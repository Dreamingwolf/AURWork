# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2014-2015 Perfect Privacy <support@perfect-privacy.com>
# This program is free software: you can redistribute it and/or modify it 
# under the terms of the GNU General Public License version 3, as published 
# by the Free Software Foundation.
# 
# This program is distributed in the hope that it will be useful, but 
# WITHOUT ANY WARRANTY; without even the implied warranties of 
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR 
# PURPOSE.  See the GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License along 
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

from locale import gettext as _
import logging
from perfect_privacy_vpn_lib.AboutDialog import AboutDialog
import perfect_privacy_vpn_lib.perfect_privacy_vpnconfig as config


class AboutPerfectPrivacyVpnDialog(AboutDialog):
    __gtype_name__ = "AboutPerfectPrivacyVpnDialog"

    # noinspection PyAttributeOutsideInit
    def finish_initializing(self, builder):  # pylint: disable=E1002
        """Set up the about dialog"""
        super(AboutPerfectPrivacyVpnDialog, self).finish_initializing(builder)

        self._logger = logging.getLogger(__name__)

        self.set_name(config.get_name())
        self.set_program_name(config.get_name())
        self.set_version(config.get_version())
        self.set_website(config.get_website())
        self.set_website_label(config.get_website()
                               .replace("https://", "").replace("http://", ""))
