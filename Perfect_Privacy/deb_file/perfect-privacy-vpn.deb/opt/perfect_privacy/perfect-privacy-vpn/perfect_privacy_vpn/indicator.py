# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2014-2015 Perfect Privacy <support@perfect-privacy.com>
# This program is free software: you can redistribute it and/or modify it 
# under the terms of the GNU General Public License version 3, as published 
# by the Free Software Foundation.
# 
# This program is distributed in the hope that it will be useful, but 
# WITHOUT ANY WARRANTY; without even the implied warranties of 
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR 
# PURPOSE.  See the GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License along 
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

"""
Indicator (panel icon)

new_application_indicator() returns an indicator based on the desktop
"""

from blinker import Signal
# noinspection PyUnresolvedReferences
from gi.repository import Gtk, GdkPixbuf, GObject  # pylint: disable=E0611

#noinspection PyBroadException
try:
    # try using Ubuntu App Indicator instead of gtk.StatusIcon
    # noinspection PyUnresolvedReferences
    import gi
    gi.require_version('AppIndicator3', '0.1')
    #noinspection PyUnresolvedReferences
    from gi.repository import AppIndicator3  # pylint: disable=E0611
    _use_appindicator = True
except ImportError:
    # fallback is Gtk.StatusIcon
    _use_appindicator = False

from perfect_privacy_vpn_lib.helpers import get_media_file_path
import logging
import gettext
from gettext import gettext as _
gettext.textdomain('perfect-privacy-vpn')


class Indicator(object):
    """
    :type _core: perfect_privacy_vpn_lib.core.Core
    """

    STATUS_DISCONNECTED = get_media_file_path(
        "icon_indicator_disconnected.png")
    STATUS_UNSTABLE = get_media_file_path("icon_indicator_unstable.png")
    STATUS_CONNECTED = get_media_file_path("icon_indicator_connected.png")

    _STATUS_LIST = [STATUS_DISCONNECTED, STATUS_UNSTABLE, STATUS_CONNECTED]

    def __init__(self, core):
        self._logger = logging.getLogger(__name__)

        self.on_icon_left_clicked = Signal()
        self.on_menu_item_status_clicked = Signal()
        self.on_menu_item_about_clicked = Signal()
        self.on_menu_item_preferences_clicked = Signal()
        self.on_menu_item_quit_clicked = Signal()

        self._core = core
        self._core.servergroup_list.vpn_state.on_change.connect(
            self._on_server_group_list_vpn_state_changed)

        self.menu = self._create_main_menu()
        self.menu.show()

    def _on_server_group_list_vpn_state_changed(self, sender, main_state, main_message, sub_state, sub_message, last_changed):
        """
        :type sender: servers.vpn_connection.VPNState
        """
        image_path = self.STATUS_UNSTABLE
        if sender.is_inactive():
            image_path = self.STATUS_DISCONNECTED
        elif sender.is_connected():
            image_path = self.STATUS_CONNECTED

        self.update_panel_icon(image_path)

    def _create_main_menu(self):
        """
        Create a main menu with all menu items
        """

        menu = Gtk.Menu()

        # Status
        menu_item_status = Gtk.MenuItem(_("Status"))
        menu.append(menu_item_status)
        menu_item_status.connect("activate", self._on_menu_item_status_clicked)
        menu_item_status.show_all()

        # ----------------
        separator = Gtk.MenuItem()
        menu.append(separator)
        separator.show_all()

        # Preferences
        menu_item_preferences = Gtk.MenuItem(_("Preferences"))
        menu.append(menu_item_preferences)
        menu_item_preferences.connect("activate",
                                      self._on_menu_item_preferences_clicked)
        menu_item_preferences.show_all()

        # About
        menu_item_about = Gtk.MenuItem(_("About"))
        menu.append(menu_item_about)
        menu_item_about.connect("activate", self._on_menu_item_about_clicked)
        menu_item_about.show_all()

        # ----------------
        separator = Gtk.MenuItem()
        menu.append(separator)
        separator.show_all()

        # Quit
        menu_item_quit = Gtk.MenuItem(_("Quit"))
        menu.append(menu_item_quit)
        menu_item_quit.connect("activate", self._on_menu_item_quit_clicked)
        menu_item_quit.show_all()

        return menu

    #noinspection PyUnusedLocal
    def _on_menu_item_status_clicked(self, item):
        """
        User clicked 'Status'
        Send signal
        """
        self.on_menu_item_status_clicked.send(self)

    # noinspection PyUnusedLocal
    def _on_menu_item_preferences_clicked(self, item):
        """
        User clicked 'Preferences'
        Send signal
        """
        self.on_menu_item_preferences_clicked.send(self)

    #noinspection PyUnusedLocal
    def _on_menu_item_about_clicked(self, args):
        """
        User clicked 'About'
        Send signal
        """
        self.on_menu_item_about_clicked.send(self)

    #noinspection PyUnusedLocal
    def _on_menu_item_quit_clicked(self, args):
        """
        User clicked 'Quit'
        Send signal
        """
        self.on_menu_item_quit_clicked.send(self)

    def update_panel_icon(self, status):
        """
        Update the icon color
        @param status: the new connection status
        @type status: str
        """
        self._logger.debug("updating panel icon")
        assert status in self._STATUS_LIST

        def do():
            self._set_icon(status)

        GObject.idle_add(do)

    def _set_icon(self, icon_path):
        raise NotImplementedError()


class AppIndicator(Indicator):
    """
    Indicator is an AppIndicator (for Unity Desktop)
    """

    def __init__(self, core):
        super(AppIndicator, self).__init__(core)
        self._logger = logging.getLogger(__name__)

        self._logger.info("new Gtk.StatusIcon (for Gnome Desktop)")

        self.indicator = AppIndicator3.Indicator.new(
            'perfect-privacy-vpn',
            self.STATUS_DISCONNECTED,
            AppIndicator3.IndicatorCategory.APPLICATION_STATUS)
        self.indicator.set_status(AppIndicator3.IndicatorStatus.ACTIVE)

        # attach menu to icon
        # this will automatically show the menu when icon was clicked
        self.indicator.set_menu(self.menu)

    def _set_icon(self, icon_path):
        def do():
            self.indicator.set_icon(icon_path)
        GObject.idle_add(do)


class StatusIcon(Indicator):
    """
    Indicator is a Gtk.StatusIcon (for Gnome Desktop)
    """

    def __init__(self, core):
        super(StatusIcon, self).__init__(core)
        self._logger = logging.getLogger(__name__)

        self._logger.info("new AppIndicator (for Unity Desktop)")

        self.indicator = Gtk.StatusIcon()
        self._set_icon(self.STATUS_DISCONNECTED)

        # manually attach menu to icon
        # different behaviour:
        #  right click -> show menu
        #  left click -> show main window (via signal)
        self.indicator.connect("popup-menu", self._on_icon_right_click)
        self.indicator.connect("activate", self._on_icon_left_click)

    def _on_icon_right_click(self, icon, button, time):
        """
        Show popup menu when indicator right-clicked
        """
        self.menu.popup(parent_menu_shell=None,
                        parent_menu_item=None,
                        func=Gtk.StatusIcon.position_menu,
                        button=button,
                        activate_time=time,
                        data=icon)
        return

    # noinspection PyUnusedLocal
    def _on_icon_left_click(self, icon):
        """
        Show popup menu when indicator left-clicked
        This only applies for Gtk.StatusIcon
        """
        self.on_icon_left_clicked.send(self)

    def _set_icon(self, icon_path):
        def do():
            self.indicator.set_from_file(icon_path)
        GObject.idle_add(do)


def new_application_indicator(core):
    if _use_appindicator:
        ind = AppIndicator(core)
    else:
        ind = StatusIcon(core)
    return ind
