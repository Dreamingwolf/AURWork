# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2014-2015 Perfect Privacy <support@perfect-privacy.com>
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License version 3, as published
# by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranties of
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR
# PURPOSE.  See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

# noinspection PyUnresolvedReferences
from gi.repository import Gtk, GObject  # pylint: disable=E0611

from perfect_privacy_vpn_lib.helpers import get_builder
from perfect_privacy_api import PortForwarding
from perfect_privacy_vpn.ChangeCpfServerDialog import ChangeCpfServerDialog

import logging
import gettext
from gettext import gettext as _
gettext.textdomain('perfect-privacy-vpn')


class PrefPaneIPsPorts(Gtk.Box):
    __gtype_name__ = "PrefPaneIPsPorts"

    def __new__(cls):
        """
        Special static method that's automatically called by Python when
        constructing a new instance of this class.
        
        Returns a fully instantiated ServerBoDialog object.
        """
        builder = get_builder('PrefPaneIPsPorts')
        new_object = builder.get_object('pref_pane_ips_ports')
        new_object.finish_initializing(builder)
        return new_object

    def __init__(self, *args):
        super(PrefPaneIPsPorts, self).__init__(args)

    # noinspection PyAttributeOutsideInit
    def finish_initializing(self, builder):
        """
        Called when we're finished initializing.

        finish_initalizing should be called after parsing the ui definition
        and creating a ServerBoDialog object with it in order to
        finish initializing the start of the new ServerBoDialog
        instance.
        """

        # Get a reference to the builder and set up the signals.
        self.builder = builder
        self.ui = builder.get_ui(self)
        self._logger = logging.getLogger(__name__)

        self._core = None
        self._cpf_selected_server_group = None

        # TRANSLATOR: settings window, Tab 'IPs and Ports'
        self.label_header_page = Gtk.Label(_("IPs and Ports"))

        self.set_sensitive(False)

        # setup list
        renderer_source_port = Gtk.CellRendererText()
        column_source_port = Gtk.TreeViewColumn(_("Source"),
                                                renderer_source_port,
                                                text=0)
        self.ui.treeview_cpf_list.append_column(column_source_port)

        renderer_destination_port = Gtk.CellRendererText()
        column_destination_port = Gtk.TreeViewColumn(_("Destination"),
                                                     renderer_destination_port,
                                                     text=1)
        self.ui.treeview_cpf_list.append_column(column_destination_port)

        renderer_valid_until = Gtk.CellRendererText()
        column_valid_until = Gtk.TreeViewColumn(_("Valid until"),
                                                renderer_valid_until,
                                                text=2)
        self.ui.treeview_cpf_list.append_column(column_valid_until)

        self._liststore_cpf_list = Gtk.ListStore(int, int, str, int)
        self.ui.treeview_cpf_list.set_model(self._liststore_cpf_list)

        # === initialize labels ===
        self._init_labels()

        # manually connect some signals to  save the handler ids
        #TODO: get the handler ids on the fly
        self._handler_ids = {}
        self._handler_ids[self.ui.chk_random_exit] = \
            self.ui.chk_random_exit.connect("toggled",
                                            self._on_chk_random_exit_toggled)
        self._handler_ids[self.ui.chk_default_port_forwarding] = \
            self.ui.chk_default_port_forwarding.connect(
                "toggled",
                self._on_chk_default_port_forwarding_toggled)
        self._handler_ids[self.ui.chk_cpf_autorenew] = \
            self.ui.chk_cpf_autorenew.connect(
                "toggled",
                self._on_chk_cpf_autorenew_changed)

        self._logger.debug("handler ids: {}".format(self._handler_ids))

        # TODO: connect automatically?
        self.ui.entry_cpf_dest_port.connect(
            "changed", self._on_entry_cpf_dest_port_changed)

        return

    def _init_labels(self):
        # TODO: initialize labels and tooltips
        pass

    # noinspection PyAttributeOutsideInit
    def set_core(self, core):
        """
        :type core: perfect_privacy_vpn_lib.core.Core
        """
        self._core = core

        if self._core.user_api_async.data_is_available:
            self._update_all_elements()
            self.set_sensitive(True)
        else:
            self._core.user_api_async.force_update()

        self._blinker_event_mapping = [
            (self._core.user_api_async.on_random_exit_changed,
             self._on_random_exit_changed),
            (self._core.user_api_async.on_default_port_forwarding_changed,
             self._on_default_port_forwarding_changed),
            (self._core.user_api_async.on_auto_renew_port_forwarding_changed,
             self._on_auto_renew_port_forwarding_changed),
            (self._core.user_api_async.on_custom_port_forwardings_changed,
             self._on_custom_port_forwardings_changed),
            (self._core.user_api_async.on_data_becomes_available,
             self._on_data_becomes_available),
            (self._core.user_api_async.on_data_becomes_unavailable,
             self._on_data_becomes_unavailable)
        ]

        for (event, method) in self._blinker_event_mapping:
            event.connect(method)

    def _on_chk_random_exit_toggled(self, widget):
        new_status = widget.get_active()
        self._logger.debug("chk_random_exit toggled to {}".format(new_status))
        self._core.user_api_async.random_exit = new_status

    def _on_random_exit_changed(self, sender, new_value, by_request):
        if not by_request:
            GObject.idle_add(self.show_info_bar,
                             Gtk.MessageType.INFO,
                             _("You changed 'Enable random exit IP address'"),
                             _("(on another computer or on the web site)"))
        GObject.idle_add(self._update_random_exit, new_value)

    def _update_random_exit(self, new_value):
        if new_value is None:
            return

        # block event handler. Setting the active value programmatically
        # doesn't fire a toggled event again
        self.ui.chk_random_exit.handler_block(
            self._handler_ids[self.ui.chk_random_exit])

        self.ui.chk_random_exit.set_active(new_value)

        self.ui.chk_random_exit.handler_unblock(
            self._handler_ids[self.ui.chk_random_exit])

        return

    def destroy(self):
        super(PrefPaneIPsPorts, self).destroy()

        for (event, method) in self._blinker_event_mapping:
            event.disconnect(method)

    def _on_chk_default_port_forwarding_toggled(self, widget):
        new_status = widget.get_active()
        self._logger.debug("chk_default_port_forwarding toggled to {}".format(
            new_status))
        self._core.user_api_async.default_port_forwarding = new_status

    def _on_default_port_forwarding_changed(self, sender, new_value,
                                            by_request):
        if not by_request:
            GObject.idle_add(self.show_info_bar,
                             Gtk.MessageType.INFO,
                             _("You changed 'Enable default port forwarding'"),
                             _("(on another computer or on the web site)"))
        GObject.idle_add(self._update_default_port_forwarding, new_value)

    def _update_default_port_forwarding(self, new_value):
        if new_value is None:
            return

        # block event handler. Setting the active value programmatically
        # doesn't fire a toggled event again
        self.ui.chk_default_port_forwarding.handler_block(
            self._handler_ids[self.ui.chk_default_port_forwarding])

        self.ui.chk_default_port_forwarding.set_active(new_value)

        self.ui.chk_default_port_forwarding.handler_unblock(
            self._handler_ids[self.ui.chk_default_port_forwarding])

        return

    def on_chk_cpf_toggled(self, widget, delete_existing_cpfs=True):
        self._logger.debug("chk_cpf toggled")

        # sensitiveness
        cpf_active = widget.get_active()
        self.ui.box_cpf_extras.set_sensitive(cpf_active)

        self._set_cpf_add_buttons_sensitiveness()

        # deactivate: delete all port forwardings
        if delete_existing_cpfs and not widget.get_active():
            self._delete_all_custom_port_forwardings()

    def _delete_all_custom_port_forwardings(self):
        self._core.user_api_async.delete_all_custom_port_forwardings()

    def _on_chk_cpf_autorenew_changed(self, widget):
        new_status = widget.get_active()
        self._logger.debug("chk_auto_renew_port_forwarding toggled to {}".
                           format(new_status))
        self._core.user_api_async.auto_renew_port_forwarding = new_status

    def _on_auto_renew_port_forwarding_changed(self, sender, new_value,
                                               by_request):
        if not by_request:
            GObject.idle_add(
                self.show_info_bar,
                Gtk.MessageType.INFO,
                _("You changed 'Automatically renew expired forwardings'"),
                _("(on another computer or on the web site)"))

        GObject.idle_add(self._update_auto_renew_port_forwarding, new_value)

    def _update_auto_renew_port_forwarding(self, new_value):
        if new_value is None:
            return

        # block event handler. Setting the active value programmatically
        # doesn't fire a toggled event again
        self.ui.chk_cpf_autorenew.handler_block(
            self._handler_ids[self.ui.chk_cpf_autorenew])

        self.ui.chk_cpf_autorenew.set_active(new_value)

        self.ui.chk_cpf_autorenew.handler_unblock(
            self._handler_ids[self.ui.chk_cpf_autorenew])

        return

    def _on_custom_port_forwardings_changed(self, sender, new_value,
                                            by_request):

        self._logger.debug("custom port forwarding changed")

        if not by_request:
            GObject.idle_add(
                self.show_info_bar,
                Gtk.MessageType.INFO,
                _("You changed the custom port forwardings"),
                _("(on another computer or on the web site)"))

        GObject.idle_add(self._update_custom_port_forwardings, new_value)

    def _update_custom_port_forwardings(self, new_port_forwardings):
        """
        @param new_port_forwardings:
        @type new_port_forwardings: list of PortForwarding
        """
        self._logger.debug("updating custom port forwardings ({})".format(
            new_port_forwardings))

        if not new_port_forwardings:  # list is empty
            def hide_list():
                #TODO: disable chk_cpf (block handlers)
                self.ui.label_cpf_no_cpfs.set_visible(True)
                self.ui.box_cpf_list.set_visible(False)

            GObject.idle_add(hide_list)

        else:
            # fill list
            self._liststore_cpf_list.clear()
            for port_forwarding in new_port_forwardings:
                self._liststore_cpf_list.append([
                    port_forwarding.src_port,
                    port_forwarding.dest_port,
                    port_forwarding.valid_until.strftime(
                        "%d.%m.%Y %H:%M:%S (UTC)"),
                    port_forwarding.pf_id
                ])
                # TODO: port forwarding (valid until) UTC -> local time

            self._cpf_selected_server_group = \
                new_port_forwardings[0].server_group_name

            def show_list():
                # set selected server group
                self.ui.label_cpf_current_server.set_text(
                    self._cpf_selected_server_group)

                self.ui.label_cpf_no_cpfs.set_visible(False)
                self.ui.box_cpf_list.set_visible(True)
                self.ui.chk_cpf.set_active(True)
                self._set_cpf_add_buttons_sensitiveness()

            GObject.idle_add(show_list)

    def on_button_cpf_change_server_clicked(self, widget):
        self._logger.debug("button cpf_change_server clicked")

        # show "change server group" window
        window_change_cpf_server = ChangeCpfServerDialog()
        response = window_change_cpf_server.run(self._core)

        self._logger.debug("dialog returned {}".format(response))
        if response != Gtk.ResponseType.OK:
            self._logger.debug("changing cpf server group cancelled")
            window_change_cpf_server.destroy()
            return

        # noinspection PyAttributeOutsideInit
        self._cpf_selected_server_group = \
            window_change_cpf_server.selected_server_group

        self.ui.label_cpf_current_server.set_text(
            self._cpf_selected_server_group)
        self._delete_all_custom_port_forwardings()

        self._set_cpf_add_buttons_sensitiveness()

        window_change_cpf_server.destroy()

    def on_treeviewselection_cpf_list_changed(self, selection):
        liststore, treeiter = selection.get_selected()

        self.ui.button_cpf_delete.set_sensitive(treeiter is not None)

    def on_button_cpf_delete_clicked(self, widget):
        liststore, treeiter = self.ui.treeviewselection_cpf_list.get_selected()
        pf_id = liststore.get_value(treeiter, 3)
        port_forwarding = PortForwarding(pf_id=pf_id)
        self._core.user_api_async.delete_custom_port_forwarding(
            port_forwarding)

    def on_button_cpf_add_1to1_clicked(self, widget):
        port_forwarding = PortForwarding(
            server_group_name=self._cpf_selected_server_group)
        self._core.user_api_async.add_custom_port_forwarding(port_forwarding)

    def on_button_cpf_add_custom_clicked(self, widget):
        dest_port = self.ui.entry_cpf_dest_port.get_text()
        self.ui.entry_cpf_dest_port.set_text("")
        port_forwarding = PortForwarding(
            server_group_name=self._cpf_selected_server_group,
            dest_port=dest_port)
        self._core.user_api_async.add_custom_port_forwarding(port_forwarding)

    def _on_entry_cpf_dest_port_changed(self, widget):
        self._set_cpf_add_buttons_sensitiveness()

    def _set_cpf_add_buttons_sensitiveness(self):
        button_1to1_sensitive = False
        button_custom_sensitive = False

        if self._cpf_selected_server_group is not None \
                and len(self._core.user_api_async.custom_port_forwardings) < 5:
            button_1to1_sensitive = True

            if self.ui.entry_cpf_dest_port.get_text_length() > 0:
                try:
                    int(self.ui.entry_cpf_dest_port.get_text())
                    button_custom_sensitive = True
                except:
                    pass

        self.ui.button_cpf_add_1to1.set_sensitive(button_1to1_sensitive)
        self.ui.button_cpf_add_custom.set_sensitive(button_custom_sensitive)

    def _on_data_becomes_available(self, sender):
        self._logger.debug("data became available. enabling IPs/Ports pane")

        def do():
            self.set_sensitive(True)
        GObject.idle_add(do)

    def _on_data_becomes_unavailable(self, sender):
        self._logger.debug("data became unavailable. disabling IPs/Ports pane")

        def do():
            self.set_sensitive(False)
        GObject.idle_add(do)

    def _update_all_elements(self):
        self._update_random_exit(
            new_value=self._core.user_api_async.random_exit)
        self._update_default_port_forwarding(
            new_value=self._core.user_api_async.default_port_forwarding)
        self._update_auto_renew_port_forwarding(
            new_value=self._core.user_api_async.auto_renew_port_forwarding)
        self._update_custom_port_forwardings(
            new_port_forwardings=
            self._core.user_api_async.custom_port_forwardings)

    def show_info_bar(self, info_bar_type, title, subtitle=None):
        self._logger.debug("showing notify message: {} ({})"
                           .format(title, subtitle))
        new_infobar = Gtk.InfoBar()
        new_infobar.set_message_type(info_bar_type)
        new_infobar.set_show_close_button(True)

        new_infobar.get_content_area().set_orientation(
            Gtk.Orientation.VERTICAL)
        new_infobar.get_content_area().set_spacing(0)

        infobar_title_label = Gtk.Label(title)
        infobar_title_label.set_halign(Gtk.Align.START)
        infobar_title_label.set_sensitive(True)
        new_infobar.get_content_area().add(infobar_title_label)

        if subtitle is not None:
            infobar_subtitle_label = Gtk.Label(subtitle)
            infobar_subtitle_label.set_halign(Gtk.Align.START)
            infobar_subtitle_label.set_sensitive(True)
            new_infobar.get_content_area().add(infobar_subtitle_label)

        self.ui.box_notify.pack_end(new_infobar, True, True, 0)
        new_infobar.connect("response", self._info_bar_response)
        new_infobar.show_all()

    # noinspection PyMethodMayBeStatic,PyUnusedLocal
    def _info_bar_response(self, info_bar, response_id):
        info_bar.hide()
        info_bar.destroy()

    # noinspection PyUnusedLocal
    def on_focus(self, sender, args):
        self._logger.debug("received focus")
        self._update_all_elements()