# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2014-2015 Perfect Privacy <support@perfect-privacy.com>
# This program is free software: you can redistribute it and/or modify it 
# under the terms of the GNU General Public License version 3, as published 
# by the Free Software Foundation.
# 
# This program is distributed in the hope that it will be useful, but 
# WITHOUT ANY WARRANTY; without even the implied warranties of 
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR 
# PURPOSE.  See the GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License along 
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

import optparse
import os.path
import shutil
import os
import signal
import threading
from locale import gettext as _

# noinspection PyUnresolvedReferences
import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk  # pylint: disable=E0611

from perfect_privacy_vpn import PerfectPrivacyVpnWindow
from perfect_privacy_vpn_lib import set_up_logging, get_version, Core


VPN_SERVICE_NAME = "Perfect Privacy"
VPN_SERVICE_NAME_SANITIZED = "".join(
    c for c in VPN_SERVICE_NAME.replace(' ', '_')
    if c.isalnum() or c == '_' or c == '-').lower()
CONFIG_DIR = os.path.join("/usr/share", "{}_vpn".format(VPN_SERVICE_NAME_SANITIZED))
CONFIG_FILE_ACCOUNT_SETTINGS = os.path.join(CONFIG_DIR, "account_settings.json")
CONFIG_DIR_OPENVPN_BUNDLE = os.path.join(CONFIG_DIR, "openvpn_configs")

core = None
is_running = True


def migrate():
    """
    migrate
    """
    try:
        import pwd
        import os

        user = pwd.getpwuid(int(os.environ["PKEXEC_UID"])).pw_name
        user_home_dir = '/home/{}'.format(user)

        user_config_dir = os.path.join(user_home_dir, ".{}_vpn".format(VPN_SERVICE_NAME_SANITIZED))

        # rename config dir (< 1.3)
        # ~/.perfect_privacy_openvpn_manager -> ~/.perfect_privacy_vpn
        old_config_dir = os.path.join(user_home_dir, ".%s_openvpn_manager" % VPN_SERVICE_NAME_SANITIZED)
        if os.path.exists(old_config_dir) and not os.path.exists(user_config_dir):
            os.rename(old_config_dir, user_config_dir)

        # remove old configs (< 1.2)
        old_openvpn_config_dir = os.path.join(user_config_dir, "openvpn")
        if os.path.exists(old_openvpn_config_dir):
            shutil.rmtree(old_openvpn_config_dir)

        # move old user/password file to /usr/share
        account_config_file = os.path.join(user_config_dir, "account_settings.json")
        if os.path.exists(account_config_file) and not os.path.exists(CONFIG_FILE_ACCOUNT_SETTINGS):
            os.mkdir(os.path.dirname(CONFIG_FILE_ACCOUNT_SETTINGS))
            os.rename(account_config_file, CONFIG_FILE_ACCOUNT_SETTINGS)
            os.chmod(CONFIG_FILE_ACCOUNT_SETTINGS, 0o600)
            os.chown(CONFIG_FILE_ACCOUNT_SETTINGS, 0, 0)
            shutil.rmtree(user_config_dir)
            return True
    except:
        pass
    return False


def parse_options():
    """Support for command line options"""
    parser = optparse.OptionParser(version="%%prog %s" % get_version())
    parser.add_option(
        "-d", "--debug", action="count", dest="debug",
        help=_("Show debug messages"))
    (options, args) = parser.parse_args()

    set_up_logging(options)


def main():

    if os.getuid() != 0:
        print("Need to be root. Abort.")
        exit(1)

    t = threading.Thread(target=run)
    t.daemon = True
    t.start()

    signal.signal(signal.SIGTERM, on_sig_int_term)
    signal.signal(signal.SIGINT, on_sig_int_term)

    while is_running:
        signal.pause()

    Gtk.main_quit()

    t.join(timeout=10)
    if t.is_alive():
        print("shutting down gracefully failed")


def on_core_quit(sender):
    global is_running
    if not is_running:
        return

    is_running = False

    # send SIGTERM to release signal.pause()
    # and finally stop the program
    os.kill(os.getpid(), signal.SIGTERM)


def on_sig_int_term(signal_number, stack_frame):
    global core
    global is_running
    if not is_running:
        return
    try:
        core.quit()
    except:
        pass
    finally:
        is_running = False


def run():
    parse_options()

    needs_config_update = False
    try:
        needs_config_update = migrate()
    except:
        pass

    # Run the application.
    global core
    core = Core(CONFIG_FILE_ACCOUNT_SETTINGS, CONFIG_DIR_OPENVPN_BUNDLE)
    core.on_quit.connect(on_core_quit)

    if needs_config_update:
        username = core.get_username()
        password = core.get_password()
        if username and password:
            core.servergroup_list.update_configs(
                username=username,
                password=password,
                blocking=False,
                create_new=True)

    window = PerfectPrivacyVpnWindow.PerfectPrivacyVpnWindow()
    window.core = core
    window.show()

    from perfect_privacy_vpn import indicator as pp_indicator
    indicator = pp_indicator.new_application_indicator(core)

    def on_indicator_left_clicked(sender):
        window.present()

    def on_indicator_status_clicked(sender):
        window.present()

    def on_indicator_preferences_clicked(sender):
        window.show_preferences_dialog()

    def on_indicator_about_clicked(sender):
        window.show_about_dialog()

    def on_indicator_quit_clicked(sender):
        core.quit()

    indicator.on_menu_item_status_clicked.connect(on_indicator_status_clicked)
    indicator.on_menu_item_about_clicked.connect(on_indicator_about_clicked)
    indicator.on_menu_item_preferences_clicked.connect(
        on_indicator_preferences_clicked)
    indicator.on_menu_item_quit_clicked.connect(on_indicator_quit_clicked)
    indicator.on_icon_left_clicked.connect(on_indicator_left_clicked)

    core.on_program_started()

    Gtk.main()
