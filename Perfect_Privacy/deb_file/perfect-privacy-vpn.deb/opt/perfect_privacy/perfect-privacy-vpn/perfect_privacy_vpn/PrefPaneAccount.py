# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2014-2015 Perfect Privacy <support@perfect-privacy.com>
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License version 3, as published
# by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranties of
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR
# PURPOSE.  See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

# noinspection PyUnresolvedReferences
from gi.repository import Gtk, GObject  # pylint: disable=E0611

from perfect_privacy_vpn_lib.helpers import get_builder

import logging
from random import randint
import gettext
from gettext import gettext as _
gettext.textdomain('perfect-privacy-vpn')


class PrefPaneAccount(Gtk.Box):
    __gtype_name__ = "PrefPaneAccount"

    TEXT_NO_ACCOUNT_INFORMATION = _("No account information available")

    def __new__(cls):
        """
        Special static method that's automatically called by Python when
        constructing a new instance of this class.
        
        Returns a fully instantiated ServerBoDialog object.
        """
        builder = get_builder('PrefPaneAccount')
        new_object = builder.get_object('pref_pane_account')
        new_object.finish_initializing(builder)
        return new_object

    # noinspection PyAttributeOutsideInit
    def finish_initializing(self, builder):
        """
        Called when we're finished initializing.

        finish_initalizing should be called after parsing the ui definition
        and creating a ServerBoDialog object with it in order to
        finish initializing the start of the new ServerBoDialog
        instance.
        """
        # Get a reference to the builder and set up the signals.
        self.builder = builder
        self.ui = builder.get_ui(self)
        self._logger = logging.getLogger(__name__)

        self._core = None

        # TRANSLATOR: settings window
        self.label_header_page = Gtk.Label(_("General"))

        # TRANSLATOR: settings window
        self.ui.label_header_credentials.set_label(_("<b>Credentials</b>"))
        # TRANSLATOR: settings window
        self.ui.label_username.set_label(_("Username:"))
        # TRANSLATOR: settings window
        self.ui.label_password.set_label(_("Password:"))
        # TRANSLATOR: settings window
        self.ui.checkbutton_enable_tray_icon.set_label(_("Enable Tray Icon"))

        self.ui.label_header_account_information.set_label(
            _("<b>Account Information</b>"))

        self.ui.label_membership_expiration_text.set_label(
            self.TEXT_NO_ACCOUNT_INFORMATION)
        self.ui.label_membership_expiration_date.hide()

        self.ui.frame_account_information.set_sensitive(False)

        self._liststore_server_groups = Gtk.ListStore(str, str)
        self.ui.combobox_server_groups.set_model(self._liststore_server_groups)

        return

    # noinspection PyAttributeOutsideInit
    def set_core(self, core):
        """
        :type core: perfect_privacy_vpn_lib.core.Core
        """
        self._core = core

        self.ui.entry_username.set_text(self._core.get_username())
        self.ui.entry_password.set_text(self._core.get_password())

        self._core.user_api_async.on_data_becomes_available.connect(
            self._on_data_becomes_available)
        self._core.user_api_async.on_data_becomes_unavailable.connect(
            self._on_data_becomes_unavailable)

        self._core.user_api_async.on_valid_until_changed.connect(
            self._on_user_api_valid_until_changed)

        if self._core.user_api_async.data_is_available:
            self._on_user_api_valid_until_changed(
                None, self._core.user_api_async.valid_until, False)
            self._on_data_becomes_available(None)

        self._core.settings.on_change.connect(self._on_settings_change)
        self._update_checkbutton_enable_tray_icon()
        self.ui.checkbutton_enable_tray_icon.connect("toggled", self._on_checkbutton_enable_tray_icon_toggled)

        self._update_checkbutton_auto_connect()
        self._update_server_groups()
        self.ui.checkbutton_auto_connect.connect("toggled", self._on_checkbutton_auto_connect_toggled)
        self.ui.combobox_server_groups.connect("changed", self._on_combobox_server_groups_changed)
        self._core.servergroup_list.update_state.on_change.connect(
            self._on_config_update_state_changed)

    def _update_server_groups(self):
        self._logger.debug("updating server groups combobox")

        self._liststore_server_groups.clear()
        server_groups = self._core.selected_server_list[:]
        if server_groups:
            server_groups.sort(key=lambda g: g.human_readable_name)
            active_item = randint(0, len(server_groups) - 1)

            for group in server_groups:
                if self._core.settings.get_auto_connect_hostname() == group.hostname:
                    active_item = len(self._liststore_server_groups)
                self._liststore_server_groups.append([group. human_readable_name, group.hostname])

            self.ui.combobox_server_groups.set_active(active_item)

    def _on_config_update_state_changed(self, sender):
        """
        :type sender: servers.servergrouplistwithvpnconnection.UpdateState
        """
        if sender.main_state == sender.UPDATE_STATE_UPDATE_SUCCEEDED:
            def do():
                self._update_server_groups()
            GObject.idle_add(do)

    def _save_auto_connect(self):
        new_hostname = None
        if self.ui.checkbutton_auto_connect.get_active():
            liststore_id = self.ui.combobox_server_groups.get_active()
            new_hostname = self._liststore_server_groups[liststore_id][1]

        self._logger.debug("new auto-connect hostname: '{}'".format(new_hostname))
        self._core.settings.save_auto_connect_hostname(new_hostname)

    def _update_checkbutton_auto_connect(self):
        self.ui.checkbutton_auto_connect.set_active(bool(self._core.settings.get_auto_connect_hostname()))

    def _on_checkbutton_auto_connect_toggled(self, widget):
        self._save_auto_connect()

    def _on_combobox_server_groups_changed(self, widget):
        self._save_auto_connect()

    def on_entry_username_activate(self, entry):
        self._core.set_username(entry.get_text())

    def on_entry_username_focus_out_event(self, entry, data):
        self._core.set_username(entry.get_text())

    def on_entry_password_activate(self, entry):
        self._core.set_password(entry.get_text())

    def on_entry_password_focus_out_event(self, entry, data):
        self._core.set_password(entry.get_text())

    def _on_user_api_valid_until_changed(self, sender, new_value, by_request):
        """
        @param new_value: the new datetime
        @type new_value: datetime.datetime
        """
        # TODO: membership date UTC -> local time
        def do():
            if new_value is None:
                self.ui.label_membership_expiration_date.hide()
                self.ui.label_membership_expiration_text.set_label(
                    self.TEXT_NO_ACCOUNT_INFORMATION)
            else:
                self.ui.label_membership_expiration_text.set_label(
                    _("Your membership is valid until"))
                self.ui.label_membership_expiration_date.set_label(
                    new_value.strftime("%d.%m.%Y %H:%M:%S (UTC)"))
                self.ui.label_membership_expiration_date.show()
        GObject.idle_add(do)
        return

    def _on_data_becomes_available(self, sender):
        def do():
            self.ui.frame_account_information.set_sensitive(True)
        GObject.idle_add(do)

    def _on_data_becomes_unavailable(self, sender):
        def do():
            self.ui.frame_account_information.set_sensitive(False)
        GObject.idle_add(do)

    def _on_settings_change(self, sender):
        GObject.idle_add(self._update_checkbutton_enable_tray_icon)

    def _update_checkbutton_enable_tray_icon(self):
        self.ui.checkbutton_enable_tray_icon.set_active(self._core.settings.get_enable_tray_icon())

    def _on_checkbutton_enable_tray_icon_toggled(self, checkbutton):
        self._core.settings.save_enable_tray_icon(self.ui.checkbutton_enable_tray_icon.get_active())

    # noinspection PyUnusedLocal
    def on_focus(self, sender, args):
        self._logger.debug("received focus")
