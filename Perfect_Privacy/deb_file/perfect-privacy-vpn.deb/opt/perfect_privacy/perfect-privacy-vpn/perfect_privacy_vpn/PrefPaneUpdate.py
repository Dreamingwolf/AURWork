# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2014-2015 Perfect Privacy <support@perfect-privacy.com>
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License version 3, as published
# by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranties of
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR
# PURPOSE.  See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

# noinspection PyUnresolvedReferences
from gi.repository import Gtk, GObject  # pylint: disable=E0611

from perfect_privacy_vpn_lib.helpers import get_builder
from perfect_privacy_vpn_lib import get_version
from servers.servergrouplistwithopenvpnconfig import UpdateState

import logging
import gettext
from gettext import gettext as _
gettext.textdomain('perfect-privacy-vpn')


class PrefPaneUpdate(Gtk.Box):
    __gtype_name__ = "PrefPaneUpdate"

    def __new__(cls):
        """
        Special static method that's automatically called by Python when
        constructing a new instance of this class.
        
        Returns a fully instantiated ServerBoDialog object.
        """
        builder = get_builder('PrefPaneUpdate')
        new_object = builder.get_object('pref_pane_update')
        new_object.finish_initializing(builder)
        return new_object

    # noinspection PyAttributeOutsideInit
    def finish_initializing(self, builder):
        """
        Called when we're finished initializing.

        finish_initalizing should be called after parsing the ui definition
        and creating a ServerBoDialog object with it in order to
        finish initializing the start of the new ServerBoDialog
        instance.
        """
        # Get a reference to the builder and set up the signals.
        self.builder = builder
        self.ui = builder.get_ui(self)
        self._logger = logging.getLogger(__name__)

        self._core = None

        # === initialize labels ===

        # TRANSLATOR: settings window, update VPN config
        self.label_header_page = Gtk.Label(_("Update"))

        # TRANSLATOR: settings window, update VPN config
        self.ui.label_header_config_update.set_label("<b>{}</b>".format(
            _("VPN Configuration")))
        # TRANSLATOR: settings window, update VPN config
        self.ui.label_current_config_version_text.set_label(
            _("Current Version:"))
        # TRANSLATOR: settings window, update VPN config
        self.ui.button_update.set_label(_("Update VPN configuration"))

        # TRANSLATOR: settings window, update software
        self.ui.label_header_software_update.set_label("<b>{}</b>".format(
            _("Software")))
        # TRANSLATOR: settings window, update software
        self.ui.label_current_software_version_text.set_label(
            _("Current Version: "))
        self.ui.label_current_software_version_number.set_label(get_version())
        # TRANSLATOR: settings window, update software
        self.ui.label_software_notice.set_label(
            _("Software updates will be installed by your system's "
              "update manager."))

    # noinspection PyAttributeOutsideInit
    def set_core(self, core):
        """
        :type core: perfect_privacy_vpn_lib.core.Core
        """
        self._core = core

        self._core.servergroup_list.update_state.on_change.connect(
            self._on_update_state_changed)
        if self._core.servergroup_list.update_state.main_state \
                == UpdateState.UPDATE_STATE_UPDATING:
            self._on_config_update_started(
                self._core.servergroup_list.update_state.full_message)
        self._update_config_version()

    def _update_config_version(self):
        current_config_version = self._core.servergroup_list.config_version
        if current_config_version is None:
            current_config_version = _("no configurations installed yet")
        else:
            current_config_version = str(current_config_version)
        self.ui.label_current_config_version_number.set_label(
            current_config_version)

    def on_button_update_clicked(self, widget):
        def do():
            username = self._core.get_username()
            password = self._core.get_password()
            if not username or not password:
                self._on_config_update_failed(
                    _("Cannot update: username/password missing"))
                return
            self.ui.button_update.set_sensitive(False)
            self._core.servergroup_list.update_configs(
                username=username,
                password=password,
                blocking=False,
                create_new=True)

        GObject.idle_add(do)

    def _on_update_state_changed(self, sender):
        """
        :type sender: servers.servergrouplistwithvpnconnection.UpdateState
        """
        if sender.main_state == sender.UPDATE_STATE_UPDATING:
            self._on_config_update_started(sender.full_message)
        elif sender.main_state == sender.UPDATE_STATE_UPDATE_SUCCEEDED \
                or sender.main_state == sender.UPDATE_STATE_NO_UPDATE_REQUIRED:
            self._on_config_update_succeeded(sender.full_message)
        elif sender.main_state == sender.UPDATE_STATE_UPDATE_FAILED:
            self._on_config_update_failed(sender.full_message)

    def _on_config_update_started(self, message):
        def do():
            self.ui.button_update.set_sensitive(False)
            self.ui.label_update_status.set_label(message)
            self.ui.spinner_update.start()
            self.ui.spinner_update.set_visible(True)
            self.ui.box_update_status.set_visible(True)
            self.ui.image_success.set_visible(False)
            self.ui.image_error.set_visible(False)
            self._update_config_version()
        GObject.idle_add(do)

    def _on_config_update_failed(self, message):
        def do():
            self.ui.label_update_status.set_label(message)
            self.ui.spinner_update.stop()
            self.ui.spinner_update.set_visible(False)
            self.ui.image_error.set_visible(True)
            self.ui.button_update.set_sensitive(True)
            self.ui.box_update_status.set_visible(True)
            self._update_config_version()
        GObject.idle_add(do)

    def _on_config_update_succeeded(self, message):
        def do():
            self.ui.label_update_status.set_label(message)
            self.ui.spinner_update.stop()
            self.ui.spinner_update.set_visible(False)
            self.ui.image_success.set_visible(True)
            self.ui.button_update.set_sensitive(True)
            self._update_config_version()
        GObject.idle_add(do)

    # noinspection PyUnusedLocal
    def on_focus(self, sender, args):
        self._logger.debug("received focus")
