# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2014-2015 Perfect Privacy <support@perfect-privacy.com>
# This program is free software: you can redistribute it and/or modify it 
# under the terms of the GNU General Public License version 3, as published 
# by the Free Software Foundation.
# 
# This program is distributed in the hope that it will be useful, but 
# WITHOUT ANY WARRANTY; without even the implied warranties of 
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR 
# PURPOSE.  See the GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License along 
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

# noinspection PyUnresolvedReferences
from gi.repository import Gtk, GObject  # pylint: disable=E0611
from perfect_privacy_vpn_lib.helpers import get_builder
import gettext
from gettext import gettext as _
gettext.textdomain('perfect-privacy-vpn')


class LogDialog(Gtk.Dialog):
    __gtype_name__ = "LogDialog"

    def __new__(cls):
        """Special static method that's automatically called by Python when 
        constructing a new instance of this class.
        
        Returns a fully instantiated LogDialog object.
        """
        builder = get_builder('LogDialog')
        new_object = builder.get_object('log_dialog')
        new_object.finish_initializing(builder)
        return new_object

    # noinspection PyAttributeOutsideInit
    def finish_initializing(self, builder):
        """Called when we're finished initializing.

        finish_initalizing should be called after parsing the ui definition
        and creating a LogDialog object with it in order to
        finish initializing the start of the new LogDialog
        instance.
        """
        # Get a reference to the builder and set up the signals.
        self.builder = builder
        self.ui = builder.get_ui(self)

        self._server = None

        self.set_title("Log")

        return

    def set_server(self, server):
        """
        :param server:
        :type server: servers.server.ServerWithVPNConnection
        """
        self._server = server
        self._server.vpn_connection.on_log.connect(self._on_log, weak=False)

        # TRANSLATOR: Log dialog title
        self.set_title(_("{server_name} Log").format(
            server_name=self._server.human_readable_name))

        GObject.idle_add(self._populate_textview)
        return

    def _on_log(self, sender, new_line):
        GObject.idle_add(self._append_line, new_line)
        return

    def _populate_textview(self):
        str_log = ""

        for l in self._server.vpn_connection.log:
            str_log += l + "\n"

        buff = self.ui.textview_log.get_buffer()
        buff.set_text(str_log)
        self.ui.textview_log.queue_draw()
        self.ui.textview_log.scroll_to_iter(buff.get_end_iter(), 0.0,
                                            use_align=False, xalign=0.5,
                                            yalign=0.5)
        return

    def _append_line(self, new_line):
        buff = self.ui.textview_log.get_buffer()
        buff.insert(buff.get_end_iter(), "%s\n" % new_line)
        self.ui.textview_log.scroll_to_iter(buff.get_end_iter(), 0.0,
                                            use_align=False, xalign=0.5,
                                            yalign=0.5)
        return

    def on_btn_close_clicked(self, widget):
        self._server.vpn_connection.on_log.disconnect(self._on_log)
        self.destroy()
        self = None
