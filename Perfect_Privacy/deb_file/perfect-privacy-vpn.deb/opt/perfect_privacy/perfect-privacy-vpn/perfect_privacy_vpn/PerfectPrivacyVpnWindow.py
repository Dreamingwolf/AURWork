# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2014-2015 Perfect Privacy <support@perfect-privacy.com>
# This program is free software: you can redistribute it and/or modify it 
# under the terms of the GNU General Public License version 3, as published 
# by the Free Software Foundation.
# 
# This program is distributed in the hope that it will be useful, but 
# WITHOUT ANY WARRANTY; without even the implied warranties of 
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR 
# PURPOSE.  See the GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License along 
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

from locale import gettext as _
# noinspection PyUnresolvedReferences
from gi.repository import Gtk, Gdk, GObject  # pylint: disable=E0611
import logging
from perfect_privacy_vpn_lib.helpers import get_media_file

from perfect_privacy_vpn_lib import Window
from perfect_privacy_vpn.AboutPerfectPrivacyVpnDialog \
    import AboutPerfectPrivacyVpnDialog
from perfect_privacy_vpn.PreferencesPerfectPrivacyVpnDialog \
    import PreferencesPerfectPrivacyVpnDialog
from perfect_privacy_vpn.ServerBox import ServerBox
from perfect_privacy_vpn.SetupDialog import SetupDialog

from perfect_privacy_vpn_lib.helpers import get_media_file_path
from perfect_privacy_vpn_lib import get_name


class PerfectPrivacyVpnWindow(Window):
    # overrides perfect_privacy_vpn_lib.Window.py

    __gtype_name__ = "PerfectPrivacyVpnWindow"

    STATUS_CONNECTED = get_media_file_path("icon_dashboard_connected.png")
    STATUS_UNSTABLE = get_media_file_path("icon_dashboard_unstable.png")
    STATUS_DISCONNECTED = get_media_file_path(
        "icon_dashboard_disconnected.png")

    _STATUS_LIST = [STATUS_CONNECTED, STATUS_UNSTABLE, STATUS_DISCONNECTED]

    SORT_ORDER_LOCATION_NAME = "SORT_ORDER_NAME"
    SORT_ORDER_LOCATION_COUNTRY = "SORT_ORDER_COUNTRY"
    SORT_ORDER_BANDWIDTH_ABSOLUTE = "SORT_ORDER_BANDWIDTH_ABSOLUTE"
    SORT_ORDER_BANDWIDTH_RELATIVE = "SORT_ORDER_BANDWIDTH_RELATIVE"

    # noinspection PyAttributeOutsideInit
    def finish_initializing(self, builder):  # pylint: disable=E1002
        """
        Set up the main window
        See Window.__new__ for details
        """
        super(PerfectPrivacyVpnWindow, self).finish_initializing(builder)

        self.set_default_size(500, 700)

        self.AboutDialog = AboutPerfectPrivacyVpnDialog
        self.PreferencesDialog = PreferencesPerfectPrivacyVpnDialog

        self._logger = logging.getLogger(__name__)

        self._server_box_list = []

        self._core = None
        self._settings_window = None

        # show disconnected icon
        self.ui.image_status.set_from_file(self.STATUS_DISCONNECTED)

        # === initialize labels ===

        self.set_title(get_name())

        # TRANSLATOR: status window
        self.ui.button_settings.set_label(_("Settings..."))
        # TRANSLATOR: status window
        self.ui.button_quit.set_label(_("Quit"))
        # TRANSLATOR: status window
        self.ui.button_minimize.set_label(_("To Tray"))

        # TRANSLATOR: status window
        self.ui.label_no_servers.set_label(
            _("There are no locations available yet.\n\n"
              "Please go to 'Settings', enter your credentials and "
              "update the VPN configurations."))

        self.connect("notify::is-active", self._on_window_gets_focus)

        # create border around server list box using CSS
        style_provider = Gtk.CssProvider()
        css = """
        .border {
            border-width: 1px;
            border-color: #aaaaaa;
            border-style: solid;
            border-radius: 3px;
        }
        """
        style_provider.load_from_data(css)
        Gtk.StyleContext.add_provider_for_screen(
            Gdk.Screen.get_default(),
            style_provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )

        # header
        # TRANSLATOR: server list header
        self._label_header_location_markup = "<b>{}</b>".format(_("Location"))
        self.ui.label_header_location.set_markup(
            self._label_header_location_markup)
        # TRANSLATOR: server list header
        self._label_header_bandwidth_markup = "<b>{}</b>".format(
            _("Available Bandwidth"))
        self.ui.label_header_bandwidth.set_markup(
            self._label_header_bandwidth_markup)

        # sort order of the server list
        self._sort_order = self.SORT_ORDER_LOCATION_NAME
        self._sorting_reversed = False

        return

    @property
    def core(self):
        return self._core

    @core.setter
    def core(self, core):
        """
        :type core: perfect_privacy_vpn_lib.core.Core
        """
        # noinspection PyAttributeOutsideInit
        self._core = core

        self.ui.label_status.set_label(
            self._core.servergroup_list.vpn_state.full_message)

        self._update_minimize_button()
        self.core.settings.on_change.connect(self._on_settings_change)

        self._core.servergroup_list.update_state.on_change.connect(
            self._on_config_update_state_changed)

        self._core.servergroup_list.vpn_state.on_change.connect(
            self._on_server_group_list_state_changed)

        self._rebuild_list()

        if not self._core.settings.config_existed_on_startup():
            self._logger.debug("showing setup")
            setup_dialog = SetupDialog()
            response = setup_dialog.run(self._core)
            self._core.settings.save_enable_tray_icon(response == Gtk.ResponseType.YES)
            self._logger.debug("setup finished")
            setup_dialog.destroy()

    # noinspection PyUnusedLocal
    def _on_config_update_state_changed(self, sender):
        """
        :type sender: servers.servergrouplistwithvpnconnection.UpdateState
        """
        if sender.main_state == sender.UPDATE_STATE_UPDATE_SUCCEEDED:
            self._rebuild_list()

    def _on_server_group_list_state_changed(self, sender, main_state, main_message, sub_state, sub_message, last_changed):
        """
        :type new_state: vpn_connection.VPNState
        """
        self.update_status_image()
        self.update_application_icon()

    def _on_settings_change(self, sender):
        self._update_minimize_button()

    def _update_minimize_button(self):
        def do():
            if self._core.settings.get_enable_tray_icon():
                self.ui.button_minimize.show()
            else:
                self.ui.button_minimize.hide()
        GObject.idle_add(do)

    def _rebuild_list(self):
        self._logger.debug("re-building list")

        # clear server_box_list
        self._server_box_list = []
        """ :type: list(ServerBox) """

        # get new list from core, create new server boxes
        for s in self._core.selected_server_list:
            if s.vpn_connection is None or not s.vpn_connection.is_available():
                continue
            new_server_box = ServerBox()
            new_server_box.set_core_and_server(self._core, s)
            self._server_box_list.append(new_server_box)

        # sort
        self._sort_list()

        # display
        self._show_list()

    def _sort_list(self):
        self._logger.debug("sort order: {}, reversed={}".format(
            self._sort_order, self._sorting_reversed))

        if self._sort_order == self.SORT_ORDER_LOCATION_NAME:
            key = lambda box: box.human_readable_name
        elif self._sort_order == self.SORT_ORDER_LOCATION_COUNTRY:
            key = lambda box: "{}_{}".format(box.country_name,
                                             box.human_readable_name)
        elif self._sort_order == self.SORT_ORDER_BANDWIDTH_ABSOLUTE:
            key = lambda box: box.bandwidth_available_mbps
        elif self._sort_order == self.SORT_ORDER_BANDWIDTH_RELATIVE:
            key = lambda box: 1 - box.bandwidth_load
        else:
            self._logger.error("program error: invalid sort order")
            return

        sorted_list = sorted(self._server_box_list,
                             key=key,
                             reverse=self._sorting_reversed)

        self._server_box_list = sorted_list

    def _show_list(self):
        def do():
            # remove all boxes
            self.ui.box_openvpn_server_list.foreach(
                lambda widget, data: self.ui.box_openvpn_server_list.remove(
                    widget),
                None)

            # add all boxes
            for server_box in self._server_box_list:
                self.ui.box_openvpn_server_list.pack_start(
                    child=server_box, expand=True, fill=True,
                    padding=0)

            # if there are no boxes, display update message
            self.ui.label_no_servers.set_visible(
                len(self._server_box_list) == 0)

            # display sort order arrow (unicode)
            location_markup = self._label_header_location_markup
            bandwidth_markup = self._label_header_bandwidth_markup
            arrow_markup = u"  <span size='7000' rise='2000'>{}</span>".format(
                u"\u25BC" if self._sorting_reversed else u"\u25B2")

            if self._sort_order in [self.SORT_ORDER_LOCATION_NAME,
                                    self.SORT_ORDER_LOCATION_COUNTRY]:
                location_markup += arrow_markup
            elif self._sort_order in [self.SORT_ORDER_BANDWIDTH_ABSOLUTE,
                                      self.SORT_ORDER_BANDWIDTH_RELATIVE]:
                bandwidth_markup += arrow_markup

            self.ui.label_header_location.set_markup(location_markup)
            self.ui.label_header_bandwidth.set_markup(bandwidth_markup)

        GObject.idle_add(do)

    def on_eventbox_label_header_location_button_release_event(self, widget,
                                                             args):
        if self._sort_order == self.SORT_ORDER_LOCATION_NAME:
            self._sort_order = self.SORT_ORDER_LOCATION_COUNTRY
        elif self._sort_order == self.SORT_ORDER_LOCATION_COUNTRY:
            self._sort_order = self.SORT_ORDER_LOCATION_NAME
            self._sorting_reversed = not self._sorting_reversed
        else:
            self._sort_order = self.SORT_ORDER_LOCATION_NAME
            self._sorting_reversed = False

        self._sort_list()
        self._show_list()

    def on_eventbox_label_header_location_enter_notify_event(self, widget, a):
        def do():
            widget.get_parent_window().set_cursor(
                Gdk.Cursor(Gdk.CursorType.HAND1))
        GObject.idle_add(do)

    def on_eventbox_label_header_location_leave_notify_event(self, widget, a):
        def do():
            widget.get_parent_window().set_cursor(None)
        GObject.idle_add(do)

    def on_eventbox_label_header_bandwidth_enter_notify_event(self, widget, a):
        def do():
            widget.get_parent_window().set_cursor(
                Gdk.Cursor(Gdk.CursorType.HAND1))
        GObject.idle_add(do)

    def on_eventbox_label_header_bandwidth_leave_notify_event(self, widget, a):
        def do():
            widget.get_parent_window().set_cursor(None)
        GObject.idle_add(do)

    def on_eventbox_label_header_bandwidth_button_release_event(self, widget,
                                                              args):
        if self._sort_order == self.SORT_ORDER_BANDWIDTH_ABSOLUTE:
            self._sort_order = self.SORT_ORDER_BANDWIDTH_RELATIVE
        elif self._sort_order == self.SORT_ORDER_BANDWIDTH_RELATIVE:
            self._sort_order = self.SORT_ORDER_BANDWIDTH_ABSOLUTE
            self._sorting_reversed = not self._sorting_reversed
        else:
            self._sort_order = self.SORT_ORDER_BANDWIDTH_ABSOLUTE
            self._sorting_reversed = True

        self._sort_list()
        self._show_list()

    # noinspection PyUnusedLocal
    def on_button_settings_clicked(self, widget):
        self.show_preferences_dialog()

    # noinspection PyUnusedLocal
    def on_button_quit_clicked(self, widget):
        self._core.quit()

    def hide(self):
        super(PerfectPrivacyVpnWindow, self).hide()
        # we don't need to update the bandwidth if the window is hidden
        self._core.bandwidth_updater.stop()

    def present(self):
        super(PerfectPrivacyVpnWindow, self).present()
        # start updating the bandwidth again
        self._core.bandwidth_updater.start()

    # noinspection PyUnusedLocal
    def on_button_minimize_clicked(self, widget):
        self._core.bandwidth_updater.stop()

    def _on_window_gets_focus(self, sender, args):
        if sender.is_active() and self._core is not None:
            # the user is active, reset bandwidth update interval
            self._core.bandwidth_updater.reset_interval()

    # noinspection PyUnusedLocal
    def on_delete_event(self, widget, data):
        if self._core.settings.get_enable_tray_icon():
            self.hide()
            return True
        else:
            self._core.quit()

    def update_status_image(self):
        vpn_state = self._core.servergroup_list.vpn_state

        image_path = self.STATUS_UNSTABLE
        if vpn_state.is_connected():
            image_path = self.STATUS_CONNECTED
        if vpn_state.is_inactive():
            image_path = self.STATUS_DISCONNECTED

        message = vpn_state.full_message

        def do():
            self.ui.label_status.set_label(message)
            self.ui.image_status.set_from_file(image_path)

        GObject.idle_add(do)

    def update_application_icon(self):
        vpn_state = self._core.servergroup_list.vpn_state

        image_path = self.STATUS_UNSTABLE
        if vpn_state.is_inactive():
            image_path = self.STATUS_DISCONNECTED
        elif vpn_state.is_connected():
            image_path = self.STATUS_CONNECTED

        def do():
            self.set_icon_from_file(image_path)

        GObject.idle_add(do)
