# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2014-2015 Perfect Privacy <support@perfect-privacy.com>
# This program is free software: you can redistribute it and/or modify it 
# under the terms of the GNU General Public License version 3, as published 
# by the Free Software Foundation.
# 
# This program is distributed in the hope that it will be useful, but 
# WITHOUT ANY WARRANTY; without even the implied warranties of 
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR 
# PURPOSE.  See the GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License along 
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

# noinspection PyUnresolvedReferences
from gi.repository import Gtk, GObject, Gdk  # pylint: disable=E0611
from perfect_privacy_vpn_lib.helpers import get_builder, get_media_file_path
import gettext
from gettext import gettext as _
gettext.textdomain('perfect-privacy-vpn')
import logging
import os.path
from perfect_privacy_vpn.LogDialog import LogDialog


class ServerBox(Gtk.Box):
    __gtype_name__ = "ServerBox"

    def __new__(cls):
        """Special static method that's automatically called by Python when 
        constructing a new instance of this class.
        
        Returns a fully instantiated ServerBox object.
        """
        builder = get_builder('ServerBox')
        new_object = builder.get_object('server_box')
        new_object.finish_initializing(builder)
        return new_object

    # noinspection PyAttributeOutsideInit
    def finish_initializing(self, builder):
        """Called when we're finished initializing.

        finish_initalizing should be called after parsing the ui definition
        and creating a ServerBox object with it in order to
        finish initializing the start of the new ServerBox
        instance.
        """
        # Get a reference to the builder and set up the signals.
        self.builder = builder
        self.ui = builder.get_ui(self)

        self._logger = logging.getLogger(__name__)

        self._log_dialog = None

        self._server = None
        self._core = None

        return

    def set_core_and_server(self, core, server):
        """
        :type core: perfect_privacy_vpn_lib.core.Core
        :type server: servers.server.ServerWithOpenVPNConnection
        """
        # noinspection PyAttributeOutsideInit
        self._core = core
        # noinspection PyAttributeOutsideInit
        self._server = server

        # server name
        self.ui.label_server_name.set_label(
            self._server.human_readable_name)

        # icon
        icon_path = get_media_file_path(os.path.join("flags", "_unknown.png"))
        new_icon_path = get_media_file_path(os.path.join(
            "flags", "{}.png".format(self._server.country_code.upper())))
        if new_icon_path is not None and os.path.exists(new_icon_path):
            icon_path = new_icon_path
        self.ui.image_flag.set_from_file(icon_path)
        self.ui.image_flag.set_tooltip_text(self._server.country_name)

        # buttons
        self.ui.button_connect.set_label("")
        self.ui.button_show_log.set_label("")
        image = Gtk.Image()
        image.set_from_stock(Gtk.STOCK_INFO, Gtk.IconSize.BUTTON)
        self.ui.button_show_log.set_image(image)
        # TRANSLATOR: tooltip log buttons
        self.ui.button_connect.set_tooltip_text(_("Log"))

        self._server.vpn_connection.state.on_change.connect(
            self._on_server_state_changed)
        self._server.on_bandwidth_changed.connect(
            self._on_server_bandwidth_changed)

        self._core.servergroup_list.vpn_state.on_change.connect(
            self._on_global_state_changed)

        self._update_connect_button()
        self._update_bandwidth()

        return

    @property
    def human_readable_name(self):
        return self._server.human_readable_name

    @property
    def country_name(self):
        return self._server.country_name

    @property
    def bandwidth_load(self):
        if self._server.bandwidth_available:
            return self._server.bandwidth_load
        else:
            return 1.

    @property
    def bandwidth_available_mbps(self):
        if self._server.bandwidth_available:
            return ((1 - self._server.bandwidth_load) * self._server.bandwidth_max) / 1000
        else:
            return 0.

    def on_button_connect_clicked(self, widget):
        try:
            if self._server.vpn_connection.is_active():
                self._server.vpn_connection.disconnect(blocking=False)
            else:
                self._server.vpn_connection.connect()
        except:
            pass

    def on_button_show_log_clicked(self, widget):
        self._logger.debug('on_button_show_log_clicked')
        if self._log_dialog is None:
            self._log_dialog = LogDialog()
            self._log_dialog.connect('destroy', self._on_log_dialog_destroyed)
            self._log_dialog.set_server(self._server)
            self._log_dialog.show()
        else:
            self._log_dialog.present()

    def _on_log_dialog_destroyed(self, widget, data=None):
        self._logger.debug('on_log_dialog_destroyed')
        # to determine whether to create or present the log_dialog
        self._log_dialog = None

    def _on_server_state_changed(self, sender, main_state, main_message, sub_state, sub_message, last_changed):
        self._update_connect_button()
        self._update_background_color()

    def _on_server_bandwidth_changed(self, sender):
        self._update_bandwidth()

    def _update_bandwidth(self):
        def do():
            # TODO: find constants Gtk.LEVEL_BAR_OFFSET_LOW
            self.ui.levelbar_bandwidth.add_offset_value("low", 0.2)
            self.ui.levelbar_bandwidth.add_offset_value("high", 0.6)
            if self._server.bandwidth_available:
                self.ui.levelbar_bandwidth.set_value(
                    1 - self._server.bandwidth_load)
                available_mbps = int(round((1 - self._server.bandwidth_load) * self._server.bandwidth_max) / 1000)
                self.ui.label_bandwidth.set_label("{}/{} {}".format(
                    available_mbps,
                    self._server.bandwidth_max / 1000,
                    _("mbps")))
            else:
                self.ui.levelbar_bandwidth.set_value(0)
                # TRANSLATOR: bandwidth
                self.ui.label_bandwidth.set_label(_("unknown"))
        GObject.idle_add(do)

    def _on_global_state_changed(self, sender, main_state, main_message, sub_state, sub_message, last_changed):
        self._logger.debug(
            "updating (dis)connect button sensitiveness of {}"
            .format(self._server.human_readable_name))
        self._update_connect_button()

    def _update_background_color(self):
        def do():
            if self._server.vpn_connection.is_connected():
                background_color = Gdk.color_parse("#b3ffbe")
            elif self._server.vpn_connection.is_connecting():
                background_color = Gdk.color_parse("#fff3b5")
            else:
                background_color = None
            self.ui.grid_inner.modify_bg(Gtk.StateType.NORMAL,
                                         background_color)
        GObject.idle_add(do)

    def _update_connect_button(self):
        def do():
            sensitiveness = True
            if not self._core.servergroup_list.vpn_state.is_inactive() \
                    and not self._server.vpn_connection.is_active():
                # disable when any server is active but not this one
                sensitiveness = False
            self.ui.button_connect.set_sensitive(sensitiveness)

            # TRANSLATOR: Connect button
            label = _("Connect")
            stock_icon = Gtk.STOCK_CONNECT
            if self._server.vpn_connection.is_active():
                # TRANSLATOR: Connect button
                label = _("Disconnect")
                stock_icon = Gtk.STOCK_DISCONNECT
            image = Gtk.Image()
            image.set_from_stock(stock_icon, Gtk.IconSize.BUTTON)
            self.ui.button_connect.set_image(image)
            self.ui.button_connect.set_tooltip_text(label)

        GObject.idle_add(do)

    def get_server(self):
        return self._server
