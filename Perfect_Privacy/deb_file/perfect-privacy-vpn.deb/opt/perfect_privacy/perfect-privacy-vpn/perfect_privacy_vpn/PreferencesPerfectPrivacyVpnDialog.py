# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2014-2015 Perfect Privacy <support@perfect-privacy.com>
# This program is free software: you can redistribute it and/or modify it 
# under the terms of the GNU General Public License version 3, as published 
# by the Free Software Foundation.
# 
# This program is distributed in the hope that it will be useful, but 
# WITHOUT ANY WARRANTY; without even the implied warranties of 
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR 
# PURPOSE.  See the GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License along 
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

# This is your preferences dialog.
#
# Define your preferences in
# data/glib-2.0/schemas/net.launchpad.perfect-privacy-vpn.gschema.xml
# See http://developer.gnome.org/gio/stable/GSettings.html for more info.

# noinspection PyUnresolvedReferences
from locale import gettext as _
import logging
from perfect_privacy_vpn_lib.PreferencesDialog import PreferencesDialog
from perfect_privacy_vpn.PrefPaneAccount import PrefPaneAccount
from perfect_privacy_vpn.PrefPaneIPsPorts import PrefPaneIPsPorts
from perfect_privacy_vpn.PrefPaneUpdate import PrefPaneUpdate
from perfect_privacy_vpn_lib import get_name

from os.path import join
#noinspection PyUnresolvedReferences
from gi.repository import Gtk, GdkPixbuf, Pango, GObject


class PreferencesPerfectPrivacyVpnDialog(PreferencesDialog):
    """
    The preferences window
    """
    __gtype_name__ = "PreferencesPerfectPrivacyVpnDialog"

    # noinspection PyAttributeOutsideInit
    def finish_initializing(self, builder):  # pylint: disable=E1002
        """
        Set up the preferences dialog
        """
        super(PreferencesPerfectPrivacyVpnDialog, self)\
            .finish_initializing(builder)
        self._logger = logging.getLogger(__name__)

        self._core = None

        # TRANSLATOR: title of preferences window
        self.set_title(_("{application_name} Preferences")
                       .format(application_name=get_name()))

        self.set_default_size(650, 880)

        self._box_account = PrefPaneAccount()
        self._box_account.show()
        self.ui.notebook.append_page(self._box_account,
                                     self._box_account.label_header_page)

        self._box_ips_ports = PrefPaneIPsPorts()
        self._box_ips_ports.show()
        self.ui.notebook.append_page(self._box_ips_ports,
                                     self._box_ips_ports.label_header_page)

        self._box_update = PrefPaneUpdate()
        self._box_update.show()
        self.ui.notebook.append_page(self._box_update,
                                     self._box_update.label_header_page)

        # === connect signals ===
        self.connect("notify::is-active", self._on_window_gets_focus)

        return

    # noinspection PyAttributeOutsideInit
    def set_core(self, core):
        """
        :type core: perfect_privacy_vpn_lib.core.Core
        """
        self._core = core
        self._box_update.set_core(self._core)
        self._box_account.set_core(self._core)
        self._box_ips_ports.set_core(self._core)

    def _on_window_gets_focus(self, sender, args):
        if sender.is_active() and self._core is not None:
            self._core.user_api_async.request_update()

    def on_destroy(self, widget):
        self._box_update.destroy()
        self._box_account.destroy()
        self._box_ips_ports.destroy()