# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2014-2015 Perfect Privacy <support@perfect-privacy.com>
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License version 3, as published
# by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranties of
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR
# PURPOSE.  See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

from gi.repository import Gtk # pylint: disable=E0611

from perfect_privacy_vpn_lib.helpers import get_builder

import logging
import gettext
from gettext import gettext as _
from random import randint

gettext.textdomain('perfect-privacy-vpn')


class ChangeCpfServerDialog(Gtk.Dialog):
    __gtype_name__ = "ChangeCpfServerDialog"

    def __new__(cls):
        """
        Special static method that's automatically called by Python when
        constructing a new instance of this class.
        
        Returns a fully instantiated ChangeCpfServerDialog object.
        """
        builder = get_builder('ChangeCpfServerDialog')
        new_object = builder.get_object('change_cpf_server_dialog')
        new_object.finish_initializing(builder)
        return new_object

    # noinspection PyAttributeOutsideInit
    def finish_initializing(self, builder):
        """
        Called when we're finished initializing.

        finish_initalizing should be called after parsing the ui definition
        and creating a ChangeCpfServerDialog object with it in order to
        finish initializing the start of the new ChangeCpfServerDialog
        instance.
        """
        # Get a reference to the builder and set up the signals.
        self.builder = builder
        self.ui = builder.get_ui(self)
        self._logger = logging.getLogger(__name__)

        self.set_title(_("Select a server group"))

        self.selected_server_group = None

        self._liststore_server_groups = Gtk.ListStore(str)
        self.ui.combobox_server_groups.set_model(self._liststore_server_groups)

        self._core = None

    def run(self, core):
        """
        :type core: perfect_privacy_vpn_lib.core.Core
        """
        # noinspection PyAttributeOutsideInit
        self._core = core

        # initially fill combobox
        self._update_server_group()

        return super(ChangeCpfServerDialog, self).run()

    def on_btn_ok_clicked(self, widget, data=None):
        """
        Called before the dialog returns Gtk.ResponseType.OK from run().
        """
        # noinspection PyAttributeOutsideInit
        self.selected_server_group = str(
            self.ui.combobox_server_groups.get_active_text())

        self._logger.debug("server group selected: {}"
                           .format(self.selected_server_group))

    def _update_server_group(self):
        self._logger.debug("updating server groups combobox")

        self._liststore_server_groups.clear()
        server_groups = self._core.user_api_async.server_groups
        for server_group in server_groups:
            self._liststore_server_groups.append([server_group])

        # select a server group randomly if none is selected
        if self.ui.combobox_server_groups.get_active_text() is None:
            self.ui.combobox_server_groups.set_active(
                randint(0, len(server_groups)) - 1)