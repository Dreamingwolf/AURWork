# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2014-2015 Perfect Privacy <support@perfect-privacy.com>
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License version 3, as published
# by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranties of
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR
# PURPOSE.  See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

import logging
from blinker import Signal
from time import time
from gettext import gettext as _


class VPNConnectionError(Exception):
    def __init__(self, message=_("General VPN connection error")):
        super(VPNConnectionError, self).__init__(message)


class VPNConnection(object):

    def __init__(self):
        self._logger = logging.getLogger(__name__)

        self.on_log = Signal()
        self.on_credentials_required = Signal()

        self.state = VPNState()

    @property
    def log(self):
        raise NotImplementedError()

    @property
    def config_version(self):
        raise NotImplementedError()

    def connect(self):
        raise NotImplementedError()

    def disconnect(self, blocking=True):
        raise NotImplementedError()

    def set_credentials(self, username, password):
        raise NotImplementedError()

    def is_active(self):
        return not self.state.is_inactive()

    def is_connecting(self):
        return self.state.main_state == VPNState.VPN_STATE_CONNECTING

    def connecting_failed(self):
        return self.state.main_state == \
            VPNState.VPN_STATE_CONNECTING_FAILED

    def is_connected(self):
        return self.state.main_state == VPNState.VPN_STATE_CONNECTED

    def is_available(self):
        raise NotImplementedError()


class VPNState(object):
    VPN_STATE_CONNECTING = "CONNECTING"
    VPN_STATE_CONNECTED = "CONNECTED"
    VPN_STATE_CONNECTING_FAILED = "CONNECTING_FAILED"
    VPN_STATE_DISCONNECTING = "DISCONNECTING"
    VPN_STATE_DISCONNECTED = "INACTIVE"

    _VALID_VPN_STATES = {
        # TRANSLATOR: VPN state
        VPN_STATE_CONNECTING: _("Connecting"),
        # TRANSLATOR: VPN state
        VPN_STATE_CONNECTED: _("Connected"),
        # TRANSLATOR: VPN state
        VPN_STATE_CONNECTING_FAILED: _("Connecting failed"),
        # TRANSLATOR: VPN state
        VPN_STATE_DISCONNECTING: _("Disconnecting"),
        # TRANSLATOR: VPN state
        VPN_STATE_DISCONNECTED: _("Disconnected")
    }

    def __init__(self):
        self._logger = logging.getLogger(__name__)

        self.main_state = self.VPN_STATE_DISCONNECTED
        self.sub_state = None
        self.sub_message = ""
        self.last_changed = time()

        self.on_change = Signal()
        """ args: sender, main_state, main_message, sub_state, sub_message, last_changed """
        self.on_user_pass_required = Signal()

    def update(self, new_state, sub_state=None, sub_message="",
               timestamp=time(), send_signal=True):

        assert new_state in self._VALID_VPN_STATES

        self.main_state = new_state
        if sub_message == self.main_message:
            sub_message = ""
        self.sub_state = sub_state
        self.sub_message = sub_message
        self.last_changed = timestamp

        self._logger.debug("state changed to {}".format(self.full_message))

        if send_signal:
            self.send_state_changed_signal()

        return

    def send_state_changed_signal(self):
        # TODO: send full_message in addition to main/sub
        self.on_change.send(self,
                            main_state=self.main_state,
                            main_message=self.main_message,
                            sub_state=self.sub_state,
                            sub_message=self.sub_message,
                            last_changed=self.last_changed)

    @property
    def main_message(self):
        return self._VALID_VPN_STATES[self.main_state]

    @property
    def full_message(self):
        msg = self.main_message
        if self.sub_message:
            msg += ": {}".format(self.sub_message)
        return msg

    def is_connected(self):
        return self.main_state == self.VPN_STATE_CONNECTED

    def is_inactive(self):
        return self.main_state == self.VPN_STATE_DISCONNECTED \
            or self.main_state == self.VPN_STATE_CONNECTING_FAILED

    def is_unstable(self):
        return not (self.is_connected() or self.is_inactive())

    def __str__(self):
        return self.full_message
