# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2014-2015 Perfect Privacy <support@perfect-privacy.com>
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License version 3, as published
# by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranties of
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR
# PURPOSE.  See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

import logging
from threading import Thread, Event, RLock
from gettext import gettext as _
from pydoc import deque
from blinker import Signal
from datetime import datetime
import sys
import traceback

from vpn_connection import VPNState


class OpenVPNManagementInterfaceParser(Thread):
    """
    :type socket: socket._socketobject
    """

    # OpenVPN states
    _OPENVPN_STATE_CONNECTING = "CONNECTING"  # OpenVPN's initial state.
    _OPENVPN_STATE_WAIT = "WAIT"              # (Client only) Waiting for initial response from server.
    _OPENVPN_STATE_AUTH = "AUTH"              # (Client only) Authenticating with server.
    _OPENVPN_STATE_GET_CONFIG = "GET_CONFIG"  # (Client only) Downloading configuration options from server.
    _OPENVPN_STATE_ASSIGN_IP = "ASSIGN_IP"    # Assigning IP address to virtual network interface.
    _OPENVPN_STATE_ADD_ROUTES = "ADD_ROUTES"  # Adding routes to system.
    _OPENVPN_STATE_CONNECTED = "CONNECTED"    # Initialization Sequence Completed.
    _OPENVPN_STATE_RECONNECTING = "RECONNECTING"  # A restart has occurred.
    _OPENVPN_STATE_EXITING = "EXITING"        # A graceful exit is in progress.
    _OPENVPN_STATE_RESOLVE = "RESOLVE"
    _OPENVPN_STATE_SLEEP = "SLEEP"
    _OPENVPN_STATE_TCP_CONNECT = "TCP_CONNECT"
    _OPENVPN_STATE_UDP_CONNECT = "UDP_CONNECT"

    _OPENVPN_STATES_CONNECTING = [
        _OPENVPN_STATE_CONNECTING,
        _OPENVPN_STATE_WAIT,
        _OPENVPN_STATE_AUTH,
        _OPENVPN_STATE_GET_CONFIG,
        _OPENVPN_STATE_ASSIGN_IP,
        _OPENVPN_STATE_ADD_ROUTES,
        _OPENVPN_STATE_RECONNECTING,
        _OPENVPN_STATE_RESOLVE,
        _OPENVPN_STATE_SLEEP,
        _OPENVPN_STATE_TCP_CONNECT,
        _OPENVPN_STATE_UDP_CONNECT
    ]
    _OPENVPN_STATES_CONNECTED = [
        _OPENVPN_STATE_CONNECTED
    ]
    _OPENVPN_STATES_DISCONNECTING = [
        _OPENVPN_STATE_EXITING
    ]

    _OPENVPN_STATES_MESSAGES = {
        # TRANSLATOR: OpenVPN state
        _OPENVPN_STATE_CONNECTING: _("Connecting"),
        # TRANSLATOR: OpenVPN state
        _OPENVPN_STATE_WAIT: _("Waiting for server response"),
        # TRANSLATOR: OpenVPN state
        _OPENVPN_STATE_AUTH: _("Authenticating"),
        # TRANSLATOR: OpenVPN state
        _OPENVPN_STATE_GET_CONFIG: _("Getting configuration"),
        # TRANSLATOR: OpenVPN state
        _OPENVPN_STATE_ASSIGN_IP: _("Assigning IP address to virtual network interface"),
        # TRANSLATOR: OpenVPN state
        _OPENVPN_STATE_ADD_ROUTES: _("Adding routes to system"),
        # TRANSLATOR: OpenVPN state
        _OPENVPN_STATE_CONNECTED: _("Connected"),
        # TRANSLATOR: OpenVPN state
        _OPENVPN_STATE_RECONNECTING: _("Reconnecting"),
        # TRANSLATOR: OpenVPN state
        _OPENVPN_STATE_EXITING: _("Disconnecting"),
        # TRANSLATOR: OpenVPN state
        _OPENVPN_STATE_RESOLVE: _("Resolving domain name"),
        # TRANSLATOR: OpenVPN state
        _OPENVPN_STATE_SLEEP: _("Waiting for daemon process"),
        # TRANSLATOR: OpenVPN state
        _OPENVPN_STATE_TCP_CONNECT: _("Establishing TCP connection"),
        # TRANSLATOR: OpenVPN state
        _OPENVPN_STATE_UDP_CONNECT: _("Establishing UDP connection")
    }

    # reading modes
    _READING_MODE_NORMAL = 0
    _READING_MODE_BULK_LOG = 1
    _READING_MODE_BULK_STATE = 2

    def __init__(self, vpn_state):
        """
        :param vpn_state: a state reference to manipulate
        :type vpn_state: VPNState
        """
        super(OpenVPNManagementInterfaceParser, self).__init__()

        self.daemon = True

        self._logger = logging.getLogger(__name__)

        self._vpn_state = vpn_state
        self.socket = None
        self.pid = None

        self.log = deque([])
        self._reading_mode = self._READING_MODE_NORMAL

        self._username = None
        self._password = None
        self._credentials_are_set = Event()
        self._credentials_are_set.clear()

        self.on_log = Signal()
        """ args: sender, new_line """
        self.on_credentials_required = Signal()
        self.on_invalid_credentials_detected = Signal()

        self._send_lock = RLock()

    def _send_command(self, command):
        command = command.strip() + "\r\n"
        with self._send_lock:
            try:
                self.socket.sendall(command)
            except:
                pass

    def _init_management_interface(self):
        """
        initially, configure the management interface
        """
        # get pid
        self._send_command("pid")

        # log in real time
        self._send_command("log on all")

        # turn on real time state notifications
        self._send_command("state on all")

        # retry on bad passwords
        self._send_command("auth-retry interact")

        # let openvpn start its business
        self._send_command("hold off")
        self._send_command("hold release")

    def _get_line_from_socket(self):
        """
        Generator reading lines from socket
        :rtype: str
        """
        buff = ""
        done = False
        try:
            buff = self.socket.recv(1024)
        except Exception as e:
            done = True

        while not done or buff:
            if "\n" in buff:
                (line, buff) = buff.split("\n", 1)
                yield line + "\n"
            else:
                try:
                    more = self.socket.recv(1024)
                except Exception as e:
                    done = True

                if not more:
                    done = True
                else:
                    buff = buff + more

        if buff:
            yield buff

    def _process_line(self, line):
        line = line.strip()
        self._logger.debug(line)

        if line.startswith("SUCCESS: pid="):
            self.pid = int(line.replace("SUCCESS: pid=", "").strip())

        elif line == "SUCCESS: real-time log notification set to ON":
            self._reading_mode = self._READING_MODE_BULK_LOG

        elif line == "SUCCESS: real-time state notification set to ON":
            self._reading_mode = self._READING_MODE_BULK_STATE

        elif line == "END":
            # state: send state changed signal on last change only
            if self._reading_mode == self._READING_MODE_BULK_STATE:
                self._vpn_state.send_state_changed_signal()

            # reset reading mode
            self._reading_mode = self._READING_MODE_NORMAL

        elif line.startswith(">STATE:") \
                or self._reading_mode == self._READING_MODE_BULK_STATE:

            (timestamp, openvpn_state, description, tun_tap_ip, remote_ip) \
                = line.replace(">STATE:", "", 1).split(",", 4)

            state = VPNState.VPN_STATE_CONNECTING
            if openvpn_state in self._OPENVPN_STATES_CONNECTED:
                state = VPNState.VPN_STATE_CONNECTED
            elif openvpn_state in self._OPENVPN_STATES_DISCONNECTING:
                state = VPNState.VPN_STATE_DISCONNECTING

            sub_message = self._OPENVPN_STATES_MESSAGES[openvpn_state]

            # send state changed signal on last change only
            send_signal = self._reading_mode != self._READING_MODE_BULK_STATE

            # auth-failure: delete user/pass to ask for new one
            if openvpn_state == self._OPENVPN_STATE_RECONNECTING \
                    and description == "auth-failure":
                self._logger.debug("invalid credentials")
                sub_message += " ({})".format(_("invalid username/password"))
                self._username = None
                self._password = None
                self._credentials_are_set.clear()
                self.on_invalid_credentials_detected.send(self)

            self._vpn_state.update(
                new_state=state, sub_state=openvpn_state,
                sub_message=sub_message, timestamp=timestamp,
                send_signal=send_signal)

        elif line.startswith(">LOG:") \
                or self._reading_mode == self._READING_MODE_BULK_LOG:

            (timestamp, message_type, message) = line.replace(">LOG:", "", 1) \
                .split(",", 2)
            d = datetime.fromtimestamp(int(timestamp))
            formatted_d = d.strftime("%Y-%m-%d %H:%M:%S")
            new_line = "[{}] {}".format(formatted_d, message)
            self.log.append(new_line)
            self.on_log.send(self, new_line=new_line)

            if message == "MANAGEMENT: CMD 'state all'":
                self._reading_mode = self._READING_MODE_BULK_STATE

        elif line == ">PASSWORD:Need 'Auth' username/password":

            # if user/pass aren't set, wait until they are
            if self._username is None or self._password is None:
                self._logger.debug("firing signal 'on_credentials_required'")
                self.on_credentials_required.send(self)
                self._logger.debug("waiting for user/pass to be set...")
                self._credentials_are_set.wait()
                self._logger.debug("user/pass are set, continuing")

            # maybe the request_disconnect() method set the Event to unlock
            # this thread, so check whether user/pass are available
            if self._username is not None and self._password is not None:
                self._send_command(
                    "username \"Auth\" {}".format(self._username))
                self._send_command(
                    "password \"Auth\" {}".format(self._password))

    def run(self):
        self._logger.debug("starting to parse management interface")

        try:
            self._init_management_interface()

            for line in self._get_line_from_socket():
                try:
                    self._process_line(line)
                except:
                    exc_type, exc_value, exc_traceback = sys.exc_info()
                    tb = traceback.format_exception(exc_type, exc_value,
                                                    exc_traceback, limit=2)
                    self._logger.error(tb)

            self._logger.debug("no more lines left")
        except Exception as e:
            self._logger.error(str(e))
            exc_type, exc_value, exc_traceback = sys.exc_info()
            tb = traceback.format_exception(exc_type, exc_value,
                                            exc_traceback, limit=2)
            self._logger.debug("".join(tb))
        finally:
            # TODO: need to close?
            #self._logger.debug("closing socket to management interface")
            #self.socket.close()
            self._vpn_state.update(new_state=VPNState.VPN_STATE_DISCONNECTED)

        self._logger.debug("parsing management interface finished")

    def set_credentials(self, username, password):
        self._username = username
        self._password = password

        if self._username is not None and self._password is not None:
            self._credentials_are_set.set()
        else:
            self._credentials_are_set.clear()
            self.on_credentials_required.send(self)
        return

    def request_disconnect(self):
        # request openvpn to shut down
        self._send_command("signal SIGTERM")

        # thread may wait for password - release it
        self._credentials_are_set.set()

    def __del__(self):
        try:
            self.request_disconnect()
        except:
            pass
