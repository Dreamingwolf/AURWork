# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2014-2015 Perfect Privacy <support@perfect-privacy.com>
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License version 3, as published
# by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranties of
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR
# PURPOSE.  See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

import logging
import os.path
from blinker import Signal


OPENVPN_PROTOCOL_TCP = "tcp"
OPENVPN_PROTOCOL_UDP = "udp"


def get_hostname_from_ovpn_file(ovpn_config_file_path, main_domain):
    """
    Read and return the hostname from the .ovpn file.

    The hostname is in the line of the first "remote" entry
    in the.ovpn config that contains the main_domain

    :param ovpn_config_file_path: the path to the file
    :type ovpn_config_file_path: str | unicode
    :param main_domain: the domain name to search for
    :type main_domain: str | unicode
    :rtype: str | unicode
    """
    tag_hostname = ""
    hostname = ""
    with open(ovpn_config_file_path) as f:
        for l in f.readlines():
            if l.startswith("#URL"):
                tag_hostname = l.replace("#URL", "").strip()
                break
            elif not hostname and l.startswith("remote ") and l.count(main_domain) > 0:
                hostname = l.strip().split(" ")[1]
                continue

    ret_hostname = tag_hostname if tag_hostname else hostname
    if not ret_hostname:
        ret_hostname = "unknown-hostname"

    return ret_hostname


class OpenVPNConfig(object):
    def __init__(self, config_path=None, cd=None, main_domain=None):
        self._logger = logging.getLogger(__name__)

        self.on_change = Signal()

        self._clear()

        self.cd = cd
        self.main_domain = main_domain

        if config_path is not None and os.path.isfile(config_path):
            self._config_path = config_path
            self._parse_config_file()

    def _clear(self):
        self.cd = None
        self.main_domain = None
        self.hostname = None
        self.human_readable_name = None
        self.protocol = None
        self.version = None
        self.country_code = None
        self.bandwidth_mbps = None
        self.ips = []
        self.alt_ips = []
        self._config_path = None

    def clear(self):
        self._clear()
        self.on_change.send(self)

    @property
    def config_path(self):
        return self._config_path

    @config_path.setter
    def config_path(self, config_path):
        self._config_path = config_path

        if config_path is None:
            self.clear()
            return

        self._parse_config_file()

    def _parse_config_file(self):
        cd = self.cd
        main_domain = self.main_domain
        config_path = self._config_path
        self._clear()
        self.cd = cd
        self.main_domain = main_domain
        self._config_path = config_path

        first_hostname = None

        # The human readable name is the filename without the extension (.ovpn)
        # If there is an upper case letter, add a space in front of it.
        self.human_readable_name = "".join(
            c if c.islower() else " " + c
            for c in os.path.basename(self.config_path)
            .rsplit(".", 1)[0]
            .replace("udp_", "")
            .replace("tcp_", "")
            .replace("single_", "")
        ).strip()

        # parse the file
        with open(self.config_path) as f:
            for l in f.readlines():
                try:
                    if l.startswith("remote ") and not first_hostname:
                        first_hostname = l.strip().split(" ")[1]
                        continue
                    if l.startswith("remote ") and self.main_domain and \
                            l.count(self.main_domain) > 0:
                        self.hostname = l.strip().split(" ")[1]
                        continue

                    if l.startswith("proto "):
                        protocol = l.replace("proto ", "").strip()
                        if protocol == "udp":
                            self.protocol = OPENVPN_PROTOCOL_UDP
                        elif protocol == "tcp":
                            self.protocol = OPENVPN_PROTOCOL_TCP
                        continue

                    if l.startswith("#VERSION "):
                        self.version = l.replace("#VERSION ", "").strip()
                        continue

                    if l.startswith("#COUNTRY"):
                        self.country_code = l.replace("#COUNTRY", "").strip()
                        continue

                    if l.startswith("#BANDWIDTH "):
                        self.bandwidth_mbps = int(l.replace("#BANDWIDTH ", "").strip())
                        continue

                    if l.startswith("#IPS "):
                        self.ips += l.replace("#IPS ", "").strip().split(",")
                        continue

                    if l.startswith("#ALTIPS "):
                        self.alt_ips += l.replace("#ALTIPS ", "").strip().split(",")
                        continue

                except:
                    pass

            if not self.hostname:
                self.hostname = first_hostname

        # make sure a cd path is set
        if not self.cd:
            self.cd = os.path.dirname(self.config_path)

        # inform subscribers
        self.on_change.send(self)

    def __str__(self):
        return "OpenVPNConfig <config_path='{config_path}', " \
               "cd='{cd}', protocol={protocol}>".format(
                   config_path=self.config_path,
                   cd=self.cd,
                   protocol=self.protocol)
