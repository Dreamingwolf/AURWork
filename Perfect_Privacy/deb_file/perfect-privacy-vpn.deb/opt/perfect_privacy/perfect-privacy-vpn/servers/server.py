# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2014-2015 Perfect Privacy <support@perfect-privacy.com>
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License version 3, as published
# by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranties of
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR
# PURPOSE.  See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

import logging
from blinker import Signal

from country_lookup_table import COUNTRY_LOOKUP_TABLE


class Server(object):
    """
    This is a generic server containing general information such as
    hostname, human-readable name, IP addresses, country.
    """

    def __init__(self, hostname=None, human_readable_name=None,
                 primary_ips=None, alt_ips=None, country_code=None):
        self._logger = logging.getLogger(__name__)
        self.hostname = hostname
        self.human_readable_name = human_readable_name
        self.primary_ips = primary_ips if primary_ips else []
        self.alt_ips = alt_ips if alt_ips else []
        self.country_code = country_code

    @property
    def ips(self):
        ips = []
        ips.extend(self.primary_ips)
        ips.extend(self.alt_ips)
        return ips

    @property
    def country_name(self):
        if self.country_code.upper() in COUNTRY_LOOKUP_TABLE:
            return COUNTRY_LOOKUP_TABLE[self.country_code.upper()]
        else:
            return self.country_code

    def __str__(self):
        return "Server <hostname='{hostname}', " \
               "human_readable_name='{human_readable_name}'>" \
               .format(hostname=self.hostname,
                       human_readable_name=self.human_readable_name)


class ServerWithBandwidth(Server):
    """
    This class provides a server with the ability to store
    bandwidth information (max, load in/out)
    """

    def __init__(self):
        super(ServerWithBandwidth, self).__init__()
        self._logger = logging.getLogger(__name__)
        self.bandwidth_timestamp = None
        self.bandwidth_in = None
        self.bandwidth_out = None
        self.bandwidth_max = None
        self.bandwidth_load = None
        self.bandwidth_available = False
        self.on_bandwidth_changed = Signal()

    def set_bandwidth(self, bw_timestamp, bw_in, bw_out, bw_max):
        """
        Sets the bandwidth values to the given ones,
        calculates the load and sets the bandwidth_available flag.

        :param bw_timestamp: the UNIX timestamp of the information in UTC
        :type bw_timestamp: int
        :param bw_in: kbit/s incoming
        :type bw_in: int
        :param bw_out: kbit/s outgoing
        :type bw_out: int
        :param bw_max: the absolute bandwidth available in each direction
        :type bw_max: int
        """

        if bw_in >= 0 and bw_out >= 0 and bw_max > 0:
            self.bandwidth_in = bw_in
            self.bandwidth_out = bw_out
            self.bandwidth_load = 1. * max(bw_in, bw_out) / max(bw_max, bw_in, bw_out)
            self.bandwidth_available = True
        else:
            self.unset_bandwidth()

        self.bandwidth_timestamp = bw_timestamp
        self.bandwidth_max = bw_max

        self.on_bandwidth_changed.send(self)

    def unset_bandwidth(self):
        """
        Clear all bandwidth data and clear the bandwidth_available flag.
        """
        self.bandwidth_timestamp = None
        self.bandwidth_in = None
        self.bandwidth_out = None
        self.bandwidth_max = None
        self.bandwidth_load = None
        self.bandwidth_available = False
        self.on_bandwidth_changed.send(self)

    def __str__(self):
        return_string = super(ServerWithBandwidth, self).__str__()[:-1]
        return_string += "; bandwidth_max={bandwidth_max}>".format(
            bandwidth_max=self.bandwidth_max)
        return return_string


from vpn_connection import VPNConnection


class ServerWithVPNConnection(Server):
    """
    This class provides a server with the ability to store
    a generic VPN connection.

    :type vpn_connection: VPNConnection
    """

    def __init__(self):
        super(ServerWithVPNConnection, self).__init__()
        self._logger = logging.getLogger(__name__)
        self.vpn_connection = None

    def __str__(self):
        return_string = super(ServerWithVPNConnection, self).__str__()[:-1]
        return_string += "; vpn_connection={vpn_connection}>".format(
            vpn_connection=self.vpn_connection)
        return return_string


from openvpn_connection import OpenVPNConnection


class ServerWithOpenVPNConnection(ServerWithVPNConnection, ServerWithBandwidth):
    """
    This class provides a server with the ability to store
    a OpenVPN connection.

    :type vpn_connection: OpenVPNConnection
    """

    def __init__(self):
        super(ServerWithOpenVPNConnection, self).__init__()
        self._logger = logging.getLogger(__name__)
        self.vpn_connection = OpenVPNConnection()
        self.vpn_connection.on_openvpn_config_changed.connect(
            self._on_openvpn_config_changed)

    def _on_openvpn_config_changed(self, sender):
        self._logger.debug("{}: OpenVPN config changed".format(self.hostname if self.hostname else "[unknown hostname]"))

        config = self.vpn_connection.openvpn_config

        if config is None:
            return

        if config.hostname:
            if not self.hostname:
                self.hostname = config.hostname

        if not self.human_readable_name:
            self.human_readable_name = config.human_readable_name

        if config.ips:
            self.primary_ips = config.ips
        if config.alt_ips:
            self.alt_ips = config.alt_ips
        if config.country_code:
            self.country_code = config.country_code
        if config.bandwidth_mbps:
            self.bandwidth_max = config.bandwidth_mbps * 1000
