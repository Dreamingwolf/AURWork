# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2014-2015 Perfect Privacy <support@perfect-privacy.com>
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License version 3, as published
# by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranties of
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR
# PURPOSE.  See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

from gettext import gettext as _

COUNTRY_LOOKUP_TABLE = {
    # TRANSLATOR: country lookup table
    "AF": _("Afghanistan"),
    # TRANSLATOR: country lookup table
    "AL": _("Albania"),
    # TRANSLATOR: country lookup table
    "DZ": _("Algeria"),
    # TRANSLATOR: country lookup table
    "AS": _("American Samoa"),
    # TRANSLATOR: country lookup table
    "AD": _("Andorra"),
    # TRANSLATOR: country lookup table
    "AO": _("Angola"),
    # TRANSLATOR: country lookup table
    "AI": _("Anguilla"),
    # TRANSLATOR: country lookup table
    "AQ": _("Antarctica"),
    # TRANSLATOR: country lookup table
    "AG": _("Antigua and Barbuda"),
    # TRANSLATOR: country lookup table
    "AR": _("Argentina"),
    # TRANSLATOR: country lookup table
    "AM": _("Armenia"),
    # TRANSLATOR: country lookup table
    "AW": _("Aruba"),
    # TRANSLATOR: country lookup table
    "AU": _("Australia"),
    # TRANSLATOR: country lookup table
    "AT": _("Austria"),
    # TRANSLATOR: country lookup table
    "AZ": _("Azerbaijan"),
    # TRANSLATOR: country lookup table
    "BS": _("Bahamas"),
    # TRANSLATOR: country lookup table
    "BH": _("Bahrain"),
    # TRANSLATOR: country lookup table
    "BD": _("Bangladesh"),
    # TRANSLATOR: country lookup table
    "BB": _("Barbados"),
    # TRANSLATOR: country lookup table
    "BY": _("Belarus"),
    # TRANSLATOR: country lookup table
    "BE": _("Belgium"),
    # TRANSLATOR: country lookup table
    "BZ": _("Belize"),
    # TRANSLATOR: country lookup table
    "BJ": _("Benin"),
    # TRANSLATOR: country lookup table
    "BM": _("Bermuda"),
    # TRANSLATOR: country lookup table
    "BT": _("Bhutan"),
    # TRANSLATOR: country lookup table
    "BO": _("Bolivia"),
    # TRANSLATOR: country lookup table
    "BA": _("Bosnia and Herzegovina"),
    # TRANSLATOR: country lookup table
    "BW": _("Botswana"),
    # TRANSLATOR: country lookup table
    "BV": _("Bouvet Island"),
    # TRANSLATOR: country lookup table
    "BR": _("Brazil"),
    # TRANSLATOR: country lookup table
    "BQ": _("British Antarctic Territory"),
    # TRANSLATOR: country lookup table
    "IO": _("British Indian Ocean Territory"),
    # TRANSLATOR: country lookup table
    "VG": _("British Virgin Islands"),
    # TRANSLATOR: country lookup table
    "BN": _("Brunei"),
    # TRANSLATOR: country lookup table
    "BG": _("Bulgaria"),
    # TRANSLATOR: country lookup table
    "BF": _("Burkina Faso"),
    # TRANSLATOR: country lookup table
    "BI": _("Burundi"),
    # TRANSLATOR: country lookup table
    "KH": _("Cambodia"),
    # TRANSLATOR: country lookup table
    "CM": _("Cameroon"),
    # TRANSLATOR: country lookup table
    "CA": _("Canada"),
    # TRANSLATOR: country lookup table
    "CT": _("Canton and Enderbury Islands"),
    # TRANSLATOR: country lookup table
    "CV": _("Cape Verde"),
    # TRANSLATOR: country lookup table
    "KY": _("Cayman Islands"),
    # TRANSLATOR: country lookup table
    "CF": _("Central African Republic"),
    # TRANSLATOR: country lookup table
    "TD": _("Chad"),
    # TRANSLATOR: country lookup table
    "CL": _("Chile"),
    # TRANSLATOR: country lookup table
    "CN": _("China"),
    # TRANSLATOR: country lookup table
    "CX": _("Christmas Island"),
    # TRANSLATOR: country lookup table
    "CC": _("Cocos [Keeling] Islands"),
    # TRANSLATOR: country lookup table
    "CO": _("Colombia"),
    # TRANSLATOR: country lookup table
    "KM": _("Comoros"),
    # TRANSLATOR: country lookup table
    "CG": _("Congo - Brazzaville"),
    # TRANSLATOR: country lookup table
    "CD": _("Congo - Kinshasa"),
    # TRANSLATOR: country lookup table
    "CK": _("Cook Islands"),
    # TRANSLATOR: country lookup table
    "CR": _("Costa Rica"),
    # TRANSLATOR: country lookup table
    "HR": _("Croatia"),
    # TRANSLATOR: country lookup table
    "CU": _("Cuba"),
    # TRANSLATOR: country lookup table
    "CY": _("Cyprus"),
    # TRANSLATOR: country lookup table
    "CZ": _("Czech Republic"),
    # TRANSLATOR: country lookup table
    "CI": _("Côte d’Ivoire"),
    # TRANSLATOR: country lookup table
    "DK": _("Denmark"),
    # TRANSLATOR: country lookup table
    "DJ": _("Djibouti"),
    # TRANSLATOR: country lookup table
    "DM": _("Dominica"),
    # TRANSLATOR: country lookup table
    "DO": _("Dominican Republic"),
    # TRANSLATOR: country lookup table
    "NQ": _("Dronning Maud Land"),
    # TRANSLATOR: country lookup table
    "DD": _("East Germany"),
    # TRANSLATOR: country lookup table
    "EC": _("Ecuador"),
    # TRANSLATOR: country lookup table
    "EG": _("Egypt"),
    # TRANSLATOR: country lookup table
    "SV": _("El Salvador"),
    # TRANSLATOR: country lookup table
    "GQ": _("Equatorial Guinea"),
    # TRANSLATOR: country lookup table
    "ER": _("Eritrea"),
    # TRANSLATOR: country lookup table
    "EE": _("Estonia"),
    # TRANSLATOR: country lookup table
    "ET": _("Ethiopia"),
    # TRANSLATOR: country lookup table
    "FK": _("Falkland Islands"),
    # TRANSLATOR: country lookup table
    "FO": _("Faroe Islands"),
    # TRANSLATOR: country lookup table
    "FJ": _("Fiji"),
    # TRANSLATOR: country lookup table
    "FI": _("Finland"),
    # TRANSLATOR: country lookup table
    "FR": _("France"),
    # TRANSLATOR: country lookup table
    "GF": _("French Guiana"),
    # TRANSLATOR: country lookup table
    "PF": _("French Polynesia"),
    # TRANSLATOR: country lookup table
    "TF": _("French Southern Territories"),
    # TRANSLATOR: country lookup table
    "FQ": _("French Southern and Antarctic Territories"),
    # TRANSLATOR: country lookup table
    "GA": _("Gabon"),
    # TRANSLATOR: country lookup table
    "GM": _("Gambia"),
    # TRANSLATOR: country lookup table
    "GE": _("Georgia"),
    # TRANSLATOR: country lookup table
    "DE": _("Germany"),
    # TRANSLATOR: country lookup table
    "GH": _("Ghana"),
    # TRANSLATOR: country lookup table
    "GI": _("Gibraltar"),
    # TRANSLATOR: country lookup table
    "GR": _("Greece"),
    # TRANSLATOR: country lookup table
    "GL": _("Greenland"),
    # TRANSLATOR: country lookup table
    "GD": _("Grenada"),
    # TRANSLATOR: country lookup table
    "GP": _("Guadeloupe"),
    # TRANSLATOR: country lookup table
    "GU": _("Guam"),
    # TRANSLATOR: country lookup table
    "GT": _("Guatemala"),
    # TRANSLATOR: country lookup table
    "GG": _("Guernsey"),
    # TRANSLATOR: country lookup table
    "GN": _("Guinea"),
    # TRANSLATOR: country lookup table
    "GW": _("Guinea-Bissau"),
    # TRANSLATOR: country lookup table
    "GY": _("Guyana"),
    # TRANSLATOR: country lookup table
    "HT": _("Haiti"),
    # TRANSLATOR: country lookup table
    "HM": _("Heard Island and McDonald Islands"),
    # TRANSLATOR: country lookup table
    "HN": _("Honduras"),
    # TRANSLATOR: country lookup table
    "HK": _("Hong Kong SAR China"),
    # TRANSLATOR: country lookup table
    "HU": _("Hungary"),
    # TRANSLATOR: country lookup table
    "IS": _("Iceland"),
    # TRANSLATOR: country lookup table
    "IN": _("India"),
    # TRANSLATOR: country lookup table
    "ID": _("Indonesia"),
    # TRANSLATOR: country lookup table
    "IR": _("Iran"),
    # TRANSLATOR: country lookup table
    "IQ": _("Iraq"),
    # TRANSLATOR: country lookup table
    "IE": _("Ireland"),
    # TRANSLATOR: country lookup table
    "IM": _("Isle of Man"),
    # TRANSLATOR: country lookup table
    "IL": _("Israel"),
    # TRANSLATOR: country lookup table
    "IT": _("Italy"),
    # TRANSLATOR: country lookup table
    "JM": _("Jamaica"),
    # TRANSLATOR: country lookup table
    "JP": _("Japan"),
    # TRANSLATOR: country lookup table
    "JE": _("Jersey"),
    # TRANSLATOR: country lookup table
    "JT": _("Johnston Island"),
    # TRANSLATOR: country lookup table
    "JO": _("Jordan"),
    # TRANSLATOR: country lookup table
    "KZ": _("Kazakhstan"),
    # TRANSLATOR: country lookup table
    "KE": _("Kenya"),
    # TRANSLATOR: country lookup table
    "KI": _("Kiribati"),
    # TRANSLATOR: country lookup table
    "KW": _("Kuwait"),
    # TRANSLATOR: country lookup table
    "KG": _("Kyrgyzstan"),
    # TRANSLATOR: country lookup table
    "LA": _("Laos"),
    # TRANSLATOR: country lookup table
    "LV": _("Latvia"),
    # TRANSLATOR: country lookup table
    "LB": _("Lebanon"),
    # TRANSLATOR: country lookup table
    "LS": _("Lesotho"),
    # TRANSLATOR: country lookup table
    "LR": _("Liberia"),
    # TRANSLATOR: country lookup table
    "LY": _("Libya"),
    # TRANSLATOR: country lookup table
    "LI": _("Liechtenstein"),
    # TRANSLATOR: country lookup table
    "LT": _("Lithuania"),
    # TRANSLATOR: country lookup table
    "LU": _("Luxembourg"),
    # TRANSLATOR: country lookup table
    "MO": _("Macau SAR China"),
    # TRANSLATOR: country lookup table
    "MK": _("Macedonia"),
    # TRANSLATOR: country lookup table
    "MG": _("Madagascar"),
    # TRANSLATOR: country lookup table
    "MW": _("Malawi"),
    # TRANSLATOR: country lookup table
    "MY": _("Malaysia"),
    # TRANSLATOR: country lookup table
    "MV": _("Maldives"),
    # TRANSLATOR: country lookup table
    "ML": _("Mali"),
    # TRANSLATOR: country lookup table
    "MT": _("Malta"),
    # TRANSLATOR: country lookup table
    "MH": _("Marshall Islands"),
    # TRANSLATOR: country lookup table
    "MQ": _("Martinique"),
    # TRANSLATOR: country lookup table
    "MR": _("Mauritania"),
    # TRANSLATOR: country lookup table
    "MU": _("Mauritius"),
    # TRANSLATOR: country lookup table
    "YT": _("Mayotte"),
    # TRANSLATOR: country lookup table
    "FX": _("Metropolitan France"),
    # TRANSLATOR: country lookup table
    "MX": _("Mexico"),
    # TRANSLATOR: country lookup table
    "FM": _("Micronesia"),
    # TRANSLATOR: country lookup table
    "MI": _("Midway Islands"),
    # TRANSLATOR: country lookup table
    "MD": _("Moldova"),
    # TRANSLATOR: country lookup table
    "MC": _("Monaco"),
    # TRANSLATOR: country lookup table
    "MN": _("Mongolia"),
    # TRANSLATOR: country lookup table
    "ME": _("Montenegro"),
    # TRANSLATOR: country lookup table
    "MS": _("Montserrat"),
    # TRANSLATOR: country lookup table
    "MA": _("Morocco"),
    # TRANSLATOR: country lookup table
    "MZ": _("Mozambique"),
    # TRANSLATOR: country lookup table
    "MM": _("Myanmar [Burma]"),
    # TRANSLATOR: country lookup table
    "NA": _("Namibia"),
    # TRANSLATOR: country lookup table
    "NR": _("Nauru"),
    # TRANSLATOR: country lookup table
    "NP": _("Nepal"),
    # TRANSLATOR: country lookup table
    "NL": _("Netherlands"),
    # TRANSLATOR: country lookup table
    "AN": _("Netherlands Antilles"),
    # TRANSLATOR: country lookup table
    "NT": _("Neutral Zone"),
    # TRANSLATOR: country lookup table
    "NC": _("New Caledonia"),
    # TRANSLATOR: country lookup table
    "NZ": _("New Zealand"),
    # TRANSLATOR: country lookup table
    "NI": _("Nicaragua"),
    # TRANSLATOR: country lookup table
    "NE": _("Niger"),
    # TRANSLATOR: country lookup table
    "NG": _("Nigeria"),
    # TRANSLATOR: country lookup table
    "NU": _("Niue"),
    # TRANSLATOR: country lookup table
    "NF": _("Norfolk Island"),
    # TRANSLATOR: country lookup table
    "KP": _("North Korea"),
    # TRANSLATOR: country lookup table
    "VD": _("North Vietnam"),
    # TRANSLATOR: country lookup table
    "MP": _("Northern Mariana Islands"),
    # TRANSLATOR: country lookup table
    "NO": _("Norway"),
    # TRANSLATOR: country lookup table
    "OM": _("Oman"),
    # TRANSLATOR: country lookup table
    "PC": _("Pacific Islands Trust Territory"),
    # TRANSLATOR: country lookup table
    "PK": _("Pakistan"),
    # TRANSLATOR: country lookup table
    "PW": _("Palau"),
    # TRANSLATOR: country lookup table
    "PS": _("Palestinian Territories"),
    # TRANSLATOR: country lookup table
    "PA": _("Panama"),
    # TRANSLATOR: country lookup table
    "PZ": _("Panama Canal Zone"),
    # TRANSLATOR: country lookup table
    "PG": _("Papua New Guinea"),
    # TRANSLATOR: country lookup table
    "PY": _("Paraguay"),
    # TRANSLATOR: country lookup table
    "YD": _("People's Democratic Republic of Yemen"),
    # TRANSLATOR: country lookup table
    "PE": _("Peru"),
    # TRANSLATOR: country lookup table
    "PH": _("Philippines"),
    # TRANSLATOR: country lookup table
    "PN": _("Pitcairn Islands"),
    # TRANSLATOR: country lookup table
    "PL": _("Poland"),
    # TRANSLATOR: country lookup table
    "PT": _("Portugal"),
    # TRANSLATOR: country lookup table
    "PR": _("Puerto Rico"),
    # TRANSLATOR: country lookup table
    "QA": _("Qatar"),
    # TRANSLATOR: country lookup table
    "RO": _("Romania"),
    # TRANSLATOR: country lookup table
    "RU": _("Russia"),
    # TRANSLATOR: country lookup table
    "RW": _("Rwanda"),
    # TRANSLATOR: country lookup table
    "RE": _("Réunion"),
    # TRANSLATOR: country lookup table
    "BL": _("Saint Barthélemy"),
    # TRANSLATOR: country lookup table
    "SH": _("Saint Helena"),
    # TRANSLATOR: country lookup table
    "KN": _("Saint Kitts and Nevis"),
    # TRANSLATOR: country lookup table
    "LC": _("Saint Lucia"),
    # TRANSLATOR: country lookup table
    "MF": _("Saint Martin"),
    # TRANSLATOR: country lookup table
    "PM": _("Saint Pierre and Miquelon"),
    # TRANSLATOR: country lookup table
    "VC": _("Saint Vincent and the Grenadines"),
    # TRANSLATOR: country lookup table
    "WS": _("Samoa"),
    # TRANSLATOR: country lookup table
    "SM": _("San Marino"),
    # TRANSLATOR: country lookup table
    "SA": _("Saudi Arabia"),
    # TRANSLATOR: country lookup table
    "SN": _("Senegal"),
    # TRANSLATOR: country lookup table
    "RS": _("Serbia"),
    # TRANSLATOR: country lookup table
    "CS": _("Serbia and Montenegro"),
    # TRANSLATOR: country lookup table
    "SC": _("Seychelles"),
    # TRANSLATOR: country lookup table
    "SL": _("Sierra Leone"),
    # TRANSLATOR: country lookup table
    "SG": _("Singapore"),
    # TRANSLATOR: country lookup table
    "SK": _("Slovakia"),
    # TRANSLATOR: country lookup table
    "SI": _("Slovenia"),
    # TRANSLATOR: country lookup table
    "SB": _("Solomon Islands"),
    # TRANSLATOR: country lookup table
    "SO": _("Somalia"),
    # TRANSLATOR: country lookup table
    "ZA": _("South Africa"),
    # TRANSLATOR: country lookup table
    "GS": _("South Georgia and the South Sandwich Islands"),
    # TRANSLATOR: country lookup table
    "KR": _("South Korea"),
    # TRANSLATOR: country lookup table
    "ES": _("Spain"),
    # TRANSLATOR: country lookup table
    "LK": _("Sri Lanka"),
    # TRANSLATOR: country lookup table
    "SD": _("Sudan"),
    # TRANSLATOR: country lookup table
    "SR": _("Suriname"),
    # TRANSLATOR: country lookup table
    "SJ": _("Svalbard and Jan Mayen"),
    # TRANSLATOR: country lookup table
    "SZ": _("Swaziland"),
    # TRANSLATOR: country lookup table
    "SE": _("Sweden"),
    # TRANSLATOR: country lookup table
    "CH": _("Switzerland"),
    # TRANSLATOR: country lookup table
    "SY": _("Syria"),
    # TRANSLATOR: country lookup table
    "ST": _("São Tomé and Príncipe"),
    # TRANSLATOR: country lookup table
    "TW": _("Taiwan"),
    # TRANSLATOR: country lookup table
    "TJ": _("Tajikistan"),
    # TRANSLATOR: country lookup table
    "TZ": _("Tanzania"),
    # TRANSLATOR: country lookup table
    "TH": _("Thailand"),
    # TRANSLATOR: country lookup table
    "TL": _("Timor-Leste"),
    # TRANSLATOR: country lookup table
    "TG": _("Togo"),
    # TRANSLATOR: country lookup table
    "TK": _("Tokelau"),
    # TRANSLATOR: country lookup table
    "TO": _("Tonga"),
    # TRANSLATOR: country lookup table
    "TT": _("Trinidad and Tobago"),
    # TRANSLATOR: country lookup table
    "TN": _("Tunisia"),
    # TRANSLATOR: country lookup table
    "TR": _("Turkey"),
    # TRANSLATOR: country lookup table
    "TM": _("Turkmenistan"),
    # TRANSLATOR: country lookup table
    "TC": _("Turks and Caicos Islands"),
    # TRANSLATOR: country lookup table
    "TV": _("Tuvalu"),
    # TRANSLATOR: country lookup table
    "UM": _("U.S. Minor Outlying Islands"),
    # TRANSLATOR: country lookup table
    "PU": _("U.S. Miscellaneous Pacific Islands"),
    # TRANSLATOR: country lookup table
    "VI": _("U.S. Virgin Islands"),
    # TRANSLATOR: country lookup table
    "UG": _("Uganda"),
    # TRANSLATOR: country lookup table
    "UA": _("Ukraine"),
    # TRANSLATOR: country lookup table
    "SU": _("Union of Soviet Socialist Republics"),
    # TRANSLATOR: country lookup table
    "AE": _("United Arab Emirates"),
    # TRANSLATOR: country lookup table
    "GB": _("United Kingdom"),
    # TRANSLATOR: country lookup table
    "US": _("United States"),
    # TRANSLATOR: country lookup table
    "ZZ": _("Unknown or Invalid Region"),
    # TRANSLATOR: country lookup table
    "UY": _("Uruguay"),
    # TRANSLATOR: country lookup table
    "UZ": _("Uzbekistan"),
    # TRANSLATOR: country lookup table
    "VU": _("Vanuatu"),
    # TRANSLATOR: country lookup table
    "VA": _("Vatican City"),
    # TRANSLATOR: country lookup table
    "VE": _("Venezuela"),
    # TRANSLATOR: country lookup table
    "VN": _("Vietnam"),
    # TRANSLATOR: country lookup table
    "WK": _("Wake Island"),
    # TRANSLATOR: country lookup table
    "WF": _("Wallis and Futuna"),
    # TRANSLATOR: country lookup table
    "EH": _("Western Sahara"),
    # TRANSLATOR: country lookup table
    "YE": _("Yemen"),
    # TRANSLATOR: country lookup table
    "ZM": _("Zambia"),
    # TRANSLATOR: country lookup table
    "ZW": _("Zimbabwe"),
    # TRANSLATOR: country lookup table
    "AX": _("Åland Islands")
}
