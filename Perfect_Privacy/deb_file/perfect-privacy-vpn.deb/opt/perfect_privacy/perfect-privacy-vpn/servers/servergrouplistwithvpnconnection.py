# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2014-2015 Perfect Privacy <support@perfect-privacy.com>
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License version 3, as published
# by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranties of
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR
# PURPOSE.  See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

import logging
from blinker import Signal
from gettext import gettext as _
from servergrouplist import ServerGroupList
from vpn_connection import VPNState


class UpdateState(object):
    UPDATE_STATE_INACTIVE = "INACTIVE"
    UPDATE_STATE_NO_UPDATE_REQUIRED = "NO_UPDATE_REQUIRED"
    UPDATE_STATE_UPDATING = "UPDATING"
    UPDATE_STATE_UPDATE_SUCCEEDED = "UPDATE_SUCCEEDED"
    UPDATE_STATE_UPDATE_FAILED = "UPDATE_FAILED"

    _UPDATE_STATES = {
        UPDATE_STATE_INACTIVE: "",
        UPDATE_STATE_NO_UPDATE_REQUIRED: _("No update required"),
        UPDATE_STATE_UPDATING: _("Updating"),
        UPDATE_STATE_UPDATE_SUCCEEDED: _("Update succeeded"),
        UPDATE_STATE_UPDATE_FAILED: _("Update failed")
    }

    def __init__(self):
        self._logger = logging.getLogger(__name__)
        self.main_state = self.UPDATE_STATE_INACTIVE
        self.sub_message = ""
        self.on_change = Signal()

    def set(self, main_state, sub_message="", send_signal=True):
        assert main_state in self._UPDATE_STATES
        self.main_state = main_state
        self.sub_message = sub_message

        self._logger.debug(
            "update state changed to: {}".format(self.full_message))

        if send_signal:
            self.on_change.send(self)

    @property
    def message(self):
        return self._UPDATE_STATES[self.main_state]

    @property
    def full_message(self):
        message = self.message
        if self.sub_message:
            message += ": " + self.sub_message
        return message


class ServerGroupListWithVPNConnection(ServerGroupList):
    """
    This class provides a server group list, extended by the ability
    to send some common VPN connection signals

    :type groups: list[servers.servergroup.ServerGroupWithVPNConnection]
    """

    def __init__(self):
        super(ServerGroupListWithVPNConnection, self).__init__()
        self.groups = self.groups  # quick fix for "unresolved attribute" warning
        # FIXME
        self._logger = logging.getLogger(__name__)
        self.vpn_state = VPNState()
        self.update_state = UpdateState()
        self.on_vpn_requires_credentials = Signal()

    def _on_any_vpn_requires_credentials(self, sender):
        """
        :type sender: vpn_connection.VPNConnection
        """
        self.on_vpn_requires_credentials.send(sender)

    def _on_any_vpn_state_changed(self, sender, main_state, main_message, sub_state, sub_message, last_changed):
        """
        :type sender: vpn_connection.VPNState
        """
        all_vpns_disconnected = True
        any_vpn_connecting = False
        any_vpn_disconnecting = False
        any_vpn_failed = False

        for group in self.groups:
            if group.vpn_connection.state.main_state != VPNState.VPN_STATE_DISCONNECTED:
                all_vpns_disconnected = False
            if group.vpn_connection.state.main_state == VPNState.VPN_STATE_CONNECTING:
                any_vpn_connecting = True
            if group.vpn_connection.state.main_state == VPNState.VPN_STATE_DISCONNECTING:
                any_vpn_disconnecting = True
            if group.vpn_connection.state.main_state == VPNState.VPN_STATE_CONNECTING_FAILED:
                any_vpn_failed = True

            for server in group.single_servers:
                if server.vpn_connection.state.main_state != VPNState.VPN_STATE_DISCONNECTED:
                    all_vpns_disconnected = False
                if server.vpn_connection.state.main_state == VPNState.VPN_STATE_CONNECTING:
                    any_vpn_connecting = True
                if server.vpn_connection.state.main_state == VPNState.VPN_STATE_DISCONNECTING:
                    any_vpn_disconnecting = True
                if server.vpn_connection.state.main_state == VPNState.VPN_STATE_CONNECTING_FAILED:
                    any_vpn_failed = True

        if all_vpns_disconnected:
            new_state = VPNState.VPN_STATE_DISCONNECTED
        elif any_vpn_connecting:
            new_state = VPNState.VPN_STATE_CONNECTING
        elif any_vpn_disconnecting:
            new_state = VPNState.VPN_STATE_DISCONNECTING
        elif any_vpn_failed:
            new_state = VPNState.VPN_STATE_CONNECTING_FAILED
        else:
            new_state = sender.main_state

        self.vpn_state.update(
            new_state=new_state,
            sub_state=sender.sub_state,
            sub_message=sender.sub_message,
            timestamp=sender.last_changed,
            send_signal=True)

    def _reattach_signals(self):
        for group in self.groups:
            group.vpn_connection.on_credentials_required.connect(
                self._on_any_vpn_requires_credentials)
            group.vpn_connection.state.on_change.connect(
                self._on_any_vpn_state_changed)
            for server in group.single_servers:
                server.vpn_connection.on_credentials_required.connect(
                    self._on_any_vpn_requires_credentials)
                server.vpn_connection.state.on_change.connect(
                    self._on_any_vpn_state_changed)

    def disconnect_all(self):
        for group in self.groups:
            try:
                group.vpn_connection.disconnect()
            except:
                pass
            for server in group.single_servers:
                try:
                    server.vpn_connection.disconnect()
                except:
                    pass

    def update_configs(self, username, password, create_new=True):
        raise NotImplementedError()

    @property
    def config_version(self):
        current_version = None

        versions = {}

        # go through all servers and remember the number of appearances
        for group in self.groups:
            ver = group.vpn_connection.config_version
            if ver is not None:
                if ver in versions:
                    versions[ver] += 1
                else:
                    versions[ver] = 1

            for single in group.single_servers:
                ver = single.vpn_connection.config_version
                if ver is not None:
                    if ver in versions:
                        versions[ver] += 1
                    else:
                        versions[ver] = 1

        # choose the version that appears most often
        current_version_appearances = 0
        for ver in versions:
            if current_version is None \
                    or versions[ver] > current_version_appearances:
                current_version = ver
                current_version_appearances = versions[ver]

        return current_version
