# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2014-2015 Perfect Privacy <support@perfect-privacy.com>
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License version 3, as published
# by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranties of
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR
# PURPOSE.  See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

import requests
import logging
from gettext import gettext as _

from servergrouplist import ServerGroupList, DownloadError
from server import Server
from servergroup import ServerGroup


class ServerGroupListWithIPs(ServerGroupList):
    """
    This class provides a list of server groups, extended by the ability
    to download and update the list of valid IP addresses.
    """

    _SERVER_IPS_URL = "https://www.perfect-privacy.com/api/serverips"
    # contains a list of newline separated ip addresses
    # of the single servers (single servers only!)

    def __init__(self):
        super(ServerGroupListWithIPs, self).__init__()

        self._logger = logging.getLogger(__name__)

        self.request_timeout = 10.0
        """ the request timeout in seconds """

    def update_ips(self, create_new=False):
        """
        :param create_new: create new server (group) if it doesn't exist?
        """

        logging.debug("updating the list of valid IPs")

        try:
            response = requests.get(self._SERVER_IPS_URL,
                                    timeout=self.request_timeout)
        except:
            raise DownloadError(_("Updating server IP list failed"))

        if not response.ok:
            raise DownloadError(_("Updating server IP list failed"))

        for line in response.content.split("\n"):
            single_hostname = ""
            try:
                # parse line
                line = line.strip()

                # ignore lines without tab
                if "\t" not in line:
                    continue

                splitline = line.split("\t")

                single_hostname = splitline[0].strip()
                ips = [ip.strip() for ip in splitline[1].strip().split(",")]

                # find server group and single server (create new if requested)
                group, single = self.find_group_and_server(
                    hostname=single_hostname,
                    create_new_group=create_new,
                    create_new_single=create_new,
                    new_group_class=ServerGroup,
                    new_single_class=Server)

                # make sure we have a group and a single server now
                if group is None or single is None:
                    logging.debug("ignoring '{}'".format(single_hostname))
                    continue

                # update the ip list
                # only add the alt_ip if it isn't in the server already
                # this prevents duplicates in alt_ips and primary_ips
                single.alt_ips = [ip for ip in ips if ip not in single.ips]
                self._logger.debug(
                    "updated IP list of single server '{}' to {}"
                    .format(single.hostname, single.ips))

                group.alt_ips.extend([ip for ip in ips if ip not in group.ips])
                self._logger.debug(
                    "updated IP list of group '{}' to {}"
                    .format(group.hostname, group.ips))

            except:
                self._logger.error("error updating IP list of server '{}'"
                                   .format(single_hostname))
                pass
        return
