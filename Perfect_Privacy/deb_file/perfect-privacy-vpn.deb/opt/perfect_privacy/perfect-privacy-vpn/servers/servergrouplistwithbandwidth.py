# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2014-2015 Perfect Privacy <support@perfect-privacy.com>
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License version 3, as published
# by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranties of
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR
# PURPOSE.  See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

import logging
import requests
import json

from server import ServerWithBandwidth
from servergroup import ServerGroupWithBandwidth
from servergrouplist import ServerGroupList, DownloadError


class ServerGroupListWithBandwidth(ServerGroupList):
    """
    :type groups: list[ServerGroupWithBandwidth]
    """

    _SERVER_BANDWIDTH_URL = "https://www.perfect-privacy.com/api/traffic.json"

    def __init__(self):
        super(ServerGroupListWithBandwidth, self).__init__()
        self.groups = self.groups  # quick fix for "unresolved attribute" warning
        # FIXME
        self._logger = logging.getLogger(__name__)

        self.request_timeout = 10.0
        """ the request timeout in seconds """

    def get_bandwidth_as_string(self):
        """
        get bandwidth graphs as human-readable string
        """

        ret_str = ""

        def _print_load(server, is_group=False):
            single_load_str = ""
            if server.bandwidth_available:
                char = "#" if is_group else "="
                str_load = char*int(round(50*server.bandwidth_load))
                str_free = " "*int(round(50*(1-server.bandwidth_load)))
                num_load = "{}%".format(round(server.bandwidth_load*100, 2))
            else:
                str_load = "X"*50
                str_free = ""
                num_load = ""
            single_load_str += "{} {} [{}{}] {}\n".format(
                "[G]" if is_group else "   ",
                server.hostname.rjust(40),
                str_load, str_free, num_load)
            return single_load_str

        for server_group in self.groups:
            ret_str += _print_load(server_group, True)
            for single_server in server_group.single_servers:
                ret_str += _print_load(single_server, False)

        return ret_str

    def update_bandwidth(self, create_new=False):
        """
        Download new bandwidth information and update all servers
        in this group list (single servers and server groups).

        :param create_new: whether to create a new server (group) if it doesn't exist
        :type create_new: bool
        :raises: DownloadError
        """
        try:
            self._update_bandwidth(create_new=create_new)
        except DownloadError:
            self._unset_bandwidth()
        except:
            pass

    def _update_bandwidth(self, create_new=False):
        self._logger.info("updating server traffic information")
        try:
            response = requests.get(self._SERVER_BANDWIDTH_URL,
                                    timeout=self.request_timeout)
            if not response.ok:
                raise Exception()
            j = json.loads(response.content)
        except:
            self._logger.info("downloading traffic information failed")
            raise DownloadError("connection error")

        for hostname in j:
            single_hostname = hostname

            try:
                timestamp = j[hostname]["timestamp"]
                bw_in = j[hostname]["bandwidth_in"]
                bw_out = j[hostname]["bandwidth_out"]
                bw_max = j[hostname]["bandwidth_max"]
            except KeyError:
                self._logger.error("malformed traffic.json:\n{}".format(j))
                raise DownloadError("malformed file")

            group = None
            single = None

            try:

                # find server group and single server (create new if requested)
                group, single = self.find_group_and_server(
                    hostname=single_hostname,
                    is_group=False,
                    create_new_group=create_new,
                    create_new_single=create_new,
                    new_group_class=ServerGroupWithBandwidth,
                    new_single_class=ServerWithBandwidth)

                # make sure we have a group and a single server now
                if group is None or single is None:
                    self._logger.debug("ignoring '{}'".format(single_hostname))
                    continue

                # update the bandwidth
                single.set_bandwidth(timestamp, bw_in, bw_out, bw_max)
                self._logger.debug(
                    "updated bandwidth of single server '{}' to load '{}'"
                    .format(single.hostname, single.bandwidth_load))

            except Exception as e:
                self._logger.error(
                    "error updating bandwidth of {}: {}".format(single_hostname, e))
                if group is not None:
                    group.unset_bandwidth()
                if single is not None:
                    single.unset_bandwidth()

        # recalculate bandwidth of all groups
        for group in self.groups:
            group.recalculate_group_bandwidth()
            self._logger.debug(
                "updated bandwidth of group '{}' to load '{}'"
                .format(group.hostname, group.bandwidth_load))
        return

    def _unset_bandwidth(self):
        self._logger.debug("unsetting all bandwidth data")
        for group in self.groups:
            group.unset_bandwidth()
            for single in group.single_servers:
                single.unset_bandwidth()
