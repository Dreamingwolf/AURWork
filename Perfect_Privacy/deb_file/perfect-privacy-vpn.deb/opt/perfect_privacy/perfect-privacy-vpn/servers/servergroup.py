# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2014-2015 Perfect Privacy <support@perfect-privacy.com>
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License version 3, as published
# by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranties of
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR
# PURPOSE.  See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

import logging

from server import Server, ServerWithBandwidth, ServerWithVPNConnection, \
    ServerWithOpenVPNConnection


def get_group_hostname(single_hostname):
    """
    removes all digits at the and of the sub domain

    :param single_hostname: the hostname of the single server
    :type single_hostname: str
    :return: the hostname of the group
    :rtype: str
    """
    group_hostname = single_hostname.split(".")
    while group_hostname[0][-1:] in [str(n) for n in range(0, 10)]:
        group_hostname[0] = group_hostname[0][:-1]
    group_hostname = ".".join(group_hostname)
    return group_hostname


class ServerGroup(Server):
    """
    This is a server group such as london.perfect-privacy.com
    It contains a list of single servers.

    :type single_servers: list[Server]
    """

    def __init__(self):
        super(ServerGroup, self).__init__()
        self._logger = logging.getLogger(__name__)
        self.single_servers = []

    def __repr__(self):
        return_string = super(ServerGroup, self).__str__().replace(
            "Server", self.__class__.__name__)
        for server in self.single_servers:
            return_string += "\n    " + str(server)
        return return_string


class ServerGroupWithBandwidth(ServerGroup, ServerWithBandwidth):
    """
    This is a server group with the ability to store bandwidth information.

    :type single_servers: list[ServerSingleWithBandwidth]
    """

    def __init__(self):
        super(ServerGroupWithBandwidth, self).__init__()
        self._logger = logging.getLogger(__name__)
        self.single_servers = self.single_servers  # quick fix for "unresolved attribute" warning
        # FIXME

    def recalculate_group_bandwidth(self):
        """
        Takes the bandwidth values from all members of the given group
        and calculates the common bandwidth values for the group.
        """
        timestamp_min = -1
        bw_max_sum = 0
        bw_in_sum = 0
        bw_out_sum = 0

        self._logger.debug(
            "recalculating bandwidth of group '{}'".format(self.hostname))

        for server in self.single_servers:
            if server.bandwidth_timestamp is None:
                self._logger.debug("ignoring '{}': timestamp is not set"
                                   .format(server.hostname))
                continue

            # the timestamp of the group is the oldest timestamp of all members
            if timestamp_min < 0:
                timestamp_min = server.bandwidth_timestamp
            else:
                timestamp_min = min(timestamp_min, server.bandwidth_timestamp)

            # ignore unavailable servers
            if not server.bandwidth_available:
                self._logger.debug("ignoring '{}': bandwidth unavailable"
                                   .format(server.hostname))
                continue

            # ignore server if anything is missing
            if None in [server.bandwidth_in, server.bandwidth_out, server.bandwidth_max]:
                self._logger.error("ignoring '{}': bandwidth unavailable, "
                                   "but bandwidth_available is set to '{}'"
                                   .format(server.hostname,
                                           server.bandwidth_available))
                continue

            bw_max_sum += max(server.bandwidth_max, 0)
            bw_in_sum += max(server.bandwidth_in, 0)
            bw_out_sum += max(server.bandwidth_out, 0)

        if timestamp_min > 0 and bw_in_sum >= 0 and bw_out_sum >= 0 and bw_max_sum > 0:
            self.set_bandwidth(bw_timestamp=timestamp_min,
                               bw_in=bw_in_sum,
                               bw_out=bw_out_sum,
                               bw_max=bw_max_sum)
        else:
            # invalid: clear group bandwidth without clearing the group members
            super(ServerGroupWithBandwidth, self).unset_bandwidth()

        return

    def unset_bandwidth(self):
        super(ServerGroupWithBandwidth, self).unset_bandwidth()
        # clear the group bandwidth itself

        # unset the bandwidth of all members of this group
        for server in self.single_servers:
            server.unset_bandwidth()


class ServerGroupWithVPNConnection(ServerGroup, ServerWithVPNConnection):
    """
    This is a server group with the ability to store a generic VPN connection

    :type single_servers: list[ServerWithVPNConnection]
    """

    def __init__(self):
        super(ServerGroupWithVPNConnection, self).__init__()
        self._logger = logging.getLogger(__name__)
        self.single_servers = self.single_servers  # quick fix for "unresolved attribute" warning
        # FIXME


class ServerGroupWithOpenVPNConnection(ServerGroupWithVPNConnection, ServerWithOpenVPNConnection):
    """
    This is a server group with the ability to store a OpenVPN connection

    :type single_servers: list[ServerWithOpenVPNConnection]
    """

    def __init__(self):
        super(ServerGroupWithOpenVPNConnection, self).__init__()
        self._logger = logging.getLogger(__name__)
        self.single_servers = self.single_servers  # quick fix for "unresolved attribute" warning
        # FIXME


class ServerGroupWithOpenVPNConnectionAndBandwidth(
        ServerGroupWithOpenVPNConnection, ServerGroupWithBandwidth):
    pass
