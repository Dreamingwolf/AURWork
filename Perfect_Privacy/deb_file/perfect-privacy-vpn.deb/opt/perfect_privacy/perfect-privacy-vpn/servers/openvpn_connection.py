# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2014-2015 Perfect Privacy <support@perfect-privacy.com>
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License version 3, as published
# by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranties of
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR
# PURPOSE.  See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

import logging
import socket
import subprocess
from subprocess import CalledProcessError
from threading import RLock
from gettext import gettext as _
import os
from signal import SIGKILL

from blinker import Signal

from vpn_connection import VPNConnection, VPNState, VPNConnectionError
from openvpnconfig import OpenVPNConfig
from openvpn_management_interface_parser \
    import OpenVPNManagementInterfaceParser


class OpenVPNConnection(VPNConnection):
    """
    :type _openvpn_config: OpenVPNConfig
    :type _parser: OpenVPNManagementInterfaceParser
    """

    def __init__(self):
        super(OpenVPNConnection, self).__init__()
        self._logger = logging.getLogger(__name__)
        self.on_openvpn_config_changed = Signal()
        self.on_invalid_credentials_detected = Signal()

        self._openvpn_config = None
        self._parser = None
        self._connect_disconnect_lock = RLock()

        self._openvpn_command = ["/usr/bin/pkexec", "/usr/sbin/openvpn"]

    @property
    def openvpn_config(self):
        """
        :rtype: OpenVPNConfig
        """
        return self._openvpn_config

    @openvpn_config.setter
    def openvpn_config(self, openvpn_config):
        if self._openvpn_config is not None:
            self._openvpn_config.on_change.disconnect(self._on_config_changed)
        self._openvpn_config = openvpn_config
        if self._openvpn_config is not None:
            self._openvpn_config.on_change.connect(self._on_config_changed)
        self._on_config_changed()

    def _on_config_changed(self, sender=None):
        self.on_openvpn_config_changed.send(self)

    def _on_credentials_required(self, parser):
        self.on_credentials_required.send(self)

    def _on_invalid_credentials_detected(self, parser):
        self.on_invalid_credentials_detected.send(self)

    def _on_parser_log(self, sender, new_line):
        self.on_log.send(self, new_line=new_line)

    @property
    def log(self):
        if self._parser is None:
            return []
        else:
            return self._parser.log

    @property
    def config_version(self):
        if self._openvpn_config is not None:
            return self._openvpn_config.version
        else:
            return None

    def connect(self):
        """
        :raises: VPNConnectionError
        """
        self._logger.debug("connecting")

        with self._connect_disconnect_lock:

            # start if inactive only
            if self.is_active():
                self._logger.debug("connecting: VPN is already active")
                raise VPNConnectionError("VPN is already active")

            # update state
            self.state.update(
                new_state=VPNState.VPN_STATE_CONNECTING,
                sub_message=_("Starting OpenVPN"))

            # get free management port
            management_port = self._get_free_port()
            if management_port is None:
                raise VPNConnectionError(_("Couldn't get free port"))

            # compose arguments
            args = self._openvpn_command + [
                "--config", self._openvpn_config.config_path,
                "--cd", self._openvpn_config.cd,
                "--daemon",
                "--script-security", "2",
                "--management-query-passwords",
                "--management-hold",
                "--management", "127.0.0.1", str(management_port),
                "--redirect-gateway", "def1"
            ]

            self._logger.debug("starting openvpn client: {}".format(
                " ".join(args)))

            # start openvpn
            try:
                subprocess.check_call(args=args)
            except OSError as e:  # ie. file not found
                self.state.update(
                    new_state=VPNState.VPN_STATE_CONNECTING_FAILED)
                raise VPNConnectionError(_(str(e)))
            except CalledProcessError as e:  # return_code != 0
                self._logger.debug(str(e))
                if e.returncode == 126:  # pkexec: cancel clicked
                    message = _("Cancelled")
                    self.state.update(
                        new_state=VPNState.VPN_STATE_DISCONNECTED)
                elif e.returncode == 127:  # pkexec: 3x wrong password entered
                    message = _("Cancelled (wrong root password)")
                    self.state.update(
                        new_state=VPNState.VPN_STATE_DISCONNECTED)
                else:
                    message = _("Error: non-zero return code: {}").format(
                        e.returncode)
                    self.state.update(
                        new_state=VPNState.VPN_STATE_CONNECTING_FAILED)
                self._logger.debug(message)
                raise VPNConnectionError(message)

            # now, connect to management interface and start parser
            import time  # TODO: connect to management interface hotfix
            time.sleep(1)
            try:
                self._logger.debug("connecting to management interface")
                self.state.update(
                    new_state=VPNState.VPN_STATE_CONNECTING,
                    sub_message=_("connecting to management interface"))
                management_socket = socket.socket(
                    family=socket.AF_INET, type=socket.SOCK_STREAM)
                management_socket.connect(("127.0.0.1", management_port))
            except socket.error as e:
                self._logger.error(
                    "connecting to management interface failed: {}".format(
                        str(e)))
                message = _("connecting to management interface failed")
                self.state.update(
                    new_state=VPNState.VPN_STATE_CONNECTING_FAILED,
                    sub_message=message)
                raise VPNConnectionError(message)

            self._parser = OpenVPNManagementInterfaceParser(
                vpn_state=self.state)
            self._parser.socket = management_socket
            self._parser.on_credentials_required.connect(
                self._on_credentials_required)
            self._parser.on_invalid_credentials_detected.connect(
                self._on_invalid_credentials_detected)
            self._parser.on_log.connect(self._on_parser_log, weak=False)
            self._parser.start()

    def disconnect(self, blocking=True):
        self._logger.debug("disconnecting")

        with self._connect_disconnect_lock:

            # stop if active only
            if self.state.main_state == VPNState.VPN_STATE_DISCONNECTED:
                self._logger.debug("disconnecting: VPN is already inactive")
                raise VPNConnectionError("VPN is already inactive")

            self._parser.request_disconnect()
            self._parser.on_credentials_required.disconnect(
                self._on_credentials_required)
            self._parser.on_invalid_credentials_detected.disconnect(
                self._on_invalid_credentials_detected)
            self._parser.on_log.disconnect(self._on_parser_log)

            if blocking:
                self._parser.join(10)
                if self._parser.is_alive():
                    self._logger.error("thread didn't shut down within 10 sec")
                    if self._parser.pid is not None:
                        self._logger.debug("killing PID {}".format(
                            self._parser.pid))
                        os.kill(self._parser.pid, SIGKILL)

    def set_credentials(self, username, password):
        if self._parser is not None:
            self._parser.set_credentials(username, password)

    @staticmethod
    def _get_free_port():
        free_port = None
        for port in range(7505, 65535 + 1):
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                s.bind(("127.0.0.1", port))
                free_port = port
                s.close()
                break
            except socket.error:
                pass
        return free_port

    def is_available(self):
        return self.openvpn_config is not None \
            and self.openvpn_config.config_path is not None
