# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2014-2015 Perfect Privacy <support@perfect-privacy.com>
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License version 3, as published
# by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranties of
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR
# PURPOSE.  See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

import logging
from os.path import exists, isdir, basename, dirname, join
from os import makedirs, listdir
from gettext import gettext as _
import os.path
from zipfile import ZipFile, BadZipfile, LargeZipFile
from tempfile import mkdtemp
import shutil
from threading import Thread
import subprocess

from servergrouplistwithvpnconnection import ServerGroupListWithVPNConnection
from server import ServerWithOpenVPNConnection
from servergroup import ServerGroupWithOpenVPNConnection
from openvpnconfig import OpenVPNConfig, get_hostname_from_ovpn_file, \
    OPENVPN_PROTOCOL_UDP, OPENVPN_PROTOCOL_TCP
from perfect_privacy_api.members_area_downloader import MembersAreaDownloader
from servergrouplistwithvpnconnection import UpdateState


class NoUpdateRequiredError(Exception):
    """ There's no need to update. Configs are up to date. """


class DownloadError(Exception):
    """ Download failed """


class ServerGroupListWithOpenVPNConnection(ServerGroupListWithVPNConnection):
    """
    This class provides a server group list, extended by the ability
    to download and update the OpenVPN config files

    :type groups: list[ServerGroupWithOpenVPNConnection]
    """

    _CONFIG_NAME_MEMBERS_AREA = "VPNManager_Linux_configbundle.zip"

    def __init__(self):
        super(ServerGroupListWithOpenVPNConnection, self).__init__()
        self.groups = self.groups  # quick fix for "unresolved attribute" warning
        # FIXME
        self._logger = logging.getLogger(__name__)

        self._openvpn_protocol = None
        self.openvpn_config_dir = None
        self.main_domain = None

        # set this externally if you want to use another MembersAreaDownloader
        # for testing purposes
        self._downloader = None

        self.new_group_class = None
        self.new_server_class = None

    @property
    def openvpn_protocol(self):
        return self._openvpn_protocol

    @openvpn_protocol.setter
    def openvpn_protocol(self, protocol):
        """
        If the protocol already has been set, changing the protocol
        will result in reloading the *.ovpn config files from disk.
        :param protocol: OPENVPN_PROTOCOL_UDP or OPENVPN_PROTOCOL_TCP
        :type protocol: str
        """
        assert protocol in [OPENVPN_PROTOCOL_UDP, OPENVPN_PROTOCOL_TCP]

        previous_protocol = self._openvpn_protocol
        self._openvpn_protocol = protocol

        self._logger.debug(
            "openvpn protocol set to {}".format(protocol))

        if previous_protocol is not None and previous_protocol != protocol:
            if self.openvpn_config_dir is not None and \
                    self.main_domain is not None:
                self.load_openvpn_configs_from_dir(create_new_server=False)
            else:
                self._logger.error(
                    "don't reading config files because config_dir "
                    "or main_domain is missing")

    def load_openvpn_configs_from_dir(self,
                                      openvpn_protocol=None,
                                      openvpn_config_dir=None,
                                      main_domain=None,
                                      create_new_server=True,
                                      new_group_class=None,
                                      new_server_class=None):
        """
        Update / create server (group) objects by walking through the
        openvpn config directory and parsing all *.ovpn files.

        Set openvpn_protocol, openvpn_config_dir and main_domain first!

        Finally, remove the OpenVPN configs from the server objects that
        aren't available in the directory (assuming these configs have been
        removed and aren't available anymore).

        :param create_new_server: Whether to create new servers (groups) if they don't already exist
        :type create_new_server: bool
        :raises: DownloadError
        """

        self._logger.debug("loading openvpn config files from dir")

        if new_group_class is None:
            new_group_class = self.new_group_class
        if new_group_class is None:
            new_group_class = ServerGroupWithOpenVPNConnection

        if new_server_class is None:
            new_server_class = self.new_server_class
        if new_server_class is None:
            new_server_class = ServerWithOpenVPNConnection

        # if the params are not provided, they must have been set before
        if openvpn_protocol is None:
            assert self.openvpn_protocol is not None
        else:
            self.openvpn_protocol = openvpn_protocol

        if openvpn_config_dir is None:
            assert self.openvpn_config_dir is not None
        else:
            self.openvpn_config_dir = openvpn_config_dir

        if main_domain is None:
            assert self.main_domain is not None
        else:
            self.main_domain = main_domain

        # make sure the directory exists
        if not exists(self.openvpn_config_dir):
            makedirs(self.openvpn_config_dir)

        updated_servers = []
        for config_file_name in listdir(self.openvpn_config_dir):
            config_file_path = os.path.join(self.openvpn_config_dir,
                                            config_file_name)

            # ignore all other files (.crt etc.)
            if not config_file_name.endswith(".ovpn"):
                continue

            # make sure we have the correct config based on the protocol
            if self.openvpn_protocol == OPENVPN_PROTOCOL_UDP and \
                    not config_file_name.startswith("udp_"):
                continue
            if self.openvpn_protocol == OPENVPN_PROTOCOL_TCP and \
                    not config_file_name.startswith("tcp_"):
                continue

            # determine whether this is a single or a group config
            is_group = not (config_file_name.startswith("udp_single_")
                            or config_file_name.startswith("tcp_single"))

            # get the hostname out of the config file (this is the identifier)
            hostname = get_hostname_from_ovpn_file(config_file_path, self.main_domain)
            if not hostname:
                self._logger.error("ignoring {}: could't read host name")\
                    .format(config_file_name)
                continue

            # find server group and single server (create new if requested)
            group, single = self.find_group_and_server(
                hostname=hostname,
                is_group=is_group,
                create_new_group=create_new_server,
                create_new_single=create_new_server,
                new_group_class=new_group_class,
                new_single_class=new_server_class)

            # make sure we have a group (and a single server) now
            if is_group and group is None:
                # is_group: don't check the single server, we won't need it
                self._logger.debug("ignoring '{}' (no group found)"
                                   .format(hostname))
                continue
            if not is_group and (single is None or group is None):
                # not is_group: check the single server too!
                self._logger.debug("ignoring '{}' (couldn't find group "
                                   "and single server)".format(hostname))
                continue

            # set the openvpn config
            updating_server = group if is_group else single
            """ :type: ServerWithOpenVPNConnection """
            if updating_server.vpn_connection.openvpn_config is None:
                updating_server.vpn_connection.openvpn_config = \
                    OpenVPNConfig(config_path=config_file_path,
                                  cd=self.openvpn_config_dir,
                                  main_domain=self.main_domain)
            else:
                updating_server.vpn_connection.openvpn_config.main_domain = \
                    self.main_domain
                updating_server.vpn_connection.openvpn_config.cd = \
                    self.openvpn_config_dir
                updating_server.vpn_connection.openvpn_config.config_path = \
                    config_file_path

            # remember all updated servers for later use
            updated_servers.append(updating_server)

        # finally, remove all openvpn configs
        # from servers that haven't been updated
        for server_group in self.groups:
            server_group = server_group
            """ :type: ServerGroupWithOpenVPNConnection """

            # clear OpenVPN config of the server group
            if server_group not in updated_servers:
                server_group.vpn_connection.openvpn_config = None

            # clear OpenVPN config of the single server
            for single_server in server_group.single_servers:
                if single_server not in updated_servers:
                    single_server.vpn_connection.openvpn_config = None

        # attach signals
        self._reattach_signals()

        # debug output: print the entire server list
        debug_server_list = "current config (from openvpn config files):\n"
        for group in self.groups:
            debug_server_list = "{}{}\n".format(debug_server_list, group)
            for single in group.single_servers:
                debug_server_list = "{}  {}\n".format(debug_server_list,
                                                      single)
        self._logger.debug(debug_server_list.strip())

        return

    def _download_version(self, downloader, username, password, temp_download_dir,
                          download_file):

        # download version file
        self._logger.debug("downloading version file")
        version_path = downloader.download_from_members_area_and_save_to_file(
            username, password, "{}.version".format(download_file),
            temp_download_dir, expected_content_type='text/plain')

        # get version and sha256sum from version file
        self._logger.debug("parsing version file")
        config_version = None
        config_sha256 = None
        with open(version_path, "r") as version_file:
            for line in version_file:
                if config_version is None:
                    config_version = line.strip()
                if line.strip().startswith("sha256:"):
                    config_sha256 = line.replace("sha256:", "").strip()
        if config_version is None or config_sha256 is None:
            raise DownloadError(_("invalid version file"))
        self._logger.debug("parsing version file finished: version: {}, "
                           "sha256: {}".format(config_version, config_sha256))

        return config_version, config_sha256

    def _download_and_verify(self, downloader, username, password, temp_download_dir,
                             download_file, config_sha256):

        # download zip file
        self._logger.debug("downloading zip file")
        zip_path = downloader.download_from_members_area_and_save_to_file(
            username, password, download_file, temp_download_dir,
            expected_content_type='application/zip',
            expected_max_content_length=1024*1024*1024*5)  # max 5mb

        # verify sha256sum
        sha256_ok = downloader.verify_sha256sum(zip_path, config_sha256)
        if not sha256_ok:
            self._logger.error("sha256sum check failed!")
            raise DownloadError(
                _("Verifying the checksum failed. Please try again later."))
        self._logger.debug("sha256sum check passed")

        # download signature
        self._logger.debug("downloading signature file")
        sig_path = downloader.download_from_members_area_and_save_to_file(
            username, password, "{}.sig".format(download_file),
            temp_download_dir,
            expected_content_type='application/octet-stream')

        # verify signature
        self._logger.debug("verifying signature")
        signature_ok = downloader.verify_signature(zip_path, sig_path)
        if not signature_ok:
            self._logger.error("signature check failed!")
            raise DownloadError(
                _("Verifying the signature failed. Please try again later."))
        self._logger.debug("signature check passed")

        return zip_path

    def _unzip(self, zip_path, unzip_dir):
        self._logger.debug("unzipping '{}' to '{}'".format(zip_path, unzip_dir))
        try:
            if not exists(unzip_dir):
                makedirs(unzip_dir)
            with ZipFile(zip_path, 'r') as z:
                for filename in z.namelist():
                    # save all files into one directory (without sub dirs)
                    flattened_path = join(unzip_dir, basename(filename))
                    if isdir(flattened_path):  # ignore directories
                        continue
                    with open(flattened_path, 'w') as f:  # write file
                        f.write(z.open(filename).read())
        except BadZipfile as e:
            raise DownloadError(_("Error extracting ZIP file: {}").format(str(e)))
        except LargeZipFile as e:
            raise DownloadError(_("Error extracting ZIP file: {}").format(str(e)))
        except Exception as e:
            raise DownloadError(_("Error extracting ZIP file: {}").format(str(e)))
        self._logger.debug("unzipping done")

    def _legacy_openvpn_is_installed(self):
        try:
            proc = subprocess.Popen(["/usr/sbin/openvpn", "--version"], stdout=subprocess.PIPE)
            out, err = proc.communicate()

            min_version_parts = "2.3.3".split(".")
            openvpn_version_parts = out.decode().split("\n")[0].split(" ")[1].split(".")
            if len(openvpn_version_parts) != len(min_version_parts):
                self._logger.info("could not determine installed openvpn version: unknown version format")
            self._logger.info("required OpenVPN version: {}, installed version: {}".format(
                ".".join(min_version_parts), ".".join(openvpn_version_parts)))

            for i in range(len(min_version_parts)):
                diff = int(openvpn_version_parts[i]) - int(min_version_parts[i])
                if diff > 0:
                    self._logger.debug("installed > required")
                    return False
                if diff == 0:
                    continue
                if diff < 0:
                    self._logger.debug("installed < required")
                    return True
        except:
            self._logger.debug("error")
            return False

        self._logger.debug("installed = required")
        return False

    def _modify_configs_for_legacy_openvpn(self, path):
        self._logger.info("modifying configs for compatibility with legacy OpenVPN version")
        try:
            for file in os.listdir(path):
                if not file.endswith(".ovpn"):
                    continue
                self._logger.debug("modifying: {}".format(file))
                with open(os.path.join(path, file), "r") as f:
                    content = ""
                    content_changed = False
                    for line in f:
                        if line.startswith("ignore-unknown-option ncp-disable"):
                            content += "#" + line.rstrip() + " # disabled for compatibility with legacy OpenVPN\n"
                            content_changed = True
                        elif line.startswith("ncp-disable"):
                            content += "#" + line.rstrip() + " # disabled for compatibility with legacy OpenVPN"
                            content_changed = True
                        else:
                            content += line
                if content_changed:
                    with open(os.path.join(path, file), "w") as f:
                        f.write(content)
        except:
            pass

    def _update_configs_worker(self, username, password, create_new):
        self._logger.debug("updating openvpn configs")

        self.update_state.set(UpdateState.UPDATE_STATE_UPDATING,
                              _("Updating OpenVPN configuration files"))

        try:

            assert self.openvpn_config_dir is not None
            assert self.openvpn_protocol is not None
            assert self.main_domain is not None


            # create a temporary directory
            temp_download_dir = mkdtemp(prefix=self.main_domain + "_")
            if not exists(temp_download_dir):
                try:
                    makedirs(temp_download_dir)
                except:
                    self._logger.error("Couldn't create download directory: {}"
                                       .format(temp_download_dir))
                    raise DownloadError(_("Couldn't create download directory: {}")
                                        .format(temp_download_dir))

            # if it exists, use the downloader that was set externally
            if self._downloader is not None:
                downloader = self._downloader
            else:
                # FIXME: application name, version
                downloader = MembersAreaDownloader()

            # download version (and sha256sum)
            self.update_state.set(
                UpdateState.UPDATE_STATE_UPDATING,
                _("Looking for OpenVPN configuration updates..."))
            config_version, config_sha256 = self._download_version(
                downloader, username, password, temp_download_dir,
                self._CONFIG_NAME_MEMBERS_AREA)
            if config_version == self.config_version:
                self._logger.debug("update cancelled: already up to date")
                self.update_state.set(
                    UpdateState.UPDATE_STATE_NO_UPDATE_REQUIRED,
                    _("OpenVPN configs are already up-to-date"))
                return

            # download the config file, verify the checksum and the signature
            self.update_state.set(UpdateState.UPDATE_STATE_UPDATING,
                                  _("Getting OpenVPN configuration files"))
            zip_path = self._download_and_verify(
                downloader, username, password, temp_download_dir,
                self._CONFIG_NAME_MEMBERS_AREA, config_sha256)

            # all checks passed
            # unzip to 'configs' subdir in temporary directory
            unzip_dir = join(temp_download_dir, "configs")
            self._unzip(zip_path, unzip_dir)

            # legacy mode
            if self._legacy_openvpn_is_installed():
                self._modify_configs_for_legacy_openvpn(unzip_dir)

            self.update_state.set(UpdateState.UPDATE_STATE_UPDATING,
                                  _("Installing Update"))

            # unzipping succeeded. move the entire directory to our config dir
            if exists(self.openvpn_config_dir):
                shutil.rmtree(self.openvpn_config_dir)
            if not exists(dirname(self.openvpn_config_dir)):
                makedirs(dirname(self.openvpn_config_dir))
            shutil.move(unzip_dir, self.openvpn_config_dir)
            shutil.rmtree(temp_download_dir)  # remove temporary dir

            # update the object list
            self.load_openvpn_configs_from_dir(create_new_server=create_new)

            self.update_state.set(UpdateState.UPDATE_STATE_UPDATE_SUCCEEDED,
                                  _("OpenVPN configs up-to-date"))

        except Exception as e:
            self.update_state.set(UpdateState.UPDATE_STATE_UPDATE_FAILED,
                                  str(e))

        return

    def update_configs(self, username, password, blocking=True, create_new=True):
        """
        Download and install the OpenVPN config files and update the
        server group / single server object accordingly. If create_new is set,
        new server objects will be created if it doesn't already exist.
        Otherwise config files for new servers will be ignored.

        Finally, remove the OpenVPN configs from the server objects that
        haven't been updated (these configs have been removed and aren't
        available anymore).

        :param username: member's area user name
        :type username: basestring
        :param password: member's area password
        :type password: basestring
        :param create_new: whether to create a new server/group if it doesn't exist
        :type create_new: bool
        :raises: DownloadError
        """

        if blocking:
            self._update_configs_worker(username, password, create_new=True)
        else:
            Thread(target=self._update_configs_worker,
                   kwargs={"username": username,
                           "password": password,
                           "create_new": create_new}).start()

        return
