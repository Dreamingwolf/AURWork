# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2014-2015 Perfect Privacy <support@perfect-privacy.com>
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License version 3, as published
# by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranties of
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR
# PURPOSE.  See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

import logging

from server import Server
from servergroup import get_group_hostname, ServerGroup


class DownloadError(Exception):
    """ Download failed """


class ServerGroupList(object):
    """
    A list of server groups with basic access functionality

    :type groups: list[servergroup.ServerGroup]
    """

    def __init__(self):
        self.groups = []
        self._logger = logging.getLogger(__name__)

    def find_group_and_server(self,
                              hostname,
                              is_group,
                              create_new_group=False,
                              create_new_single=False,
                              new_group_class=ServerGroup,
                              new_single_class=Server):
        """
        Return the server group and single server objects matching the
        single_hostname. If create_new is True and the server (group)
        doesn't exist, create a new server/group of the provided types.
        In case the group is not found and couldn't be created
        (create_new_group=False), the creation of the single server
        is omitted.

        :param hostname: the hostname of the server
        :type hostname: str
        :param create_new_group: whether to create a new server group if it doesn't exist
        :type create_new_group: bool
        :param create_new_single: whether to create a new single server if it doesn't exist
        :type create_new_single: bool
        :param new_group_class: the type of the newly created server group
        :type new_group_class:
        :param new_single_class: the type of the newly created single server
        :type new_single_class:
        :return: 2-tuple (group, single), may be None if create_new is False
        :rtype: (new_group_class, new_single_class)
        """

        # find already existing server group / single server
        group = None
        single = None

        group_hostname = hostname if is_group else get_group_hostname(hostname)

        for existing_group in self.groups:
            if existing_group.hostname == group_hostname:
                group = existing_group
                for existing_single in existing_group.single_servers:
                    if existing_single.hostname == hostname:
                        single = existing_single
                        break
                break

        # create a new group if the create_new_group flag is set
        if group is None and create_new_group:
            group = new_group_class()
            group.hostname = group_hostname

            self.groups.append(group)

            self._logger.debug("created new group '{}'"
                               .format(group_hostname))

        if not is_group:
            # create a new single server if the create_new_single flag is set
            # and we have a group now
            if group is not None and single is None and create_new_single:
                single = new_single_class()
                single.hostname = hostname

                group.single_servers.append(single)

                self._logger.debug(
                    "created new single server '{}' in group '{}'"
                    .format(hostname, group.hostname))

        return group, single
