# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2014-2015 Perfect Privacy <support@perfect-privacy.com>
# This program is free software: you can redistribute it and/or modify it 
# under the terms of the GNU General Public License version 3, as published 
# by the Free Software Foundation.
# 
# This program is distributed in the hope that it will be useful, but 
# WITHOUT ANY WARRANTY; without even the implied warranties of 
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR 
# PURPOSE.  See the GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License along 
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

import logging
from blinker import Signal

from . account_settings import AccountSettings
from perfect_privacy_api import UserApiAsync
from servers.servergrouplistblends \
    import ServerGroupListWithOpenVPNAndBandwidth
from servers.server import ServerWithOpenVPNConnection
from servers.servergroup import ServerGroupWithOpenVPNConnectionAndBandwidth
from timedbandwidthupdater import TimedBandwidthUpdater


class Core(object):

    def __init__(self, account_settings_file, openvpn_config_bundle_path):

        self._logger = logging.getLogger(__name__)

        self.on_quit = Signal()

        self.settings = AccountSettings(account_settings_file)

        self.user_api_async = UserApiAsync(
            username=self.get_username(), password=self.get_password())
        self.user_api_async.on_username_password_not_set.connect(
            self._on_userapi_user_required)

        self.servergroup_list = ServerGroupListWithOpenVPNAndBandwidth()
        self.servergroup_list.on_vpn_requires_credentials.connect(
            self._on_vpn_connection_requires_credentials)
        from servers.openvpnconfig import OPENVPN_PROTOCOL_UDP
        self.servergroup_list.load_openvpn_configs_from_dir(
            openvpn_protocol=OPENVPN_PROTOCOL_UDP,
            openvpn_config_dir=openvpn_config_bundle_path,
            main_domain="perfect-privacy.com",
            create_new_server=True,
            new_group_class=ServerGroupWithOpenVPNConnectionAndBandwidth,
            new_server_class=ServerWithOpenVPNConnection)

        self.bandwidth_updater = TimedBandwidthUpdater(self.servergroup_list)
        self.bandwidth_updater.start()
        self.servergroup_list.update_state.on_change.connect(
            self._on_config_update_state_changed)

    def on_program_started(self):
        h = self.settings.get_auto_connect_hostname()
        if h:
            try:
                g, s = self.servergroup_list.find_group_and_server(hostname=h, is_group=True)
                if g:
                    self._logger.debug("auto-connecting to '{}'".format(h))
                    g.vpn_connection.connect()
                else:
                    self._logger.error("unable to auto-connect: couldn't find host '{}'".format(h))
            except:
                self._logger.error("unable to auto-connect: unknown error")

    @property
    def selected_server_list(self):
        """
        :rtype: list[servers.server.ServerWithVPNConnection]
        """
        return self.servergroup_list.groups

    def _on_vpn_connection_requires_credentials(self, sender):
        """
        :type sender: servers.vpn_connection.VPNConnection
        """
        self._logger.debug("providing credentials for {}".format(sender))
        sender.set_credentials(username=self.get_username(),
                               password=self.get_password())

    def _on_userapi_user_required(self, sender):
        self._logger.debug("received signal on_userapi_user_required")
        self.user_api_async.username = self.get_username()
        self.user_api_async.password = self.get_password()

    def _on_config_update_state_changed(self, sender):
        """
        :type sender: servers.servergrouplistwithvpnconnection.UpdateState
        """
        if sender.main_state == sender.UPDATE_STATE_UPDATE_SUCCEEDED:
            self.bandwidth_updater.update_now()

    def get_password(self):
        return self.settings.get_password()

    def set_password(self, new_password):
        if new_password != self.get_password():
            self.user_api_async.password = new_password
            self.settings.save_password(new_password)
        return

    def get_username(self):
        return self.settings.get_username()

    def set_username(self, new_username):
        if new_username != self.get_username():
            self.user_api_async.username = new_username
            self.settings.save_username(new_username)
        return

    def is_first_run(self):
        return not self.settings.config_existed_on_startup()

    def quit(self):
        """
        Shut down all connections
        """
        self.bandwidth_updater.stop()
        self.user_api_async.shutdown()
        self.servergroup_list.disconnect_all()
        self.on_quit.send(self)
