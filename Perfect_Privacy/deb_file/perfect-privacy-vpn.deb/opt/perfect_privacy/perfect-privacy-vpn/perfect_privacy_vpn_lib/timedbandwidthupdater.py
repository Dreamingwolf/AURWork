# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2014-2015 Perfect Privacy <support@perfect-privacy.com>
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License version 3, as published
# by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranties of
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR
# PURPOSE.  See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

import logging
from threading import Timer, Thread
from time import time


class TimedBandwidthUpdater(object):
    """
    :type _timer: Timer
    """
    INTERVAL_MIN = 100
    INTERVAL_MAX = 600
    INTERVAL_INC = 50

    def __init__(self, server_group_list):
        """
        :type server_group_list: servers.servergrouplistwithbandwidth.ServerGroupListWithBandwidth
        """
        self._logger = logging.getLogger(__name__)
        self._server_group_list = server_group_list
        self._timer = None
        self._current_interval = self.INTERVAL_MIN
        self.is_running = False
        self._number_of_updates = 0
        self._last_update = 0

    def _update(self):
        self._number_of_updates += 1
        self._logger.debug(
            "starting bandwidth update #{}".format(self._number_of_updates))
        self._last_update = time()
        try:
            self._server_group_list.update_bandwidth(create_new=False)
            self._logger.debug(
                "current server traffic load:\n"
                + self._server_group_list.get_bandwidth_as_string())
        except:
            pass

    def _update_timed(self):
        self._update()
        if self._number_of_updates > 4:
            self._current_interval += self.INTERVAL_INC
        self._start_timer()

    def _start_timer(self):
        # make sure there's no other timer running
        if self._timer is not None:
            self._timer.cancel()

        # start a new timer
        self._timer = Timer(self._current_interval, self._update_timed)
        self._timer.daemon = True
        self._timer.start()

        self._logger.debug(
            "next bandwidth update in {}s".format(self._current_interval))

    def reset_interval(self):
        self._logger.debug("resetting interval")

        next_update = self._last_update + self._current_interval
        remaining_time = next_update - time()
        time_since_last_update = time() - self._last_update

        self._current_interval = self.INTERVAL_MIN

        self._logger.debug(
            "interval reset to {}s ({}s elapsed since last update, "
            "remaining time: {}s)".format(self._current_interval,
                                          time_since_last_update,
                                          remaining_time))

        if time_since_last_update > self.INTERVAL_MIN:
            self._logger.debug(
                "bandwidth information is outdated, starting update")
            self._cancel_timer()
            self._start_now()

    def _start_now(self):
        # update immediately
        t = Thread(target=self._update)
        t.daemon = True
        t.start()

        # start the timer
        self._start_timer()

    def start(self):
        self._logger.debug("starting")
        if self.is_running:
            self._logger.debug("already running")
            return

        self.is_running = True

        self._current_interval = self.INTERVAL_MIN
        self._start_now()

    def update_now(self):
        self._logger.debug("force-update now")
        self._cancel_timer()
        self._start_now()

    def _cancel_timer(self):
        if self._timer is not None:
            self._timer.cancel()
            self._timer = None

    def stop(self):
        self._logger.debug("stopping")
        self._cancel_timer()
        self._number_of_updates = 0
        self.is_running = False
        self._logger.debug("bandwidth updater stopped")

    def __del__(self):
        self.stop()
