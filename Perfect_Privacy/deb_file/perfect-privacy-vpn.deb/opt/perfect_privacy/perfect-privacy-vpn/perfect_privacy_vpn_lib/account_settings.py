# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2014-2015 Perfect Privacy <support@perfect-privacy.com>
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License version 3, as published
# by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranties of
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR
# PURPOSE.  See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

from os.path import exists, dirname
from os import mkdir
import os
import json
import logging
from gettext import gettext as _

from blinker import Signal


class SettingsWriteError(Exception):
    """ Writing settings to file failed """


class SettingsReadError(Exception):
    """ Reading settings from file failed """


class AccountSettings(object):
    _CONFIG_VERSION = 1.1

    def __init__(self, config_file):
        """
        Constructor
        @param config_file: the file to read the config from
        @raise SettingsReadError: if reading failed
        """

        self._logger = logging.getLogger(__name__)

        self._config_file = config_file

        self._config_existed_on_startup = exists(self._config_file)

        self._config = {}
        self._read_config_from_file()

        self.on_change = Signal()

        return

    def _read_config_from_file(self):
        """
        Read configuration from self._config_file to self._config
        """

        # default base config
        default_config = {
            u"config_version": self._CONFIG_VERSION,
            u"login": {
                u"username": u"",
                u"password": u"",
                # u"store_password": False
            },
            u"enable_tray_icon": True,
            u"auto_connect_hostname": "",
        }

        # read config from file
        try:
            with open(self._config_file, "r") as f:
                saved_config = json.load(f)
                self._merge_dict(default_config, saved_config)
                self._config = saved_config
        except:
            self._config = default_config
            self._write_config_to_file()

    def _merge_dict(self, tool_dict, target_dict):
        """
        Recursively merge dict
        @param tool_dict: dict
        @param target_dict: dict
        """

        for i in tool_dict.iterkeys():
            if i not in target_dict:
                target_dict[i] = tool_dict[i]
                continue

            # if value is a dict, check that dict recursively
            if type(tool_dict[i]) == dict:
                self._merge_dict(tool_dict[i], target_dict[i])

    def _write_config_to_file(self):
        """
        Write configuration to self._config_file
        @raise SettingsWriteError: if writing file failed
        """

        try:
            # create new config directory if it doesn't exists
            if not exists(dirname(self._config_file)):
                mkdir(dirname(self._config_file))

            # write config to file (pretty)
            with os.fdopen(os.open(self._config_file, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600), "w") as f:
                json.dump(self._config, f, sort_keys=True, indent=4, separators=(',', ': '))

        except Exception as e:
            raise SettingsWriteError(_("Writing settings failed: {}".format(str(e))))

        return

    def get_username(self):
        """
        @return: the username stored in the config file, may be empty
        @rtype: basestring
        """
        assert isinstance(self._config["login"]["username"], basestring)
        return self._config["login"]["username"]

    def save_username(self, username):
        """
        Save the username to config
        @param username: the new username
        @type username: basestring
        @raise SettingsWriteError: if writing file failed
        """
        assert isinstance(username, basestring)
        self._config["login"]["username"] = unicode(username)
        self._write_config_to_file()
        self.on_change.send(self)

    def get_password(self):
        """
        @return: the password stored in the config file, may be empty
        @rtype: basestring
        """
        assert isinstance(self._config["login"]["password"], basestring)
        return self._config["login"]["password"]

    def save_password(self, password):
        """
        Save the password to config if store password is set
        Else save an empty string
        @param password: the new password
        @type password: basestring
        @raise SettingsWriteError: if writing file failed
        """
        assert isinstance(password, basestring)
        # if not self._config["login"]["store_password"]:
        #    password = ""
        self._config["login"]["password"] = unicode(password)
        self._write_config_to_file()
        self.on_change.send(self)

    def get_enable_tray_icon(self):
        return True if self._config["enable_tray_icon"] else False

    def save_enable_tray_icon(self, enable_tray_icon):
        self._config["enable_tray_icon"] = True if enable_tray_icon else False
        self._write_config_to_file()
        self.on_change.send(self)

    def get_auto_connect_hostname(self):
        h = self._config["auto_connect_hostname"]
        return h if h else None

    def save_auto_connect_hostname(self, hostname):
        self._config["auto_connect_hostname"] = hostname if hostname else ""
        self._write_config_to_file()
        self.on_change.send()

    # def get_store_password(self):
    #     """
    #     @return: whether to store the password in the config file
    #     @rtype: bool
    #     """
    #     assert isinstance(self._config["login"]["store_password"], bool)
    #     return self._config["login"]["store_password"]
    #
    # def save_store_password(self, store_password, password=""):
    #     """
    #     Save the store password setting to config and clear the password if it is set to False
    #     @param store_password: whether to store the password in the config file
    #     @type store_password: bool
    #     @param password: at least if store_password is True, specify password too
    #     @type password: basestring
    #     @raise SettingsWriteError: if writing file failed
    #     """
    #     assert isinstance(store_password, bool)
    #     assert isinstance(password, basestring)
    #
    #     password = unicode(password)
    #     if not store_password:
    #         password = u""
    #     self._config["login"]["password"] = password
    #     self._config["login"]["store_password"] = store_password
    #     self._write_config_to_file()
    #     return

    def config_existed_on_startup(self):
        """
        @return: whether the configuration file existed on application startup
        @rtype: bool
        """
        return self._config_existed_on_startup
