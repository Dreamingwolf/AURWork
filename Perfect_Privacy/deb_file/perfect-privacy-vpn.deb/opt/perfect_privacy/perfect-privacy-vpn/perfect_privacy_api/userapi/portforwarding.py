# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2014-2015 Perfect Privacy <support@perfect-privacy.com>
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License version 3, as published
# by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranties of
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR
# PURPOSE.  See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

import logging
from datetime import datetime


class PortForwarding(object):

    @staticmethod
    def is_complete(pf_id, server_group_name,
                    src_port, dest_port, valid_until):

        logger = logging.getLogger(__name__)
        logger.debug(
            "checking whether port forwarding is complete "
            "(id='%s', server_group_name='%s', src_port='%s', "
            "dest_port='%s', valid_until='%s')",
            pf_id, server_group_name, src_port,
            dest_port, valid_until)

        try:
            logger.debug("  checking server_group_name")
            assert isinstance(server_group_name, basestring)
            # noinspection PyTypeChecker
            assert len(server_group_name) > 0
        except AssertionError:
            logger.debug("  -> not a string or empty")
            return False

        try:
            logger.debug("  checking pf_id: %s", pf_id)
            int(pf_id)
        except (ValueError, TypeError):
            logger.debug("  -> not an int")
            return False

        try:
            logger.debug("  checking src_port: %s", src_port)
            assert 1 <= int(src_port) <= 65535
        except (ValueError, TypeError):
            logger.debug("  -> not an int")
            return False
        except AssertionError:
            logger.debug("  -> not a valid port number")
            return False

        try:
            logger.debug("  checking dest_port: %s", dest_port)
            assert 1 <= int(dest_port) <= 65535
        except (ValueError, TypeError):
            logger.debug("  -> not an int")
            return False
        except AssertionError:
            logger.debug("  -> not a valid port number")
            return False

        try:
            logger.debug("  checking valid_until: %s", valid_until)
            assert isinstance(valid_until, datetime)
        except AssertionError:
            logger.debug("  -> not a datetime")
            return False

        logger.debug("complete")
        return True

    def __init__(self, pf_id=None, server_group_name="",
                 src_port=None, dest_port=None, valid_until=None):
        """
        :param pf_id:
        :type pf_id: int
        :param server_group_name:
        :type server_group_name: basestring
        :param src_port:
        :type src_port: int
        :param dest_port:
        :type dest_port: int
        :param valid_until:
        :type valid_until: datetime
        :raise ValueError:
        """

        self._logger = logging.getLogger(__name__)

        if pf_id is not None:
            self.pf_id = int(pf_id)
        else:
            self.pf_id = None

        self.server_group_name = server_group_name

        if src_port is not None:
            self.src_port = int(src_port)
        else:
            self.src_port = None

        if dest_port is not None:
            self.dest_port = int(dest_port)
        else:
            self.dest_port = None

        self.valid_until = valid_until

        return

    def __cmp__(self, other):
        assert isinstance(other, PortForwarding)

        if self.pf_id == other.pf_id \
                and self.server_group_name == other.server_group_name \
                and self.src_port == other.src_port \
                and self.dest_port == other.dest_port \
                and self.valid_until == other.valid_until:

            return 0
        else:
            return -1 if self.dest_port < other.dest_port else 1

    def __repr__(self):
        return "<PortForwarding " \
               "(id: '{id}', server_group: '{server_group}', " \
               "src_port: '{src_port}', dest_port: '{dest_port}', " \
               "valid_until: '{valid_until}')>".format(
                   id=self.pf_id, server_group=self.server_group_name,
                   src_port=self.src_port, dest_port=self.dest_port,
                   valid_until=self.valid_until)
