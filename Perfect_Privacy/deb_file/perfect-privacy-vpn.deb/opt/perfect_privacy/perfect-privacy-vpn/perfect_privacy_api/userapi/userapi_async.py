# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2014-2015 Perfect Privacy <support@perfect-privacy.com>
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License version 3, as published
# by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranties of
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR
# PURPOSE.  See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

import sys
import traceback
from blinker import Signal
from userapi import UserApi
from exceptions import UserApiError, UsernamePasswordNotSetError, LoginError, \
    UserApiNetworkError
from threading import Thread, RLock, Event
from Queue import Queue


class UserApiAsync(UserApi):

    class Task(object):
        def __init__(self):
            self.method = None
            self.args = None
            return

        def __repr__(self):
            return "<Task (method: {}, args: {})>".format(
                self.method, self.args)

    def __init__(self, username=None, password=None):
        if username == "":
            username = None
        if password == "":
            password = None

        self.on_operating_started = Signal()
        self.on_operating_ended = Signal()
        self.on_operating_failed = Signal()
        self.operating = False
        self._operating_lock = RLock()

        self.on_data_becomes_available = Signal()
        self.on_data_becomes_unavailable = Signal()

        self.on_username_password_not_set = Signal()
        self._username_password_set = Event()
        self.on_username_password_wrong = Signal()

        self.on_valid_until_changed = Signal()
        self.on_random_exit_changed = Signal()
        self.on_default_port_forwarding_changed = Signal()
        self.on_auto_renew_port_forwarding_changed = Signal()
        self.on_custom_port_forwardings_changed = Signal()
        self.on_server_groups_changed = Signal()

        self._queue_is_unlocked_event = Event()
        self._queue_is_unlocked_event.set()  # unlock queue by default
        self._queue = Queue()

        super(UserApiAsync, self).__init__(username, password)
        self._logger.name = __name__  # override logger name

        self._running = True
        self._worker_thread = Thread(target=self._worker)
        self._worker_thread.daemon = True
        self._worker_thread.start()

        return

    def _send_signal(self, signal, **kwargs):
        # noinspection PyBroadException
        try:
            signal.send(self, **kwargs)
        except:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            tb = traceback.format_exception(exc_type, exc_value,
                                            exc_traceback, limit=2)
            self._logger.error("Error sending signal '{signal_name}'."
                               "This should never happen! "
                               "Stack trace: {stacktrace}"
                               .format(signal_name=str(signal),
                                       stacktrace=tb))
        return

    def _worker(self):
        """
        Worker thread waiting for Task items in self._queue
        sends on_operating_started signal
            when items in queue are being processed
        sends on_operating_ended signal
            when all items in queue are processed
        """
        while self._running:
            task = self._queue.get(block=True, timeout=None)
            if not task:
                continue

            self._queue_is_unlocked_event.wait()
            if not self._running:
                continue

            with self._operating_lock:
                prev_operating = self.operating
                self.operating = True

            if not prev_operating:
                self._logger.debug("operating started")
                self._send_signal(self.on_operating_started)

            self._logger.debug("start processing task: {task}".format(
                task=task))
            try:
                if task.args is ():
                    task.method()
                else:
                    task.method(*task.args)
            except:
                exc_type, exc_value, exc_traceback = sys.exc_info()
                tb = traceback.format_exception(exc_type, exc_value,
                                                exc_traceback, limit=2)
                self._logger.error("Error executing task: {stacktrace}"
                                   .format(stacktrace=tb))
            finally:
                self._queue.task_done()
                if self._queue.empty():
                    with self._operating_lock:
                        self.operating = False
                    self._logger.debug("operating ended")
                    self._send_signal(self.on_operating_ended)

    def _add_task(self, method, *args):
        new_task = self.Task()
        new_task.method = method
        new_task.args = args

        self._logger.debug("adding task to queue: {}".format(new_task))

        self._queue.put(new_task)
        return

    def _clear_queue(self):
        self._logger.debug("clearing queue")
        while not self._queue.empty():
            self._queue.get(block=True, timeout=None)
        self._logger.debug("queue successfully cleared")

    def _communicate(self, payload):
        prev_data_is_available = self._data_is_available

        if payload == {} and self._data_is_available:
            # normal update >= #1
            changed_by_request = False
        else:
            changed_by_request = True

        monitored_vars = [
            {
                "var": "_valid_until",
                "changed": self.on_valid_until_changed,
            },
            {
                "var": "_random_exit",
                "changed": self.on_random_exit_changed
            },
            {
                "var": "_default_port_forwarding",
                "changed": self.on_default_port_forwarding_changed
            },
            {
                "var": "_auto_renew_port_forwarding",
                "changed": self.on_auto_renew_port_forwarding_changed
            },
            {
                "var": "_custom_port_forwardings",
                "changed": self.on_custom_port_forwardings_changed
            }
        ]

        # save previous values
        for monitored_var in monitored_vars:
            monitored_var["prev"] = getattr(self, monitored_var["var"])

        # make sure username and password are set
        if self._username is None or self._password is None \
                or len(self._username) <= 0 or len(self._password) <= 0:
            self._send_signal(self.on_username_password_not_set)
            self._username_password_set.wait()

        # communicate
        content = ""
        # max_number_of_tries = 3
        # number_of_tries = 2
        # while number_of_tries < max_number_of_tries:
        #     number_of_tries += 1
        try:
            content = super(UserApiAsync, self)._communicate(payload)
            # break
        # except LoginError:
        #     self._logger.info("username or password wrong")
        #     self._send_signal(self.on_username_password_wrong)
        #     break
        except UsernamePasswordNotSetError:
            self._logger.info("username or password not set. waiting ...")
            self._send_signal(self.on_username_password_not_set)
            self._username_password_set.wait()
            self._logger.info("... username and password set.")
            # continue
        except UserApiNetworkError as e:
            self._data_is_available = False
        except UserApiError as e:
            # self._logger.info("try #{no}, communicating failed: {msg}"
            #                   .format(no=number_of_tries, msg=e))
            self._logger.info("communicating failed: {msg}"
                              .format(msg=e))
        except:
            # self._logger.error("unexpected exception, try #{no}, "
            #                    "communicating failed: {msg}"
            #                    .format(no=number_of_tries,
            #                            msg=sys.exc_info()[0]))
            self._logger.error("unexpected exception, "
                               "communicating failed: {msg}"
                               .format(msg=sys.exc_info()[0]))
            # sleep(3)

        # send changed signals if any monitored variable changed
        for monitored_var in monitored_vars:
            new_value = getattr(self, monitored_var["var"])
            if not new_value == monitored_var["prev"]:
                self._logger.debug("{} changed from {} to {} {}".format(
                    monitored_var["var"], monitored_var["prev"], new_value,
                    "by request" if changed_by_request
                    else "by external change"))
                self._send_signal(monitored_var["changed"],
                                  new_value=new_value,
                                  by_request=changed_by_request)

        if not self._data_is_available == prev_data_is_available:
            self._logger.debug("data_is_available: {} -> {}".format(
                prev_data_is_available, self._data_is_available))
            if self._data_is_available:
                self._send_signal(self.on_data_becomes_available)
            else:
                self._send_signal(self.on_data_becomes_unavailable)

        return content

    def _reset(self):
        # noinspection PyProtectedMember
        super(UserApiAsync, self)._reset()

        self._send_signal(self.on_data_becomes_unavailable)

        self._send_signal(self.on_valid_until_changed,
                          new_value=self._valid_until,
                          by_request=True)
        self._send_signal(self.on_random_exit_changed,
                          new_value=self._random_exit,
                          by_request=True)
        self._send_signal(self.on_default_port_forwarding_changed,
                          new_value=self._default_port_forwarding,
                          by_request=True)
        self._send_signal(self.on_auto_renew_port_forwarding_changed,
                          new_value=self._auto_renew_port_forwarding,
                          by_request=True)
        self._send_signal(self.on_custom_port_forwardings_changed,
                          new_value=self._custom_port_forwardings,
                          by_request=True)
        return

    def request_update(self):
        # add update task
        if self._should_update():
            # only if timeout exceeded or no data available
            if self._queue.empty():
                # only if queue is empty
                # other tasks will update automatically
                self._add_task(self._update)
        return

    @property
    def api_calls_blocked(self):
        return not self._queue_is_unlocked_event.is_set()

    @api_calls_blocked.setter
    def api_calls_blocked(self, value):
        if value:
            self._queue_is_unlocked_event.clear()
        else:
            self._queue_is_unlocked_event.set()

    @property
    def username(self):
        return self._username

    @username.setter
    def username(self, value):
        if value == self._username:
            return
        self._logger.debug("new username set")

        self._clear_queue()

        if value == "":
            value = None
        self._reset()
        self._username = value
        if self._username is not None and self._password is not None\
                and self._queue.empty():
            self._username_password_set.set()
            self._add_task(self._update)
        else:
            self._username_password_set.clear()

    @property
    def password(self):
        return self._password

    @password.setter
    def password(self, value):
        if value == self._password:
            return
        self._logger.debug("new password set")

        self._clear_queue()

        if value == "":
            value = None
        self._reset()
        self._password = value
        if self._username is not None and self._password is not None\
                and self._queue.empty():
            self._username_password_set.set()
            self._add_task(self._update)
        else:
            self._username_password_set.clear()

    def force_update(self):
        if self._username is not None and self._password is not None:
            self._logger.debug("force update")
            self._add_task(self._update)
        else:
            self._logger.debug("ignoring force update (no username/password)")

    @property
    def random_exit(self):
        """
        Get or set whether to use a random exit IP address.

        If the API has not been accessed yet or the last update
        is longer than max_cache_time ago, this will asynchronously
        access the API.

        It will return the current known state immediately and possibly
        fire an on_random_exit_changed signal later.

        :return: whether to use a random exit IP address
        :rtype: bool or None
        """
        self.request_update()
        return self._random_exit

    @UserApi.random_exit.setter
    def random_exit(self, value):
        def set_random_exit(new_value):
            UserApi.random_exit.fset(self, new_value)
        self._add_task(set_random_exit, value)

    @property
    def default_port_forwarding(self):
        """
        Get or set whether to use default port forwarding.

        If the API has not been accessed yet or the last update
        is longer than max_cache_time ago, this will asynchronously
        access the API.

        It will return the current known state immediately and possibly
        fire an on_default_port_forwarding_changed signal later.

        :return: whether to use default port forwarding
        :rtype: bool or None
        """
        self.request_update()
        return self._default_port_forwarding

    @UserApi.default_port_forwarding.setter
    def default_port_forwarding(self, value):
        def set_default_port_forwarding(new_value):
            UserApi.default_port_forwarding.fset(self, new_value)
        self._add_task(set_default_port_forwarding, value)

    @property
    def auto_renew_port_forwarding(self):
        """
        Get or set whether to auto-renew port forwarding.

        If the API has not been accessed yet or the last update
        is longer than max_cache_time ago, this will asynchronously
        access the API.

        It will return the current known state immediately and possibly
        fire an on_auto_renew_port_forwarding_changed signal later.

        :return: whether to auto-renew port forwarding
        :rtype: bool or None
        """
        self.request_update()
        return self._auto_renew_port_forwarding

    @UserApi.auto_renew_port_forwarding.setter
    def auto_renew_port_forwarding(self, value):
        def set_auto_renew_port_forwarding(new_value):
            UserApi.auto_renew_port_forwarding.fset(self, new_value)
        self._add_task(set_auto_renew_port_forwarding, value)

    @property
    def custom_port_forwardings(self):
        """
        Get all custom port forwardings as list. List may be empty or None.

        If the API has not been accessed yet or the last update
        is longer than max_cache_time ago, this will asynchronously
        access the API.

        It will return the current known state immediately and possibly
        fire an on_custom_port_forwardings_changed signal later.

        :return: all custom port forwardings
        :rtype: list of PortForwarding or None
        """
        self.request_update()
        return self._custom_port_forwardings

    def add_custom_port_forwarding(self, port_forwarding):
        def add(custom_port_forwarding):
            super(UserApiAsync, self).add_custom_port_forwarding(
                custom_port_forwarding)
        self._add_task(add, port_forwarding)

    def delete_custom_port_forwarding(self, port_forwardings):
        def delete(custom_port_forwarding):
            super(UserApiAsync, self).delete_custom_port_forwarding(
                custom_port_forwarding)
        self._add_task(delete, port_forwardings)

    def delete_all_custom_port_forwardings(self):
        def delete_all():
            super(UserApiAsync, self).delete_custom_port_forwarding(
                self._custom_port_forwardings)
        self._add_task(delete_all)

    @property
    def server_groups(self):
        self.request_update()
        return sorted(self._server_groups.keys())

    def shutdown(self):
        self._running = False
        self._queue.put(None)  # release blocking get()
        self._queue_is_unlocked_event.set()
        self._worker_thread.join(timeout=10)
        if self._worker_thread.is_alive():
            self._logger.error("shutting down gracefully failed")
