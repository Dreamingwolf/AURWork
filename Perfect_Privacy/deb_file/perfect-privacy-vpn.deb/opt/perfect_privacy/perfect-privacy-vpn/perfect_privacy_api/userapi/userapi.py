# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2014-2015 Perfect Privacy <support@perfect-privacy.com>
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License version 3, as published
# by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranties of
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR
# PURPOSE.  See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

import logging
from datetime import datetime, timedelta
import requests
import json

from portforwarding import PortForwarding
from exceptions import \
    UserApiError, UserApiMalfunctionError, UsernamePasswordNotSetError, \
    LoginError, InvalidCharsInUsernameError, ExpiredError, DisabledError, \
    UserApiCallLimitError, NotAnIPAddressError, UserApiNetworkError

from gettext import gettext as _


class UserApi(object):
    """
    This class communicates with the Perfect Privacy User API.

    The Perfect Privacy User API is intended for getting
    user account information such as expiration date and
    setting user related settings like port forwarding and
    whether to use random exit IP address or default port forwarding.
    """

    def __init__(self, username=None, password=None):
        """
        :param username: Perfect Privacy user name
        :type username: basestring
        :param password: Perfect Privacy password
        :type password: basestring
        """

        self._logger = logging.getLogger(__name__)

        self.max_cache_time = timedelta(seconds=10)
        """ cache time. use force_update() to update immediately. """

        self.base_url = "https://www.perfect-privacy.com/api/user.php"
        """ the base URL used by all API calls """

        self.request_timeout = 10.0
        """ the request timeout in seconds """

        self._username = username
        self._password = password

        self.last_update = None

        self._data_is_available = False

        self._valid_until = None
        self._random_exit = None
        self._default_port_forwarding = None
        self._auto_renew_port_forwarding = None
        self._custom_port_forwardings = None
        """ @type: list of PortForwarding """

        self._server_groups = {}

        return

    def _reset(self):
        self._logger.debug("resetting all values")

        self._data_is_available = False

        self.last_update = None

        self._valid_until = None
        self._random_exit = None
        self._default_port_forwarding = None
        self._auto_renew_port_forwarding = None
        self._custom_port_forwardings = None

        self._server_groups = {}
        return

    def _should_update(self):
        any_setting_not_set = \
            self._valid_until is None \
            or self._random_exit is None \
            or self._default_port_forwarding is None \
            or self._auto_renew_port_forwarding is None \
            or self._custom_port_forwardings is None

        max_cache_time_exceeded = \
            self.last_update is None \
            or self.last_update + self.max_cache_time < datetime.now()

        self._logger.debug(
            "should update: %s%s%s",
            "yes" if any_setting_not_set or max_cache_time_exceeded else "no",
            ", any setting not set" if any_setting_not_set else "",
            ", max cache time exceeded" if max_cache_time_exceeded else "")

        return any_setting_not_set or max_cache_time_exceeded

    def _update(self):
        self._logger.debug("updating")
        self._communicate({})
        return

    def _communicate(self, payload):
        """

        :param payload: dict of additional GET payload
        :type payload: dict
        :return: the response as text
        :rtype: basestring
        :raise UsernamePasswordNotSetError: username or password not set
        :raise LoginError: login failed
        :raise InvalidCharsInUsernameError: invalid chars in username
        :raise ExpiredError: account expired
        :raise DisabledError: account disabled
        :raise UserApiCallLimitError: API call limit exceeded
        :raise UserApiMalfunctionError: API doesn't work
        :raise UserApiError: network errors, other errors
        """
        self._logger.debug("communicating, payload: %s", payload)
        if self._username is None or self._password is None:
            raise UsernamePasswordNotSetError(
                _("Username or password not set"))

        payload["username"] = self._username
        payload["password"] = self._password
        payload["getServerGroups"] = ""

        try:
            response = requests.post(self.base_url, data=payload,
                                     timeout=self.request_timeout)
        except requests.ConnectionError:
            self._logger.error("network problem")
            raise UserApiNetworkError(_("network problem"))
        except requests.HTTPError:
            self._logger.error("invalid HTTP response")
            raise UserApiMalfunctionError(_("invalid HTTP response"))
        except requests.Timeout:
            self._logger.error("request timeout")
            raise UserApiNetworkError(_("request timeout"))
        except requests.TooManyRedirects:
            self._logger.error("too many redirects")
            raise UserApiMalfunctionError(_("too many redirects"))
        except requests.RequestException as error:
            raise UserApiError("{}".format(error.strerror))

        if response.status_code != 200:
            self._logger.error("wrong status code: %s", response.status_code)
            raise UserApiMalfunctionError(
                _("wrong status code: {}").format(response.status_code))

        # FIXME: User API should return application/json
        # ("content-type" in r.headers
        # and r.headers["content-type"] == "application/json"):
        if not response.content.startswith("{"):
            self._logger.error("invalid response: doesn't start with '{'")
            raise UserApiMalfunctionError(_("invalid response"))
        try:
            response_dict = json.loads(response.content)
        except:
            self._logger.error("invalid response: couldn't be parsed as JSON")
            raise UserApiError(_("invalid response"))

        self._response_check_error(response_dict)

        self._response_check_complete(response_dict)

        self._server_groups = \
            self._response_get_server_groups(payload, response_dict)

        port_forwardings = self._response_get_port_forwardings(response_dict)

        try:
            valid_until = datetime.strptime(
                response_dict["validUntil"], "%Y-%m-%d %H:%M:%S")
        except ValueError:
            self._logger.error(
                "invalid response: wrong validUntil date format "
                "for account expiration date, "
                "expected format: '" + r"%Y-%m-%d %H:%M:%S" + "' but got '%s'",
                response_dict["validUntil"])
            raise UserApiMalfunctionError(
                _("invalid response: wrong date format"))

        random_exit = response_dict["randomExit"] == "1"
        default_port_forwarding = response_dict["defaultPortForwarding"] == "1"
        auto_renew_port_forwarding = response_dict["autorenew_pf"] == "1"

        # everything went fine, let's save it
        self._valid_until = valid_until
        self._random_exit = random_exit
        self._default_port_forwarding = default_port_forwarding
        self._auto_renew_port_forwarding = auto_renew_port_forwarding
        self._custom_port_forwardings = port_forwardings

        self.last_update = datetime.now()

        self._data_is_available = True

        return response.content

    def _response_check_error(self, response_dict):
        """
        Check the "error" field of the response and raise exceptions.
        :param response_dict: the response dictionary (from json)
        :raise LoginError:
        :raise InvalidCharsInUsernameError:
        :raise ExpiredError:
        :raise DisabledError:
        :raise ApiCallLimitError:
        :raise ApiError: unknown error
        """
        if "error" in response_dict:
            if response_dict["error"] == "errorUsernamePassword":
                self._logger.warning("login failed")
                raise LoginError(
                    _("Login failed: "
                      "Double-check username and password and try again."))
            elif response_dict["error"] == "errorInvalidchars":
                self._logger.warning("login failed: invalid chars in username")
                raise InvalidCharsInUsernameError(
                    _("Login failed: Invalid characters in username"))
            elif response_dict["error"] == "errorExpired":
                self._logger.warning("account expired")
                raise ExpiredError(
                    _("Login failed: Your account has expired!"))
            elif response_dict["error"] == "errorDisabled":
                self._logger.warning("account disabled")
                raise DisabledError(
                    _("Login failed: Your account has been disabled. "
                      "You may know why."))
            elif response_dict["error"] == "errorApiCallLimit":
                self._logger.warning("API call limit exceeded")
                raise UserApiCallLimitError(
                    _("API call limit exceeded! Please try again later."))
            else:
                self._logger.error(
                    "unknown error: '%s'", response_dict["error"])
                raise UserApiError(
                    _("Unknown error: {}").format(response_dict["error"]))

    def _response_check_complete(self, response_dict):
        """
        Check whether the response is complete
        :param response_dict: the response dictionary (from json)
        :raise UserApiMalfunctionError: if response is incomplete
        """
        expected_keys = [
            "validUntil",
            "randomExit",
            "defaultPortForwarding",
            "autorenew_pf",
            "customPorts"
        ]
        bool_keys = [
            "randomExit",
            "defaultPortForwarding",
            "autorenew_pf"
        ]

        all_expected_keys_in_response = len(response_dict) > 0
        for expected_key in expected_keys:
            if not expected_key in response_dict:
                all_expected_keys_in_response = False
                self._logger.error("incomplete response: '%s' expected")
        if not all_expected_keys_in_response:
            raise UserApiMalfunctionError(_("incomplete response"))

        all_expected_bool_keys_bool = len(response_dict) > 0
        for bool_key in bool_keys:
            if response_dict[bool_key] not in ["1", "0"]:
                all_expected_bool_keys_bool = False
                self._logger.error("invalid response: '%s' was expected to be "
                                   "'0' or '1' but was '%s'",
                                   bool_key, response_dict[bool_key])
        if not all_expected_bool_keys_bool:
            raise UserApiMalfunctionError(_("invalid response"))
        return

    def _response_get_server_groups(self, payload, response_dict):
        """

        :param payload: the payload sent to the API
        :param response_dict: the response dictionary (from json)
        :return: the server groups dict
        :rtype: dict
        :raise UserApiMalfunctionError: if a server group is incomplete
            or no server groups provided
        """
        new_server_groups = {}
        if "getServerGroups" in payload:
            if not "serverGroups" in response_dict:
                self._logger.error("API didn't return server groups")
                raise UserApiMalfunctionError(_("didn't return server groups"))
            for server_group in response_dict["serverGroups"]:
                if "id" not in server_group or "name" not in server_group:
                    self._logger.error("server group '%s' incomplete, "
                                       "response was: '%s' ",
                                       server_group, response_dict)
                    raise UserApiMalfunctionError(_("server group incomplete"))
                new_server_groups[server_group["name"]] = server_group["id"]
        return new_server_groups

    def _response_get_port_forwardings(self, response_dict):
        """
        :param response_dict:
        :return:
        :rtype:
        :raise UserApiMalfunctionError: invalid/incomplete response
        :raise UserApiError: unknown error
        """
        port_forwardings = []

        for port_forwarding in response_dict["customPorts"]:
            # check whether all expected keys are available
            expected_keys = [
                "id",
                "serverGroupId",
                "srcPort",
                "destPort",
                "validUntil"
            ]
            all_expected_keys_in_response = len(port_forwarding) > 0
            for expected_key in expected_keys:
                if expected_key not in port_forwarding:
                    self._logger.error(
                        "expected key '%s' not in port forwarding '%s'",
                        expected_key, port_forwarding)
                    all_expected_keys_in_response = False
            if not all_expected_keys_in_response:
                raise UserApiMalfunctionError(_("incomplete response"))

            # get server group name from saved server group list by id
            try:
                server_group_name = self._server_groups.keys()[
                    self._server_groups.values().index(
                        port_forwarding["serverGroupId"])]
            except ValueError:
                raise UserApiMalfunctionError(_("unknown server group id"))

            # convert validUntil
            try:
                valid_until = datetime.strptime(
                    port_forwarding["validUntil"], "%Y-%m-%d %H:%M:%S")
            except ValueError:
                self._logger.error(
                    "invalid response: wrong validUntil date format "
                    "for port forwarding '%s', "
                    "expected format: '" + r"%Y-%m-%d %H:%M:%S" +
                    "' but got '%s'",
                    response_dict["validUntil"])
                raise UserApiMalfunctionError(
                    _("invalid response: wrong date format"))

            # get the other values
            pf_id = port_forwarding["id"]
            src_port = port_forwarding["srcPort"]
            dest_port = port_forwarding["destPort"]

            # check whether new port forwarding is complete
            if not PortForwarding.is_complete(
                    pf_id=pf_id,
                    server_group_name=server_group_name,
                    src_port=src_port,
                    dest_port=dest_port,
                    valid_until=valid_until):
                self._logger.error("port forwarding is incomplete: '%s'",
                                   port_forwarding)
                raise UserApiMalfunctionError(
                    _("returned port forwarding is incomplete"))

            # create new port forwarding object
            try:
                port_forwardings.append(PortForwarding(
                    pf_id=pf_id,
                    server_group_name=server_group_name,
                    src_port=src_port,
                    dest_port=dest_port,
                    valid_until=valid_until))
            except ValueError as error:
                self._logger.error(
                    "unexpected error creating port forwarding: '%s'",
                    error)
                raise UserApiError(error.message)

        return port_forwardings

    def force_update(self):
        """
        Update now

        :raise UsernamePasswordNotSetError: username or password not set
        :raise LoginError: login failed
        :raise InvalidCharsInUsernameError: invalid chars in username
        :raise ExpiredError: account expired
        :raise DisabledError: account disabled
        :raise UserApiCallLimitError: API call limit exceeded
        :raise UserApiMalfunctionError: API doesn't work
        :raise UserApiError: network errors, other errors
        """
        self._logger.debug("force update")
        self._update()
        return

    @property
    def data_is_available(self):  # read-only
        return self._data_is_available

    @property
    def username(self):
        """
        Get or set username.

        Setting the username resets all settings. If username and password
        are not None, the settings will automatically be updated.

        :raise UsernamePasswordNotSetError: username or password not set
        :raise LoginError: login failed
        :raise InvalidCharsInUsernameError: invalid chars in username
        :raise ExpiredError: account expired
        :raise DisabledError: account disabled
        :raise UserApiCallLimitError: API call limit exceeded
        :raise UserApiMalfunctionError: API doesn't work
        :raise UserApiError: network errors, other errors
        :return: username
        :rtype: basestring
        """
        return self._username

    @username.setter
    def username(self, value):
        if value == self._username:
            return
        self._logger.debug("new username set")
        if value == "":
            value = None
        self._reset()
        self._username = value
        if self.username is not None and self.password is not None:
            self._update()

    @property
    def password(self):
        """
        Get or set password.

        Setting the password resets all settings. If username and password
        are not None, the settings will automatically be updated.

        :raise UsernamePasswordNotSetError: username or password not set
        :raise LoginError: login failed
        :raise InvalidCharsInUsernameError: invalid chars in username
        :raise ExpiredError: account expired
        :raise DisabledError: account disabled
        :raise UserApiCallLimitError: API call limit exceeded
        :raise UserApiMalfunctionError: API doesn't work
        :raise UserApiError: network errors, other errors
        :return: username
        :rtype: basestring
        """
        return self._password

    @password.setter
    def password(self, value):
        if value == self._password:
            return
        self._logger.debug("new password set")
        if value == "":
            value = None
        self._reset()
        self._password = value
        if self.username is not None and self.password is not None:
            self._update()

    @property
    def valid_until(self):  # read-only
        """
        Get the date and time the user account will expire.

        If the API has not been accessed yet or the last update
        is longer than max_cache_time ago, this will access the API and
        update all settings.

        :raise UsernamePasswordNotSetError: username or password not set
        :raise LoginError: login failed
        :raise InvalidCharsInUsernameError: invalid chars in username
        :raise ExpiredError: account expired
        :raise DisabledError: account disabled
        :raise UserApiCallLimitError: API call limit exceeded
        :raise UserApiMalfunctionError: API doesn't work
        :raise UserApiError: network errors, other errors
        :return: valid date
        :rtype: datetime
        """
        if self._should_update():
            self._update()
        return self._valid_until

    @property
    def random_exit(self):
        """
        Get or set whether to use a random exit IP address.

        If the API has not been accessed yet or the last update
        is longer than max_cache_time ago, this will access the API and
        update all settings.

        :raise UsernamePasswordNotSetError: username or password not set
        :raise LoginError: login failed
        :raise InvalidCharsInUsernameError: invalid chars in username
        :raise ExpiredError: account expired
        :raise DisabledError: account disabled
        :raise UserApiCallLimitError: API call limit exceeded
        :raise UserApiMalfunctionError: API doesn't work
        :raise UserApiError: network errors, other errors
        :return: whether to use a random exit IP address
        :rtype: bool
        """
        if self._should_update():
            self._update()
        return self._random_exit

    @random_exit.setter
    def random_exit(self, value):
        self._communicate({
            "randomExit": "1" if value else "0"
        })
        if self._random_exit != value:
            self._logger.error(
                "Sent request to set 'randomExit' to %s, "
                "but it's still %s!", value, self._random_exit)
            raise UserApiMalfunctionError(
                _("Changing random exit IP address didn't work!"))

    @property
    def default_port_forwarding(self):
        """
        Get or set whether default port forwarding should be used.

        If the API has not been accessed yet or the last update
        is longer than max_cache_time ago, this will access the API and
        update all settings.

        :raise UsernamePasswordNotSetError: username or password not set
        :raise LoginError: login failed
        :raise InvalidCharsInUsernameError: invalid chars in username
        :raise ExpiredError: account expired
        :raise DisabledError: account disabled
        :raise UserApiCallLimitError: API call limit exceeded
        :raise UserApiMalfunctionError: API doesn't work
        :raise UserApiError: network errors, other errors
        :return: whether default port forwarding should be used
        :rtype: bool
        """
        if self._should_update():
            self._update()
        return self._default_port_forwarding

    @default_port_forwarding.setter
    def default_port_forwarding(self, value):
        self._communicate({
            "defaultPortForwarding": "1" if value else "0"
        })
        if self._default_port_forwarding != value:
            self._logger.error(
                "Sent request to set 'defaultPortForwarding' to %s, "
                "but it's still %s!", value, self._default_port_forwarding)
            raise UserApiMalfunctionError(
                _("Changing default port forwarding didn't work!"))

    @property
    def auto_renew_port_forwarding(self):
        """
        Get or set whether to auto-renew port forwarding.

        If the API has not been accessed yet or the last update
        is longer than max_cache_time ago, this will access the API and
        update all settings.

        :raise UsernamePasswordNotSetError: username or password not set
        :raise LoginError: login failed
        :raise InvalidCharsInUsernameError: invalid chars in username
        :raise ExpiredError: account expired
        :raise DisabledError: account disabled
        :raise UserApiCallLimitError: API call limit exceeded
        :raise UserApiMalfunctionError: API doesn't work
        :raise UserApiError: network errors, other errors
        :return: whether to auto-renew port forwarding
        :rtype: bool
        """
        if self._should_update():
            self._update()
        return self._auto_renew_port_forwarding

    @auto_renew_port_forwarding.setter
    def auto_renew_port_forwarding(self, value):
        self._communicate({
            "autorenew_pf": "1" if value else "0"
        })
        if self._auto_renew_port_forwarding != value:
            raise UserApiMalfunctionError(
                _("Changing auto-renew port forwarding' didn't work!"))

    @property
    def custom_port_forwardings(self):
        """
        Get all custom port forwardings as list. List may be empty.

        :raise UsernamePasswordNotSetError: username or password not set
        :raise LoginError: login failed
        :raise InvalidCharsInUsernameError: invalid chars in username
        :raise ExpiredError: account expired
        :raise DisabledError: account disabled
        :raise UserApiCallLimitError: API call limit exceeded
        :raise UserApiMalfunctionError: API doesn't work
        :raise UserApiError: network errors, other errors
        :return: all custom port forwardings
        :rtype: list of PortForwarding
        """
        if self._should_update():
            self._update()
        return self._custom_port_forwardings

    def add_custom_port_forwarding(self, port_forwarding):
        """
        Add a custom port forwarding.

        :param port_forwarding: new port forwarding
            This will use the server_group_name and the dest_port only.
            dest_port may be None for 1-to-1 port forwarding.
        :type port_forwarding: PortForwarding
        :raise UsernamePasswordNotSetError: username or password not set
        :raise LoginError: login failed
        :raise InvalidCharsInUsernameError: invalid chars in username
        :raise ExpiredError: account expired
        :raise DisabledError: account disabled
        :raise UserApiCallLimitError: API call limit exceeded
        :raise UserApiMalfunctionError: API doesn't work
        :raise UserApiError: network errors, other errors
        :return:
        :rtype:
        """

        if len(self._server_groups) == 0:
            self._update()

        if port_forwarding.server_group_name not in self._server_groups:
            raise UserApiError(
                _("No such server group: '{}'").format(
                    port_forwarding.server_group_name))

        prev_num_port_forwardings = len(self._custom_port_forwardings)

        server_group_id = str(
            self._server_groups[port_forwarding.server_group_name])
        dest_port = ",{}".format(
            port_forwarding.dest_port if port_forwarding.dest_port is not None
            else "")

        self._communicate({
            "setPortForwarding[]": "%s%s" % (server_group_id, dest_port)
        })

        # is port forwarding in list?
        found_it = False
        if len(self._custom_port_forwardings) == prev_num_port_forwardings + 1:
            if port_forwarding.dest_port is None:  # 1-to-1
                found_it = True
            else:
                for returned_port_forwarding in self._custom_port_forwardings:
                    if returned_port_forwarding.server_group_name == \
                            port_forwarding.server_group_name \
                            and returned_port_forwarding.dest_port == \
                            port_forwarding.dest_port:
                        found_it = True
                        break

        if not found_it:
            raise UserApiMalfunctionError(
                _("Adding new port forwarding didn't work!"))

    def delete_custom_port_forwarding(self, port_forwardings):
        """
        Delete a custom port forwrading

        :param port_forwardings: The port forwarding witch should be deleted.
            This will use nothing but the port_forwarding.pf_id
        :type port_forwardings: PortForwarding | list of PortForwarding
        :raise UsernamePasswordNotSetError: username or password not set
        :raise LoginError: login failed
        :raise InvalidCharsInUsernameError: invalid chars in username
        :raise ExpiredError: account expired
        :raise DisabledError: account disabled
        :raise UserApiCallLimitError: API call limit exceeded
        :raise UserApiMalfunctionError: API doesn't work
        :raise UserApiError: network errors, other errors
        """
        assert port_forwardings is not None

        # TODO: test deletion of multiple pfs
        pf_ids = ""
        if isinstance(port_forwardings, list):
            pf_ids = ",".join(str(pf.pf_id) for pf in port_forwardings)
        else:
            pf_ids = str(port_forwardings.pf_id)

        self._communicate({
            "deletePortForwarding[]": pf_ids
        })

        # is port forwarding in list?
        for returned_port_forwarding in self._custom_port_forwardings:
            if returned_port_forwarding.pf_id in pf_ids.split(","):
                raise UserApiMalfunctionError(
                    _("Deleting port forwarding didn't work!"))

    @staticmethod
    def get_default_port_forwarding_ports_by_ip_address(ip_address):
        """
        Calculate the default port forwarding ports.
        Use default_port_forwarding to check whether default port forwarding
         is enabled

        :param ip_address: the internal IP address
        :type ip_address: basestring
        :return: the list of ports
        :rtype: list of int
        """
        if not isinstance(ip_address, basestring):
            raise NotAnIPAddressError(
                "'{}' is not an IP address".format(ip_address))

        # noinspection PyUnresolvedReferences
        ip_address_parts = ip_address.split(".")
        if not len(ip_address_parts) == 4:
            raise NotAnIPAddressError(
                "'{}' is not an IP address".format(ip_address))
        for part in ip_address_parts:
            try:
                int_part = int(part)
            except (ValueError, TypeError):
                raise NotAnIPAddressError(
                    "'{}' is not an IP address".format(ip_address))
            if not 0 <= int_part <= 255:
                raise NotAnIPAddressError(
                    "'{}' is not an IP address".format(ip_address))

        middle_part = ip_address_parts[2][-1]
        last_part = ip_address_parts[3].zfill(3)

        default_port_forwardings = []
        for first_part in range(1, 4):
            default_port_forwardings.append(int(
                "{first_part}{middle_part}{last_part}".format(
                    first_part=first_part,
                    middle_part=middle_part,
                    last_part=last_part
                )))

        return default_port_forwardings
