# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2014-2015 Perfect Privacy <support@perfect-privacy.com>
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License version 3, as published
# by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranties of
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR
# PURPOSE.  See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

import requests
from os.path import join
import os
import logging
from gettext import gettext as _
from subprocess import Popen, PIPE
import tempfile


class DownloadError(Exception):
    """ Download failed """


class MembersAreaDownloader(object):

    SIG_PUBKEY = """-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAw89YGj7ROj7T/zH/eDmU
Do2tuzdMva3KYDS0PpRaaAgRnvnr6g42Dufl4Ht2wANM1MaishFZ7CZjdMqolPU2
EiumCKx4Gpc1bv78v14QLdh5GkHbtQWY919tiRe7AgbPZuvv5j+D9FjmV68pM/Zj
5EC99Cu9d2z004ub3z8dVTl17cOxIeGXtLY3xxc44JBVbaIQccdUbZPssdjdpb+m
fa2NtIpCt5/EHRgS8wjsxNqMfr+Lrj8y3STddlF3BOv+7sUcQ6km86yEBJb1cjal
eFD5xq/5mxAuxeKyrOK+ZOY1glXC9WOWqWCj7VYIEitXAYHuMBJygLlZrC1iok5i
6wIDAQAB
-----END PUBLIC KEY-----"""

    LOGIN_URL = "https://www.perfect-privacy.com/member/"

    def __init__(self, application_name="<unknown name>",
                 application_version="<unknown version>"):
        self._logger = logging.getLogger(__name__)
        self.application_name = application_name
        self.application_version = application_version

        self.request_timeout = 10.0
        """ the request timeout in seconds """

    def download_from_members_area(self, username, password, file_name,
                                   stream=False, expected_content_type=None,
                                   expected_max_content_length=None):
        """
        Download from members area and return requests response object

        :param username: the member's username
        :type username: str | unicode
        :param password: the member's password
        :type password: str | unicode
        :param file_name: the file name to download from the member's area
        :type file_name: str | unicode
        :param stream: whether to stream the download, this is passed directly to requests.post()
        :type stream: bool
        :param expected_content_type: raises DownloadError if the expected content type doesn't match, i.e. "application/zip"
        :type expected_content_type: str | unicode
        :param expected_max_content_length: raises DownloadError if the length exceeds the maximum content length in bytes
        :type expected_max_content_length: int
        :return: the response object
        :rtype: requests.Response
        """

        headers = {"User-Agent": "{application_name} for Linux, ver. {version}"
                                 .format(application_name=self.application_name,
                                         version=self.application_version),
                   "Referer": "https://www.perfect-privacy.com/member/"}

        post_data = {"username": username,
                     "password": password,
                     "uri": "/member/download/?file={}".format(file_name)}

        try:
            self._logger.debug("POST request")
            r = requests.post(url=self.LOGIN_URL, headers=headers,
                              data=post_data, verify=True, stream=stream,
                              timeout=self.request_timeout)
            self._logger.debug("POST request finished")
            assert isinstance(r, requests.Response)
            r.raise_for_status()

        except requests.ConnectionError as e:
            raise DownloadError(_("Connection error: {}").format(str(e)))
        except requests.HTTPError as e:
            raise DownloadError(_("Invalid HTTP response: {}").format(str(e)))
        except requests.Timeout as e:
            raise DownloadError(_("Timeout: {}").format(str(e)))
        except requests.TooManyRedirects as e:
            raise DownloadError(_("Too many redirects: {}").format(str(e)))
        except requests.RequestException as e:
            raise DownloadError(_("Ambiguous exception: {}").format(str(e)))
        except AssertionError:
            raise DownloadError("assertion failed")
        except:
            raise DownloadError(_("Unknown error"))

        if not r.ok:
            raise DownloadError(
                _("invalid response: server returned status code {}")
                .format(r.status_code))

        # check content type
        if expected_content_type is not None:
            if 'content-type' not in r.headers:
                raise DownloadError(_("No Content-Type received from server"))
            elif expected_content_type not in r.headers['content-type']:
                raise DownloadError(
                    _("expected '{expected_type}' "
                      "but got '{actual_type}' from server")
                    .format(expected_type=expected_content_type,
                            actual_type=r.headers['content-type']))

        # check length
        # FIXME: server doesn't send content-length 27/02/2016
        #if expected_max_content_length is not None:
        #    if 'content-length' not in r.headers:
        #        raise DownloadError(_("No Content-Length received from server"))
        #    elif int(r.headers['content-length']) > expected_max_content_length:
        #        raise DownloadError(_("Downloaded file is too big"))

        self._logger.debug("response OK")
        return r

    def download_from_members_area_and_save_to_file(
            self, username, password, file_name, dest_dir,
            expected_content_type=None, expected_max_content_length=None):
        """
        Downloads a file from the member's area and save it to disk.

        See download_from_members_area() for details.

        :return: full file path on disk
        :rtype: str | unicode
        """

        # download as stream
        response = self.download_from_members_area(
            username, password, file_name, stream=True,
            expected_content_type=expected_content_type,
            expected_max_content_length=expected_max_content_length)

        local_file_name = join(dest_dir, file_name)

        with open(local_file_name, "wb") as local_file:
            for block in response.iter_content(1024):
                if not block:
                    break

                local_file.write(block)

        return local_file_name

    def verify_sha256sum(self, file_path, sha256sum):
        """
        Verify the sha256 checksum of a file.

        :param file_path: the full path of the file to check
        :type file_path: str | unicode
        :param sha256sum: the expected sha256sum
        :type sha256sum: str | unicode
        :return: whether the check has been passed successfully
        :rtype: bool
        :raises Exception
        """

        self._logger.debug("checking sha256sum of '{}' (must be '{}')"
                           .format(file_path, sha256sum))

        sha_file_path = None
        try:
            fd, sha_file_path = tempfile.mkstemp(text=True)
            f = os.fdopen(fd, "w")
            f.write("{} {}".format(sha256sum, file_path))
            f.close()

            sha_proc = Popen(
                ["/usr/bin/sha256sum", "--check", sha_file_path],
                stdin=PIPE, stdout=PIPE, stderr=PIPE)
            sha_proc.communicate()
            if sha_proc.returncode == 0:
                self._logger.debug("sha256 ok")
                return True
        except Exception as e:
            self._logger.debug("exception occurred while checking sha256: {}"
                               .format(str(e)))
            raise Exception(_("couldn't check sha256: {}").format(str(e)))
        finally:
            # remove temp file
            try:
                if sha_file_path is not None and os.path.exists(sha_file_path):
                    os.unlink(sha_file_path)
            except:
                pass
        self._logger.debug("sha256 check failed!")
        return False

    def verify_signature(self, file_path, sig_file_path):
        """
        Verify the sha512 signature of a file. Use a hard-encoded public key.

        :param file_path: the full path to the file to check
        :type file_path: str | unicode
        :param sig_file_path: the full path to the signature file
        :type sig_file_path: str | unicode
        :return: whether the check has been passed successfully
        :rtype: bool
        :raises Exception
        """
        self._logger.debug("checking signature of '{}'".format(file_path))

        pubkey_file_path = None
        try:
            fd, pubkey_file_path = tempfile.mkstemp(text=True)
            f = os.fdopen(fd, "w")
            f.write(self.SIG_PUBKEY)
            f.close()

            sig_proc = Popen(["/usr/bin/openssl", "dgst", "-sha512",
                              "-verify", pubkey_file_path,
                              "-signature", sig_file_path,
                              file_path],
                             stdin=PIPE, stdout=PIPE, stderr=PIPE)
            out, err = sig_proc.communicate()

            if sig_proc.returncode == 0 and out.find("OK") >= 0:
                self._logger.debug("signature ok")
                return True
        except Exception as e:
            self._logger.debug("exception occurred while checking signature: "
                               "{}".format(str(e)))
            raise Exception(_("couldn't check signature: {}").format(str(e)))
        finally:
            # remove the public key file
            try:
                if pubkey_file_path is not None and \
                        os.path.exists(pubkey_file_path):
                    os.unlink(pubkey_file_path)
            except:
                pass
        self._logger.debug("signature check failed!")
        return False
